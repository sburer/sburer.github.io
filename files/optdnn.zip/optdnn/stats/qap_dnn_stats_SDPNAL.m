outfile = fopen('qap_dnn_stats_SDPNAL.csv','w');
fprintf(outfile,'instance, A1_time_per_iter, SN_time_per_iter, A1_time_to_min_LB, SN_time_to_min_LB, A1_bound, A1_time, SN_bound, SN_time\n');

!cp ../data/qap/*.dat .

infiles = dir('*.dat');

for i = 1 : length(infiles)

  str1 = strcat('../tests/paper/qap_dnn/',infiles(i).name,'.out');
  str2 = strcat('../tests/SDPNAL-0_qap_dnn/',   infiles(i).name,'.out');

  if exist(str1,'file') > 0 & exist(str2,'file') > 0

    %% --------------------------------------------------------------------
    %% Extract total time and total iter (based on last reported iteration)
    %% --------------------------------------------------------------------

    %% Algorithm 1

    strexec = strcat( [ '!grep ''iter = '' ', str1, ' | tail -1 > tmp.txt' ]);
    eval(strexec);

    [fid,msg] = fopen('tmp.txt');
    if length(msg) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'iter = %f LB = %f time = %f norm = %f sig = %f');

    fclose(fid);

    iter1 = tmp{1};
    time1 = tmp{3};
    LB1 = tmp{2};

    %% SDPNAL

    strexec = strcat( [ '!grep SAM ', str2, ' | tail -1 > tmp.txt' ]);
    eval(strexec);

    [fid,msg] = fopen('tmp.txt');
    if length(msg) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'SAM  LB = %f   time = %f');

    fclose(fid);

    iter2 = -1;
    time2 = tmp{2};
    LB2 = tmp{1};

    %% ---------------------
    %% Extract per-iter info
    %% ---------------------

    %% Algorithm 1

    strexec = strcat( [ '!grep ''iter = '' ', str1, ' > tmp.txt' ]);
    eval(strexec);

    [fid,msg] = fopen('tmp.txt');
    if length(msg) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'iter = %f LB = %f time = %f norm = %f sig = %f');

    fclose(fid);

    info1 = [tmp{1}, tmp{2}, tmp{3}];

    %% SDPNAL

    strexec = strcat( [ '!grep SAM ', str2, ' > tmp.txt' ]);
    eval(strexec);

    [fid,msg] = fopen('tmp.txt');
    if length(msg) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'SAM  LB = %f   time = %f');

    fclose(fid);

    iter2 = length(tmp{1});
    info2 = [ [1:iter2]', tmp{1}, tmp{2}];

    %% ---------------------------------------------------------------
    %% Trim per-iter info (up to minimum of two lower bounds achieved)
    %% ---------------------------------------------------------------

    if size(info2,1) == 0
      fprintf('got error\n');
      return
    end

    LB = min( [ info1(end,2), info2(end,2) ] );

    ind1 = find( info1(:,2) <= LB);
    info1 = info1(ind1,:);

    ind2 = find( info2(:,2) <= LB);
    info2 = info2(ind2,:);

    %% Save

    results{i,1} = infiles(i).name;
    results{i,2} = time1/iter1;
    results{i,3} = time2/iter2;
    results{i,4} = max(1,info1(end,3));
    results{i,5} = max(1,info2(end,3));
    results{i,6} = LB1;
    results{i,7} = time1;
    results{i,8} = LB2;
    results{i,9} = time2;

    %% Print
    fprintf(outfile,'%s, %.15e, %.15e, %.2f, %.2f, %d, %.0f, %d, %0.f\n', results{i,1}, results{i,2}, results{i,3}, results{i,4}, results{i,5}, ceil(results{i,6}), results{i,7}, ceil(results{i,8}), results{i,9});

  end

end

fclose(outfile);

!rm -rf *.dat
!rm -rf tmp.txt
