outfile = fopen('boxqp_global_stats.csv','w');
fprintf(outfile,'instance, A1_time, BV_time\n');

!cp ../data/boxqp/basic/*.in .
!cp ../data/boxqp/extended/*.in .
!cp ../data/boxqp/extended2/*.in .

infiles = dir('*.in');

for i = 1 : length(infiles)

  str1 = strcat('../tests/paper/boxqp/global/'    ,infiles(i).name,'.out');
  str2 = strcat('../tests/BurVan09_boxqp/global/',infiles(i).name,'.out');

  if exist(str1,'file') > 0 & exist(str2,'file') > 0

    %% Extract total time

    %% Algorithm 1

    strexec = strcat( [ '!grep ''FINAL STATUS 4'' ', str1, ' > tmp.txt' ]);
    eval(strexec);

    [fid,mess] = fopen('tmp.txt');
    if length(mess) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'FINAL STATUS 4: time = %f');

    fclose(fid);

    time1 = tmp{1};

    %% Burer-Vandenbussche

    strexec = strcat( [ '!grep ''B&B CPU Time'' ', str2, ' > tmp.txt' ]);
    eval(strexec);

    [fid,mess] = fopen('tmp.txt');
    if length(mess) > 0
      error('Got error\n');
    end

    tmp = textscan(fid,'B&B CPU Time = %f');

    fclose(fid);

    time2 = tmp{1};

    %% Save

    results{i,1} = infiles(i).name;
    results{i,2} = max(1,time1);
    results{i,3} = max(1,time2);

    %% Print
    fprintf(outfile,'%s, %.2f, %.2f\n', results{i,1}, results{i,2}, results{i,3});

  end

end

fclose(outfile);

!rm -rf *.in
!rm -rf tmp.txt
