for i in $(ls *.dat)
do
  diff $i tmp/$i
done
