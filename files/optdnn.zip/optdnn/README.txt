README to accompany Mathematical Programming C submission

  Samuel Burer

  November 18, 2009 (revised)
  November  6, 2009 (revised)
  November  2, 2009 (revised)
  July     27, 2009 (revised)
  February 24, 2009 (revised)
  December 26, 2008
 
================================================================================

QUICK INSTRUCTIONS

Edit Makefile.inc and runall.sh. Run runall.sh.

================================================================================

INSTRUCTIONS

To run all tests, the following software / environments are required:

  Software                                          Version tested
  ---------------------------------------------     --------------
  SDPNAL                                            0
  CPLEX (with pivoting algorithm for convex QP)     11.0
  Matlab (with Mex and engine)                      7.8.0.347 (R2009a)
  Matlab Optimization Toolbox                       4.2 (R2009a)
  LAPACK                                            3.1.1
  ATLAS (for BLAS support)                          3.6.0
  Unix/Linux (with bash shell)

SDPNAL must be installed in the subdirectory code/SDPNAL-0.

It is suspected that relatively recent prior versions of the above
software / environments should work.

Please edit Makefile.inc and runall.sh as necessary to match your
system. Note that your Matlab command is required in both files.

Run all computational results via a command such as "/bin/bash
./runall.sh". Included in runall.sh is a setting to run just a small
subset of all tests ("runtests_partial").

================================================================================

NOTES

As with many lower bounding techniques, caution must be exercised when
using the lower bounds produced by the codes in this archive. Round-off
error due to floating point arithmetic may result in invalid bounds,
and nothing specific is done within the codes to control this error.
However, for the code in the subdirectory ./code/paper, which is the
main new contribution of the correspding paper, it is believed that
round-off error is not a severe issue. In particular, the round-off
error of any given bound is dependent on the round-off error of one
call to the Matlab function null() and one call to the LAPACK function
dsyevr().

My tests were run on the following machine:

    {zero:~ 106} uname -a
    Linux zero 2.6.27-14-generic #1 SMP Tue Jun 30 19:57:39 UTC 2009 i686 GNU/Linux
    {zero:~ 107} cat /etc/issue
    Ubuntu 8.10 \n \l

In the stats directory are also the Excel files used to create the final
tables and charts in the paper.
