#!/bin/bash

#############################
# Which set of tests to run #
#############################

RUNTESTS=runtests        # for full tests
# RUNTESTS=runtests_partial # for abbreviated tests (should take approx 10 minutes for all tests)

##########################################
# Command to start Matlab on your system #
##########################################

MATLAB='matlab -nodesktop -nodisplay -nojvm -nosplash'

#########
# Shell #
#########

SHELL=/bin/bash

# Should not need to edit below
# Should not need to edit below
# Should not need to edit below
# Should not need to edit below
# Should not need to edit below
# Should not need to edit below

##########################
# Save current directory #
##########################

MYPWD=$(pwd)

#################################################
# Compile the different codes                   #
# Will probably need machine-specific tailoring #
#################################################

cd code/BurVan06_qap_dnn
$SHELL compile.sh
cd $MYPWD

cd code/BurVan09_boxqp_dnn_global
$SHELL compile.sh
cd $MYPWD

cd code/paper
$MATLAB < opt_dnn_compile.m
cd $MYPWD

#############
# Run tests #
#############

cd tests/BurVan06_qap_dnn
$SHELL $RUNTESTS.sh
cd $MYPWD

cd tests/BurVan09_boxqp/dnn
$SHELL $RUNTESTS.sh
cd $MYPWD

cd tests/BurVan09_boxqp/global
$SHELL $RUNTESTS.sh
cd $MYPWD

cd tests/SDPNAL-0_qap_dnn
$MATLAB < $RUNTESTS.m
cd $MYPWD

cd tests/paper/qap_dnn
$MATLAB < $RUNTESTS.m
cd $MYPWD

cd tests/paper/boxqp/dnn
$MATLAB < $RUNTESTS.m
cd $MYPWD

cd tests/paper/boxqp/global
$MATLAB < $RUNTESTS.m
cd $MYPWD

cd tests/paper/quadmultiknap_global
$MATLAB < $RUNTESTS.m
cd $MYPWD

#################
# Compile stats #
#################

cd stats
$MATLAB < qap_dnn_stats_BurVan.m
$MATLAB < qap_dnn_stats_SDPNAL.m
$MATLAB < boxqp_dnn_stats.m
$MATLAB < boxqp_global_stats.m
# quadmultiknap_global compiled by hand from text file 'diary'
cd $MYPWD
