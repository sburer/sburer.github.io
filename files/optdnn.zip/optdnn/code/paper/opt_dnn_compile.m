mex -O opt_dnn_subprob_Y.c
mex -O opt_dnn_subprob_Z.c -lmwlapack -lmwblas

%% Possible Windows variation
%% In Windows, do not append underscores to blas function names in .c files.

%% mex -O project.c C:\Progra~1\MATLAB\R2008a\extern\lib\win32\lcc\libmwlapack.lib C:\Progra~1\MATLAB\R2008a\extern\lib\win32\lcc\libmwblas.lib 


