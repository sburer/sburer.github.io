%
% [LB,ret] = opt_qap_dnn(A,B)
%
% Solves the doubly nonnegative relaxation of the quadratic assignment
% problem
% 
%   min  trace(A*X*B*X')
%   s.t. X permutation matrix
%
% LB  = best lower bound obtained
% ret = internal return code
%

function [LB,ret] = opt_qap_dnn(data_A,data_B)

%% Setup user options

max_iter = 6000;
     sig = 1.0;

%% Ensure Matlab uses only one CPU

maxNumCompThreads(1);

%% Extract dimension of QAP

p = size(data_A,1);

%% Setup dimension of relaxation

n = p*p;

%% Setup Q (symmetric!) and c

Q = 2*kron(data_A,data_B);
Q = 0.5*(Q + Q');

c = zeros(n,1);

%% Setup A and b (Ax = b models the doubly stochastic nature of
%% permutation matrices)

A = [];
for i = 1:p
  tmp = zeros(p);
  tmp(:,i) = ones(p,1);
  A = [A; reshape(tmp,1,n); reshape(tmp',1,n)];
end

b = ones(2*p,1);

%% Setup B and E (all variables are binary; the complementarity
%% positions are the zeros of MAT below)

B = ones(n,1);

J = ones(p);
I = eye(p);
MAT = kron(J,J)/p^2 + kron(p*I-J,p*I-J)/(p^2*(p-1));

E = 1 - full(spones(MAT));

%% Setup L and U (bounds are 0 and 1)

L = zeros(n,1);
U = ones(n,1);


%% Run

[LB,Y,Z,S,sig,ret] = opt_dnn(Q,c,A,b,B,E,L,U,max_iter,[],sig,[]);
