% [val,x] = opt_boxqp_global(Q,c)
%
% Globally solves the noconvex box-constrained quadratic program
%
%   min  0.5*x'*Q*x + c'*x
%   s.t. 0 <= x <= e
%
% returning optimal value and solution [val,x].
%

function [val,x] = opt_boxqp_global(Q,c)

%%
%% This code is reasonably well documented, but it does not describe the
%% branch-and-bound algorithm itself. Please see
%% 
%%   @TechReport{BurVan06c,
%%     author        = {S. Burer and D. Vandenbussche},
%%     title         = {Globally Solving Box-Constrained Nonconvex Quadratic
%%                     Programs with Semidefinite-Based Finite Branch-and-Bound},
%%     type          = {Manuscript},
%%     institution   = {Department of Management Sciences, University of Iowa},
%%     address       = {Iowa City, IA, USA},
%%     month         = {November},
%%     year          = {2006},
%%     note          = {Revised June 2007 and July 2007. To appear in {\em
%%                     Computational Optimization and Applications\/}.}
%%   }
%%
%% for the full details.
%%

%% ----------------
%% Set user options
%% ----------------

 my_tol  = 1.0e-6; % Fathoming and branching tolerance 
max_iter = 1000;   % Max iters allowed for solving each relaxation

%% -------------------------------
%% Ensure Matlab uses only one CPU
%% -------------------------------

maxNumCompThreads(1);

%% ----------------------------------
%% Setup constants that do not change
%% ----------------------------------

%% Setup basic constants

saveQ = Q;
savec = c;

n = size(Q,1);

e = ones(n,1);
I = eye(n);
Z = zeros(n);
z = zeros(n,1);

%% Setup upper bounds for multipliers y and z

Dz = diag( sum(max(Q,0))' + c);
Dy = diag(-sum(min(Q,0))' - c);

%% Setup constants for constructing subproblems at the nodes

%% Explanation: To facilitate the construction of the subproblems at
%% the nodes, we save several 'big' vectors and matrices from which
%% subproblems can be gotten by just extracting the correct rows and
%% columns (variables and constraints).

bign = 4*n;

bigQ = [Q,Z,Z,Z;
        Z,Z,Z,Z;
        Z,Z,Z,Z;
        Z,Z,Z,Z];

bigc = [c;z;z;z];

bigA = [ I,I,Z ,Z  ;
        -Q,Z,Dz,Z  ;
         Q,Z,Z ,Dy];

bigb = [e;c;-c];

bigL = [z;z;z;z];

bigU = [e;e;e;e];

bigB = zeros(bign,1);
bigB( find(diag(saveQ) <= 0)    ) = 1;
bigB( find(diag(saveQ) <= 0) + n) = 1;

T = diag(bigB(1:n)); % 'T' for 'temp'

bigE = [Z,T,I,Z;
        T,Z,Z,I;
        I,Z,Z,I;
        Z,I,I,Z];

%% Setup constant for timing the code

tic;

%% -------------------------
%% Initialize B&B structures
%% -------------------------

LBLB    = -Inf;
F0F0{1} = [];
F1F1{1} = [];
FzFz{1} = [];
FyFy{1} = [];
SS      = zeros((1+bign)^2,1);
SIGSIG  = -1.0;  % Signal that we want default sig in aug Lag algorithm

%% ------------------------------------------------------------------
%% Calculate first global upper bound and associated fathoming target
%% ------------------------------------------------------------------

[globalUB,globalx] = matlabprimal(saveQ,savec);
globalUB
LB_target = globalUB - my_tol*max(1,abs(globalUB));

%% ----------------------
%% ----------------------
%% Begin BRANCH-AND-BOUND
%% ----------------------
%% ----------------------

nodes_created         = 1;
nodes_solved          = 0;
nodes_solved_fully    = 0;
nodes_solved_fathomed = 0;
nodes_infeasible      = 0;
nodes_pruned          = 0;

%% ------------------------------------------
%% While there are still nodes in the tree...
%% ------------------------------------------

while length(LBLB) > 0

  %% ------------
  %% Print status
  %% ------------

  fprintf('\n');
  fprintf('STATUS 1: (gUB,gLB,gap) = (%.8e, %.8e, %.3f%%)\n', ...
    globalUB, min(LBLB), 100*(globalUB - min(LBLB))/max([1,abs(globalUB)]));
  fprintf('STATUS 2: (created,solved,pruned,infeas,left) = (%d,%d,%d,%d,%d)\n', ...
    nodes_created, nodes_solved, nodes_pruned, nodes_infeasible, length(LBLB));
  fprintf('STATUS 3: solved = fully + fathomed : %d = %d + %d\n', ...
    nodes_solved, nodes_solved_fully, nodes_solved_fathomed);
  fprintf('STATUS 4: time = %f\n', toc);

  %% -----------------------------------------------
  %% Sort nodes for 'best-bound' node-selection rule
  %% -----------------------------------------------

  [LBLB,I] = sort(LBLB,2,'descend');
  F0F0 = F0F0(I);
  F1F1 = F1F1(I);
  FzFz = FzFz(I);
  FyFy = FyFy(I);
  SS = SS(:,I);
  SIGSIG = SIGSIG(I);

  %% ---------------------------------------------------
  %% Pull last problem off the problem list (best-bound) 
  %% ---------------------------------------------------

  LB = LBLB(end); 
  F0 = F0F0(end); F0 = F0{1};
  F1 = F1F1(end); F1 = F1{1};
  Fz = FzFz(end); Fz = Fz{1};
  Fy = FyFy(end); Fy = Fy{1};
  S = reshape(SS(:,end), 1+bign, 1+bign);
  SIG = SIGSIG(end);
  if SIG < 0.0 % Signal that we want default sig in aug Lag algorithm
    SIG = [];
  end

  %% ---------------------------------
  %% Delete that problem from the tree
  %% ---------------------------------

  LBLB = LBLB(1:end-1);
  F0F0 = F0F0(1:end-1);
  F1F1 = F1F1(1:end-1);
  FzFz = FzFz(1:end-1);
  FyFy = FyFy(1:end-1);
  SS = SS(:,1:end-1);
  SIGSIG = SIGSIG(1:end-1);

  %% ------------------
  %% Handle single node
  %% ------------------

  %% Do the following only if F0 and F1 do not intersect (otherwise,
  %% problem is clearly infeasible and there's nothing to do)

  if length(intersect(F0,F1)) == 0

    %% ----------------------------
    %% Prepare problem to be solved
    %% ----------------------------

    rows = [1:n, n+Fy, 2*n+Fz];
    cols = [1:2*n, 2*n + Fy, 3*n + Fz ];

    Q = bigQ(cols,cols);
    c = bigc(cols);
    A = bigA(rows,cols);
    b = bigb(rows);
    L = bigL(cols);
    U = bigU(cols);

    U(F0) = 0;
    L(F1) = 1;
    L(n+F0) = 1;
    U(n+F1) = 0;

    B = bigB(cols);

    E = bigE(cols,cols);

    locS = S([1,1+cols],[1,1+cols]);

    %% -----------------------------------
    %% Solve doubly nonnegative relaxation
    %% -----------------------------------

    fprintf('\n=======================================================================\n');
    fprintf('------------------ Commencing solution of node %4d -------------------\n', nodes_solved+1);

    F0
    F1
    Fy
    Fz

    [newLB,Y,Z,locS,SIG,retcode] = opt_dnn(Q,c,A,b,B,E,L,U,max_iter,locS,SIG,LB_target);

    fprintf('\n------------------------------- done! ---------------------------------\n');
    fprintf('=======================================================================\n\n');

    %% ------------
    %% Post-process
    %% ------------

    %% If newLB < LB, then it means that the subproblem did not solve
    %% well because theoretically, newLB >= LB at optimality. So we take
    %% this as a sign that sig needs to be reset. So we set SIG = -1 to
    %% signal that we want sig reset for the children.
    %%
    %% Otherwise, we update LB and save SIG as sqrt(SIG) to put downward
    %% pressure on SIG as we go deeper into the tree (empirical!).

    if newLB < LB
      SIG = -1.0;
    else
      LB = newLB;
      SIG = sqrt(SIG);
    end

    nodes_solved = nodes_solved + 1;
    if strcmp(retcode,'fathom')
      nodes_solved_fathomed = nodes_solved_fathomed + 1;
    else
      nodes_solved_fully = nodes_solved_fully + 1;
    end

    %% Save multiplier

    S = zeros(1+bign);
    S([1,1+cols],[1,1+cols]) = locS;
    S = reshape(S, (1+bign)^2, 1);

    %% Extract upper bound

    x = Y(2:n+1,1);
    [tmpval,tmpx] = matlabprimal(saveQ,savec,x);
    if tmpval < globalUB
      globalUB = tmpval;
      globalx  = tmpx;
    end

    %% Update fathoming target

    LB_target = globalUB - my_tol*max(1,abs(globalUB));

    %% ----------------------
    %% Prune tree by globalUB
    %% ----------------------

    tmpsz = length(LBLB);

    I = find(LBLB < LB_target);
    LBLB = LBLB(I);
    F0F0 = F0F0(I);
    F1F1 = F1F1(I);
    FzFz = FzFz(I);
    FyFy = FyFy(I);
    SS = SS(:,I);
    SIGSIG = SIGSIG(I);

    nodes_pruned = nodes_pruned + (tmpsz - length(LBLB));

    %% ------------------------
    %% Calculate KKT violations
    %% ------------------------

    z     = max(0, saveQ*x+savec);
    y     = max(0,-saveQ*x-savec);

    %% Next four lines ensure that we don't accidentally enforce the
    %% same complementarities in the next node!
    %%
    %% If the relaxations were being solved exactly, this would not
    %% be an issue.

    x(F0) = 0;
    x(F1) = 1;
    z(Fz) = 0;
    y(Fy) = 0;
    
    zvio = ( z ./ max(1.0e-8,diag(Dz)) ) .* x;
    yvio = ( y ./ max(1.0e-8,diag(Dy)) ) .* (e-x);

    vio  = max( [zvio;yvio] );

    %% ---------------------
    %% Branch (if necessary)
    %% ---------------------

    if LB < LB_target & vio > my_tol 

      %% Determine branching type

      if max(zvio) > max(yvio)

        [tmp,index] = max(zvio);
        if saveQ(index,index) > 0
          branch_case = 'z';
        else
          branch_case = 'n';
        end

      else

        [tmp,index] = max(yvio);
        if saveQ(index,index) > 0
          branch_case = 'y';
        else
          branch_case = 'n';
        end

      end

      %% Actually do the branching

      if branch_case == 'z'

        F0a = union(F0,index);
        F1a = F1;
        Fya = union(Fy,index);
        Fza = Fz;

        F0b = F0;
        F1b = F1;
        Fyb = Fy;
        Fzb = union(Fz,index);

      elseif branch_case == 'y'

        F0a = F0;
        F1a = union(F1,index);
        Fya = Fy;
        Fza = union(Fz,index);

        F0b = F0;
        F1b = F1;
        Fyb = union(Fy,index);
        Fzb = Fz;

      else

        F0a = union(F0,index);
        F1a = F1;
        Fya = union(Fy,index);
        Fza = Fz;

        F0b = F0;
        F1b = union(F1,index);
        Fyb = Fy;
        Fzb = union(Fz,index);

      end

      LBLB   = [LBLB  ,LB ,LB ];
      SS     = [SS    ,S  ,S  ];
      SIGSIG = [SIGSIG,SIG,SIG];

      F0F0{length(F0F0)+1} = F0a;
      F1F1{length(F1F1)+1} = F1a;
      FyFy{length(FyFy)+1} = Fya;
      FzFz{length(FzFz)+1} = Fza;

      F0F0{length(F0F0)+1} = F0b;
      F1F1{length(F1F1)+1} = F1b;
      FyFy{length(FyFy)+1} = Fyb;
      FzFz{length(FzFz)+1} = Fzb;

      nodes_created = nodes_created + 2;

    %% ----------------------
    %% End branching decision
    %% ----------------------

    end

  else

    nodes_infeasible = nodes_infeasible + 1;

  %% ---------------------------
  %% End handling of single node
  %% ---------------------------

  end

%% -------------------------------
%% End loop over nodes in the tree
%% -------------------------------

end

%% -----------------
%% Print final stats
%% -----------------

fprintf('\n');
fprintf('FINAL STATUS 1: optimal value = %.8e\n', globalUB);
fprintf('FINAL STATUS 2: (created,solved,pruned,infeas,left) = (%d,%d,%d,%d,%d)\n', ...
  nodes_created, nodes_solved, nodes_pruned, nodes_infeasible, length(LBLB));
fprintf('FINAL STATUS 3: solved = fully + fathomed : %d = %d + %d\n', ...
  nodes_solved, nodes_solved_fully, nodes_solved_fathomed);
fprintf('FINAL STATUS 4: time = %f\n', toc);

%% ------
%% Return
%% ------

val = globalUB;
x   = globalx;

%% ----------------------
%% ----------------------
%% End BRANCH-AND-BOUND
%% ----------------------
%% ----------------------

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Calculate a heuristic solution to the QP, possibly starting from x0

function [fval,x] = matlabprimal(Q,c,x0)

n = length(c);
z = zeros(n,1);
e = ones(n,1);

if nargin == 3

    [x,fval] = quadprog(Q,c,[],[],[],[],z,e,x0);

else

  rand('state',0);

  minfval = 1.0e10;
  for i = 1:10
    [x,fval] = quadprog(Q,c,[],[],[],[],z,e,rand(n,1));
    if fval < minfval 
      minfval = fval;
      minx    = x;
    end
  end
  fval = minfval;
  x    = minx;

end

return
