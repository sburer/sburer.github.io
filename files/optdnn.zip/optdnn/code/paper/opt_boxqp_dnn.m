% [LB,ret] = opt_boxqp_dnn(Q,c)
%
% Solve the doubly nonnegative relaxation of the the noconvex
% box-constrained quadratic program
%
%   min  0.5*x'*Q*x + c'*x
%   s.t. 0 <= x <= e
%
% LB  = best lower bound obtained
% ret = internal return code
%

function [LB,ret] = opt_boxqp_dnn(Q,c)

%% Set user options

max_iter = 6000;

%% Ensure Matlab uses only one CPU

maxNumCompThreads(1);

%% Setup data

n = size(Q,1);

e = ones(n,1);
I = eye(n);
Z = zeros(n);
z = zeros(n,1);

saveQ = Q;

Q = [Q,Z;
     Z,Z];

c = [c;z];

A = [I,I];

b = e;

L = [z;z];
U = [e;e];

B = zeros(2*n,1);
B( find(diag(saveQ) <= 0)     ) = 1;
B( find(diag(saveQ) <= 0) + n ) = 1;

T = diag(B(1:n)); % 'T' for 'temp'

E = [Z,T;
     T,Z];

%% Run

[LB,Y,Z,S,sig,ret] = opt_dnn(Q,c,A,b,B,E,L,U,max_iter,[],[],[]);
