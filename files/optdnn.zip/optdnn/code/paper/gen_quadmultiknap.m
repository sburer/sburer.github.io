% function [Q,A,b] = genquadknap(n,m,dens)
function [Q,A,b] = genquadknap(n,m,dens)

% rand('twister',seed);

A = ceil(50 .* rand(m,n));

b = zeros(m,1);
for i = 1:m
  tmp = sum(A(i,:)) - 49;
  b(i) = 49 + ceil( tmp * rand );
end

Q = zeros(n);
for i = 1:n
  for j = 1:i
    if rand*100 <= dens
      Q(i,j) = ceil( 100 * rand );
    end
    if i ~= j
      Q(j,i) = Q(i,j);
    end
  end
end
