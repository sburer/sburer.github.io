% [val,x] = opt_quadmultiknap_global(Q,A,b,max_time)
%
% Globally solves the quadratic multiple knapsack problem
%
%   max  x'*Q*x
%   s.t. A*x <= b
%          x binary
%
% returning optimal value and solution [val,x].
%

function [val,x] = quadknapbb(Q,A,b,max_time)

%% ----------------
%% Set user options
%% ----------------

 my_tol  = 1.0e-6; % Fathoming and branching tolerance 
max_iter = 1000;   % Max iters allowed for solving each relaxation

%% -------------------------------------------
%% Set max_time if user has *not* specified it
%% -------------------------------------------

if nargin < 4
  max_time = Inf;
end

%% -------------------------------
%% Ensure Matlab uses only one CPU
%% -------------------------------

maxNumCompThreads(1);

%% ----------------------------------
%% Setup constants that do not change
%% ----------------------------------

%% Setup basic constants

[m,n] = size(A);

e = ones(n,1);
I = eye(n);
z = zeros(n,1);

saveQ = -2*Q; %% Important!
savec = z;
saveA = A;
saveb = b;


%% Setup constants for passage into opt_dnn subroutine

bign = 2*n+m;

Q = zeros(bign);
Q(1:n,1:n) = saveQ;

c = zeros(bign,1);
c(1:n) = savec;

A = [ A , zeros(m,n), diag(b) ;
      I ,    I    , zeros(n,m) ];

b = [ b; ones(n,1) ];

L_save = zeros(bign,1); % Subproblems will only differ in L and U
U_save =  ones(bign,1);

B = [ones(2*n,1);zeros(m,1)];

E = zeros(bign);
E(n+1:2*n,1:n) = eye(n);
E = E + E';

%% Setup constant for timing the code

tic;

%% -------------------------
%% Initialize B&B structures
%% -------------------------

LBLB = -Inf;
F0F0{1} = [];
F1F1{1} = [];
SS = zeros((1+bign)^2,1);
SIGSIG = -1; % Signal that we want default sig in aug Lag algorithm

%% ------------------------------------------------------------------
%% Calculate first global upper bound and associated fathoming target
%% ------------------------------------------------------------------

globalx  = zeros(n,1);
globalUB = 0
LB_target = globalUB - my_tol*max(1,abs(globalUB));

%% ----------------------
%% ----------------------
%% Begin BRANCH-AND-BOUND
%% ----------------------
%% ----------------------

nodes_created         = 1;
nodes_solved          = 0;
nodes_solved_fully    = 0;
nodes_solved_fathomed = 0;
nodes_infeasible      = 0;
nodes_pruned          = 0;

%% ------------------------------------------
%% While there are still nodes in the tree...
%% ------------------------------------------

while length(LBLB) > 0

  %% ------------
  %% Print status
  %% ------------

  fprintf('\n');
  fprintf('STATUS 1: (gUB,gLB,gap) = (%.8e, %.8e, %.3f%%)\n', ...
    globalUB, min(LBLB), 100*(globalUB - min(LBLB))/max([1,abs(globalUB)]));
  fprintf('STATUS 2: (created,solved,pruned,infeas,left) = (%d,%d,%d,%d,%d)\n', ...
    nodes_created, nodes_solved, nodes_pruned, nodes_infeasible, length(LBLB));
  fprintf('STATUS 3: solved = fully + fathomed : %d = %d + %d\n', ...
    nodes_solved, nodes_solved_fully, nodes_solved_fathomed);
  fprintf('STATUS 4: time = %d\n', round(toc));

  %% -------------------------------------
  %% Terminate if too much time has passed
  %% -------------------------------------

  if round(toc) > max_time
    break;
  end

  %% -----------------------------------------------
  %% Sort nodes for 'best-bound' node-selection rule
  %% -----------------------------------------------

  [LBLB,I] = sort(LBLB,2,'descend');
  F0F0 = F0F0(I);
  F1F1 = F1F1(I);
  SS = SS(:,I);
  SIGSIG = SIGSIG(I);

  %% ---------------------------------------------------
  %% Pull last problem off the problem list (best-bound) 
  %% ---------------------------------------------------

  LB = LBLB(end); 
  F0 = F0F0(end); F0 = F0{1};
  F1 = F1F1(end); F1 = F1{1};
  S = reshape(SS(:,end), 1+bign, 1+bign);
  SIG = SIGSIG(end);
  if SIG < 0.0 % Signal that we want default sig in aug Lag algorithm
    SIG = [];
  end

  %% ---------------------------------
  %% Delete that problem from the tree
  %% ---------------------------------

  LBLB = LBLB(1:end-1);
  F0F0 = F0F0(1:end-1);
  F1F1 = F1F1(1:end-1);
  SS = SS(:,1:end-1);
  SIGSIG = SIGSIG(1:end-1);

  %% ------------------
  %% Handle single node
  %% ------------------

  %% Do the following only if F0 and F1 do not intersect (otherwise,
  %% infeasible and nothing to do) and if together their union is not
  %% [1:n] (otherwise, we're at an easy leaf)

  if length(intersect(F0,F1)) == 0 & length(union(F0,F1)) < n

    %% ----------------------------
    %% Prepare problem to be solved
    %% ----------------------------

    L = L_save;
    U = U_save;

    U(F0) = 0;
    L(F1) = 1;
    L(n+F0) = 1;
    U(n+F1) = 0;

    %% -----------------------------------
    %% Solve doubly nonnegative relaxation
    %% -----------------------------------

    fprintf('\n=======================================================================\n');
    fprintf('------------------ Commencing solution of node %4d -------------------\n', nodes_solved+1);

    F0
    F1

    [newLB,Y,Z,S,SIG,ret] = opt_dnn(Q,c,A,b,B,E,L,U,max_iter,S,SIG,LB_target);

    fprintf('\n------------------------------- done! ---------------------------------\n');
    fprintf('=======================================================================\n\n');

    %% ------------
    %% Post-process
    %% ------------

    %% If newLB < LB, then it means that the subproblem did not solve
    %% well because theoretically, newLB >= LB at optimality. So we take
    %% this as a sign that sig needs to be reset. So we set SIG = -1 to
    %% signal that we want sig reset for the children.
    %%
    %% Otherwise, we update LB and save SIG as sqrt(SIG) to put downward
    %% pressure on SIG as we go deeper into the tree (empirical!).

    if newLB < LB
      SIG = -1.0;
    else
      LB = newLB;
      SIG = sqrt(SIG);
    end

    nodes_solved = nodes_solved + 1;
    if strcmp(ret,'fathom')
      nodes_solved_fathomed = nodes_solved_fathomed + 1;
    else
      nodes_solved_fully = nodes_solved_fully + 1;
    end

    %% Save multiplier

    S = reshape(S, (1+bign)^2, 1);

    %% Extract upper bound (primal heuristic)

    x = Y(2:n+1,1);
    s = Y(n+2:1+2*n,1);
    rx = round(x);
    currval = 0.5*rx'*saveQ*rx + savec'*rx;
    while min(saveb - saveA*rx >= 0) == 0
      I = find(rx == 1);
      clear val;
      for i = 1:length(I)
        tmprx = rx;
        tmprx(I(i)) = 0;
        val(i) = 0.5*tmprx'*saveQ*tmprx + savec'*tmprx;
      end
      [tmpval,index] = min(val);
      currval = val(index);
      rx(I(index)) = 0;
    end
    tmpval = 0.5*rx'*saveQ*rx + savec'*rx;
    if tmpval < globalUB
      globalUB = tmpval;
      globalx  = rx;
    end

    %% Update fathoming target

    LB_target = globalUB - my_tol*max(1,abs(globalUB));

    %% ----------------------
    %% Prune tree by globalUB
    %% ----------------------

    tmpsz = length(LBLB);

    I = find(LBLB < LB_target);
    LBLB = LBLB(I);
    F0F0 = F0F0(I);
    F1F1 = F1F1(I);
    SS = SS(:,I);
    SIGSIG = SIGSIG(I);

    nodes_pruned = nodes_pruned + (tmpsz - length(LBLB));

    %% ------------------------------------------------------------------
    %% Select index to branch on (but will only branch if LB < LB_target)
    %% ------------------------------------------------------------------

    [vio,index] = max( [ x .* (e-x) ] );
    if vio == 0
      [vio,index] = max( [ s .* (e-s) ] );
    end
    if vio == 0 % Got unlucky, just select first index available for branching
      tmpI = setdiff( 1:n , union(F0,F1) );
      index = tmpI(1);
    end

    %% ---------------------
    %% Branch (if necessary)
    %% ---------------------

    if LB < LB_target

      F0a = union(F0,index);
      F1a = F1;

      F0b = F0;
      F1b = union(F1,index);

      LBLB   = [LBLB  ,LB ,LB ];
      SS     = [SS    ,S  ,S  ];
      SIGSIG = [SIGSIG,SIG,SIG];

      F0F0{length(F0F0)+1} = F0a;
      F1F1{length(F1F1)+1} = F1a;

      F0F0{length(F0F0)+1} = F0b;
      F1F1{length(F1F1)+1} = F1b;

      nodes_created = nodes_created + 2;

    %% ----------------------
    %% End branching decision
    %% ----------------------

    end

  else

    if length(intersect(F0,F1)) > 0
      nodes_infeasible = nodes_infeasible + 1;
    end

    if length(intersect(F0,F1)) == n
      rx = zeros(n,1);
      rx(F1) = 1;
      tmpval = 0.5*rx'*saveQ*rx + savec'*rx;
      if tmpval < globalUB
        globalUB = tmpval;
        globalx  = rx;
      end
    end

  %% ---------------------------
  %% End handling of single node
  %% ---------------------------

  end

%% -------------------------------
%% End loop over nodes in the tree
%% -------------------------------

end

%% -----------------
%% Print final stats
%% -----------------

fprintf('\n');
fprintf('FINAL STATUS 1: optimal value = %.8e\n', -globalUB);
fprintf('FINAL STATUS 2: (created,solved,pruned,infeas,left) = (%d,%d,%d,%d,%d)\n', ...
  nodes_created, nodes_solved, nodes_pruned, nodes_infeasible, length(LBLB));
fprintf('FINAL STATUS 3: solved = fully + fathomed : %d = %d + %d\n', ...
  nodes_solved, nodes_solved_fully, nodes_solved_fathomed);
fprintf('FINAL STATUS 4: time = %d\n', round(toc));

%% ------
%% Return
%% ------

val = globalUB;
x   = globalx;

%% ----------------------
%% ----------------------
%% End BRANCH-AND-BOUND
%% ----------------------
%% ----------------------

return
