Please download SDPNAL from
  http://www.math.nus.edu.sg/~mattohkc/SDPNAL.html
and install in the subdirectory SDPNAL-0.
