@Article{BurVan06,
  author        = {S. Burer and D. Vandenbussche},
  title         = {Solving Lift-and-Project Relaxations of Binary Integer
                  Programs},
  journal       = {SIAM Journal on Optimization},
  volume        = {16},
  number        = {3},
  year          = {2006},
  pages         = {493--512}
}

@Article{BurVan09,
  author        = {Samuel Burer and Dieter Vandenbussche},
  title         = {Globally Solving Box-Constrained Nonconvex Quadratic
                  Programs with Semidefinite-Based Finite Branch-and-Bound},
  journal       = {Comput. Optim. Appl.},
  fjournal      = {Computational Optimization and Applications. An
                  International Journal},
  volume        = {43},
  year          = {2009},
  number        = {2},
  pages         = {181--195}
}

http://www.math.nus.edu.sg/~mattohkc/SDPNAL.html
  AND
http://www.optimization-online.org/DB_HTML/2008/03/1930.html
