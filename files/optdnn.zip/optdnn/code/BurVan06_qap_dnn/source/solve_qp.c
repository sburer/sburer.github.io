#include "cplex.h"
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "globalsub.h"

extern double *tempc;
extern double *qdiag;
extern int *temp_indices;

int basis_array_uninit = 1;
int **cstatus, **rstatus;

double value_qp(double**, double**, double*, double**, double*, double**, double*, double);


void project_S(double *);
void project_S_new(double *);

int set_y0_qp_obj(CPXENVptr env, CPXLPptr qp, double sigma, double **Y, double **Z, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S, double *U)
{
  int i, j, status;

  // N oper plain Lag w/o Z
  if (isqap)  //If QAP, original obj is different
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = sym_lambda[0][j - 1] - diag_lambda[j];
    }
  else if (ismps)
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = mps_obj[j] + sym_lambda[0][j - 1] - diag_lambda[j];
    }
  else
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = 1 + sym_lambda[0][j - 1] - diag_lambda[j];
    }

  // N oper plain Lag w/ Z
  if(Z_VARS == 1)
    {
      for(i = 1; i <= n; i++) tempc[0] += -z_lambda[i][0];
      for(j = 1; j <= n; j++) for(i = 1; i <= n; i++) tempc[j] += -z_lambda[i][j];
    }

  // N oper aug Lag w/o Z
  for(j = 1; j <= n; j++) tempc[j] += sigma*(Y[j][j] + Y[j][0]);

  // N oper aug Lag w/ Z
  if(Z_VARS == 1)
    {
      for(i = 1; i <= n; i++) tempc[0] += sigma*(Z[i][0] + Y[i][0]);
      for(j = 1; j <= n; j++) for(i = 1; i <= n; i++) tempc[j] += sigma*(Z[i][j] + Y[i][j]);
    }

  // N+ oper plain Lag
  for(i = 0; i <= n; i++) tempc[i] += S[updiag_index(0,i)];

  // N+ oper aug Lag
  for(i = 0; i <= n; i++) tempc[i] += sigmawt*sigma*U[updiag_index(0,i)];
  for(i = 1; i <= n; i++) tempc[i] += -(sigmawt*sigma/2.0)*Y[i][0];
 

  status = CPXchgobj(env, qp, n+1, temp_indices, tempc);
  if (status) {fprintf(stderr, "Problem changing coeff for qp y^0\n"); return(status);}

  if (sigma_reset_flag)
    {
       // N oper aug Lag w/o Z
       qdiag[0] = 0.0;
       for(j = 1; j <= n; j++) qdiag[j] = 2.0*(-sigma);

       // N oper aug Lag w/ Z
       if(Z_VARS == 1)
         {
           qdiag[0] += 2.0*(-sigma/2.0)*n;
           for(j = 1; j <= n; j++) qdiag[j] += 2.0*(-sigma/2.0)*n;
         }

       // N+ oper aug Lag
       qdiag[0] += 2.0*(-sigmawt*sigma/2.0);
       for(j = 1; j <= n; j++) qdiag[j] += 2.0*(-sigmawt*sigma/4.0);


      for(j = 0; j <= n; j++)
	{
	  status = CPXchgqpcoef (env, qp, j, j, qdiag[j]);
	  if (status) {fprintf(stderr, "Problem changing diag for qp y^i\n"); return(status);}
	}
      /*  
	  status = CPXcopyqpsep (env, qp, qdiag);
	  if (status) {fprintf(stderr, "Problem changing diag for qp y^0\n"); return(status);}
      */
    }


  return(0);

}

int set_yi_qp_obj(CPXENVptr env, CPXLPptr qp, double sigma, double **Y, double **Z, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S, double *U, int i)
{
  int j, k, l, status;
  int p, q;  //Original x_{pq} corresponding to row Y_{i.}

  // N oper plain Lag w/o Z
    tempc[0] = -sym_lambda[0][i-1];
    for(j = 1; j <= n; j++)
    if(j == i)      tempc[j] = diag_lambda[j];
    else if (i < j) tempc[j] = sym_lambda[i][j-(i+1)];
    else            tempc[j] = -sym_lambda[j][i-(j+1)];


//If this is relaxation of QAP then index Y_{pq},{kl} has original coefficient 
// a_{pk} b_{ql}
    if (isqap)  
      { //First compute p and q (Note that i >= 1)
	p = (i-1)/qap_n;
	q = (i-1)%qap_n;
	for(k = 0; k < qap_n; k++)
	  for(l = 0; l < qap_n; l++)
	    {
	      tempc[1+square_index(k,l,qap_n)] += -a[p][k]*b[q][l];
	    }
      }

  // N oper plain Lag w/ Z
  if(Z_VARS == 1)
    {
      tempc[0] += z_lambda[i][0];
      for(j = 1; j <= n; j++) tempc[j] += z_lambda[i][j];
    }
  
  // N oper aug Lag w/o Z
  for(j = 0; j <= n; j++)
    {
      if (j != i) tempc[j] += sigma*Y[j][i];
      else        tempc[j] += sigma*Y[0][i];
    }

  // N oper aug Lag w/ Z
  if(Z_VARS == 1)
    {
      for(j = 0; j <= n; j++)
        {
          tempc[j] += sigma*(Y[0][j] - Z[i][j]);
        }
     }

  // N+ oper plain Lag
  for(j = 0; j <= n; j++)
    if(i <= j) tempc[j] += S[updiag_index(i,j)];
    else       tempc[j] += S[updiag_index(j,i)];

  // N+ oper aug Lag
  for(j = 0; j <= n; j++)
    if(i <= j) tempc[j] += sigmawt*sigma*U[updiag_index(i,j)];
    else       tempc[j] += sigmawt*sigma*U[updiag_index(j,i)];
  for(j = 0; j <= n; j++)
    if(j != i) tempc[j] += -(sigmawt*sigma/2.0)*Y[j][i];
 
  // N oper aug Lag w/o Z
  for(j = 0; j <= n; j++) qdiag[j] = 2.0*(-sigma/2.0);
 
  // N oper aug Lag w/ Z
  if(Z_VARS == 1)
    {
      for(j = 0; j <= n; j++) qdiag[j] += 2.0*(-sigma/2.0);
    }

  // N+ oper aug Lag
  for(j = 0; j <= n; j++)
    if(j == i) qdiag[j] += 2.0*(-sigmawt*sigma/2.0);
    else       qdiag[j] += 2.0*(-sigmawt*sigma/4.0);


  status = CPXchgobj(env, qp, n+1, temp_indices, tempc);
  if (status) {fprintf(stderr, "Problem changing coeff for qp y^i\n"); return(status);}
  
  for(j = 0; j <= n; j++)
    {
      status = CPXchgqpcoef (env, qp, j, j, qdiag[j]);
      if (status) {fprintf(stderr, "Problem changing diag for qp y^i\n"); return(status);}
    }
      /*
	status = CPXcopyqpsep (env, qp, qdiag);
	if (status) {fprintf(stderr, "Problem changing diag for qp y^i\n"); return(status);}
      */
    


  return(0);
}

int set_zi_qp_obj(CPXENVptr env, CPXLPptr qp, double sigma, double **Y, double **Z, double **sym_lambda, double *diag_lambda, double **z_lambda, int i)
{
  int j, status;


  for(j = 0; j <= n; j++)
    {
      tempc[j] = z_lambda[i][j];
      tempc[j] += sigma*(Y[0][j] - Y[i][j]);

      qdiag[j] = 2.0*(-sigma/2.0);
    }

  
  status = CPXchgobj(env, qp, n+1, temp_indices, tempc);
  if (status) {fprintf(stderr, "Problem changing coeff for qp z^i\n"); return(status);}


  if (sigma_reset_flag)
    {
      for(j = 0; j <= n; j++)
	{
	  status = CPXchgqpcoef (env, qp, j, j, qdiag[j]);
	  if (status) {fprintf(stderr, "Problem changing diag for qp y^i\n"); return(status);}
	}
      /*
	status = CPXcopyqpsep (env, qp, qdiag);
	if (status) {fprintf(stderr, "Problem changing diag for qp z^i\n"); return(status);}
      */
    }


  return(0);
}

int solve_qp_subprob(CPXENVptr env, CPXLPptr qp, double *soln)
{
  int status, qpstat, k, l;
  double objval, *tempx;

  status = CPXqpopt(env, qp);
  if (status) {fprintf(stderr, "Problem solving qp\n"); return (status);}

  qpstat = CPXgetstat(env,qp);
  if (qpstat == CPX_STAT_INForUNBD)
    {
      printf("Incorrect qpstat in qp subproblem\n");
      printf("qpstat = %d\n", qpstat);
      CPXgetobjval(env,qp,&objval);
      printf("objval = %.10e\n", objval);
      tempx = (double *) calloc(n+1,sizeof(double));
      CPXgetx(env,qp,tempx,0,n);
      printf("x0 = %.4f\n", tempx[0]);
      if (isqap)  
        { //First compute p and q (Note that i >= 1)
        
          for(k = 0; k < qap_n; k++)
            for(l = 0; l < qap_n; l++)
              {
                printf("x(%d,%d) = %.4f\n", k+1, l+1, tempx[1+square_index(k,l,qap_n)]);
              }
        }
      else
        {
          for(k = 1; k <= n; k++)
            printf("x(%d) = %.4f\n", k, tempx[k]);
        }
      CPXwriteprob(env, qp, "test.lp", NULL);
      return(1);
    }  

  status = CPXgetx(env, qp, soln, 0, n); 
  if (status)
    {
      fprintf(stderr, "Problem getting x values of qp subproblem\n");
      return(status);
    }

  return(0);

}

int solve_auglagr(CPXENVptr env, CPXLPptr *qp, double *curval, double sigma, double **Y, double **Z, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S, double *U)
{
  int i, j, loop, status=0;
  int psd_loop;
  //double last_YZUnorm=1.0e10, YZUnorm, objval, last_objval=-1.0e10;
  // char tempname[60];


  if (basis_array_uninit)
    {
      cstatus = (int **) calloc(2*n+1, sizeof(int *));
      rstatus = (int **) calloc(2*n+1, sizeof(int *));
      for(i = 0; i <= n; i++)
	{
	  cstatus[i] = (int *) calloc(n+m+1, sizeof(int));
	  rstatus[i] = (int *) calloc(n+m+1, sizeof(int));
	  if (i >= 1 && Z_VARS == 1)
	    {
	      cstatus[i+n] = (int *) calloc(n+m+1, sizeof(int));
	      rstatus[i+n] = (int *) calloc(n+m+1, sizeof(int));
	    }
	}
    }


  for(psd_loop = 1; psd_loop <= num_psd_cycles; psd_loop++)
    {
  



  //----------------------------------------------------------------------------
  //---- begin: solve subproblem for fixed U -----------------------------------
  //----------------------------------------------------------------------------
  status = 0;
  for(loop = 1; loop <= num_qp_cycles; loop++)
    {
      // Solve y^0 qp subproblem
      status = set_y0_qp_obj(env, qp[0], sigma, Y, Z, sym_lambda, diag_lambda, z_lambda, S, U);
      if (status) {fprintf(stderr, "Problem setting y^0 qp obj\n"); return(status);}

      if (!basis_array_uninit)
	{
	  status = CPXcopybase(env, qp[0], cstatus[0], rstatus[0]);
          if (status)
            {
              fprintf(stderr, "Error copying basis into problem\n");
              return(status);
            }
	}
      //sprintf(tempname, "qp0.lp");
      //CPXwriteprob(env, qp[0], tempname, NULL);
      status = solve_qp_subprob(env, qp[0], Y[0]);
      if (status) {fprintf(stderr, "Problem solving y^0 qp\n"); return(status);}

      status = CPXgetbase(env, qp[0], cstatus[0], rstatus[0]);
      if (status)
        {
          fprintf(stderr, "Error getting basis from problem\n");
          return(status);
        } 

      
      for(i = 1; i <= n; i++)
	{
	  // Solve y^i qp subprob
	  status = set_yi_qp_obj(env, qp[1], sigma, Y, Z, sym_lambda, diag_lambda, z_lambda, S, U, i);
	  if (status) {fprintf(stderr, "Problem setting y^i qp obj\n"); return(status);}
	  if (!basis_array_uninit)
	    {
	      status = CPXcopybase(env, qp[1], cstatus[i], rstatus[i]);
	      if (status)
		{
		  fprintf(stderr, "Error copying basis into problem\n");
		  return(status);
		}
	    } 
	  //sprintf(tempname, "qp%d.lp", i);
	  //CPXwriteprob(env, qp[1], tempname, NULL);
	  status = solve_qp_subprob(env, qp[1], Y[i]);
	  if (status) {fprintf(stderr, "Problem solving y^i qp\n"); return(status);}
	  status = CPXgetbase(env, qp[1], cstatus[i], rstatus[i]);
	  if (status)
	    {
	      fprintf(stderr, "Error getting basis from problem\n");
	      return(status);
	    }

          // Solve z^i qp subprob
          if(Z_VARS == 1)
            {
              status = set_zi_qp_obj(env, qp[2], sigma, Y, Z, sym_lambda, diag_lambda, z_lambda, i);
              if (status) {fprintf(stderr, "Problem setting y^i qp obj\n"); return(status);}
              if (!basis_array_uninit)
                {
                  status = CPXcopybase(env, qp[2], cstatus[i+n], rstatus[i+n]);
                  if (status)
                    {
                      fprintf(stderr, "Error copying basis into problem\n");
                      return(status);
                    }
                }
              status = solve_qp_subprob(env, qp[2], Z[i]);
              if (status) {fprintf(stderr, "Problem solving z^i qp\n"); return(status);}
              status = CPXgetbase(env, qp[2], cstatus[i+n], rstatus[i+n]);
              if (status)
                {
                  fprintf(stderr, "Error getting basis from problem\n");
                  return(status);
                } 
            }

          // Solve y^0 qp subproblem
	  status = set_y0_qp_obj(env, qp[0], sigma, Y, Z, sym_lambda, diag_lambda, z_lambda, S, U);
	  if (status) {fprintf(stderr, "Problem setting y^0 qp obj\n"); return(status);}
      
	  if (!basis_array_uninit)
	    {
	      status = CPXcopybase(env, qp[0], cstatus[0], rstatus[0]);
	      if (status)
		{
		  fprintf(stderr, "Error copying basis into problem\n");
		  return(status);
	        }
            } 
	  status = solve_qp_subprob(env, qp[0], Y[0]);
	  if (status) {fprintf(stderr, "Problem solving y^0 qp\n"); return(status);}

	  status = CPXgetbase(env, qp[0], cstatus[0], rstatus[0]);
	  if (status) 
	    {
	      fprintf(stderr, "Error getting basis from problem\n");
	      return(status);
	    }

	}


      sigma_reset_flag = 0;
      basis_array_uninit = 0;
    
  
    }
    //----------------------------------------------------------------------------
    //----  end:  solve subproblem for fixed U -----------------------------------
    //----------------------------------------------------------------------------



    //----------------------------------------------------------------------------
    //---- begin: solve subproblem for fixed Y -----------------------------------
    //----------------------------------------------------------------------------

    if(do_psd == 1) {
  
      for(i = 0; i <= n; i++)
        for(j = i; j <= n; j++)
          U[updiag_index(i,j)] = -(1.0/(sigmawt*sigma))*S[updiag_index(i,j)] + 0.5*(Y[i][j] + Y[j][i]);

      project_S_new(U);

//       tempval = 0.0;
//       for(i = 0; i <= n; i++)
//         for(j = i; j <= n; j++)
//           tempval += U[updiag_index(i,j)]*U[updiag_index(i,j)];
//       printf("tempval = %f ", tempval);   

//       for(i = 0; i <= n; i++)
//         for(j = i; j <= n; j++)
//           U[updiag_index(i,j)] = -(1.0/(sigmawt*sigma))*S[updiag_index(i,j)] + 0.5*(Y[i][j] + Y[j][i]);

//       project_S(U);

//       tempval = 0.0;
//       for(i = 0; i <= n; i++)
//         for(j = i; j <= n; j++)
//           tempval += U[updiag_index(i,j)]*U[updiag_index(i,j)];
//       printf("= %f\n", tempval);   

    } 
 
    
    //----------------------------------------------------------------------------
    //----  end:  solve subproblem for fixed Y -----------------------------------
    //----------------------------------------------------------------------------




    // Uncomment following to implement a semi-reasonable stopping criterion for the QP subproblem
    /*
    YZUnorm = 0.0;
    for(i = 0; i <= n; i++) for(j = i; j <= n; j++) YZUnorm += pow(U[updiag_index(i,j)],2.0);
    for(i = 0; i <= n; i++) for(j = 0; j <= n; j++) YZUnorm += pow(Y[i][j],2.0);
    for(i = 1; i <= n; i++) for(j = 0; j <= n; j++) YZUnorm += pow(Z[i][j],2.0);
    //    printf("YZUnorm = %f\n", tempval);
    //    if(fabs(YZUnorm - last_YZUnorm) < 1.0e-6) break;
    last_YZUnorm = YZUnorm;
    */


    }


  return(status);

}
