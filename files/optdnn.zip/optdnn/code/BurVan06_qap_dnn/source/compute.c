#include "cplex.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include "globalsub.h"
#define row_square_index(i,j,numrows)  ((j*(numrows)) + i)
#define MYCALLOC(VAR,TYPE,SIZE) if (((VAR) = (TYPE *) calloc ((size_t)(SIZE), (size_t)sizeof(TYPE))) == NULL) { printf ("MINTO: Memory allocation failed\n"); exit(0); }
#define MYFREE(VAR) free ((void *)(VAR)); VAR = NULL;

/*Modification to solving LP's without x[0]:  Keep tempc to be length n+1, but only pass tempc+1
  to CPX_chgobj.  When solving subproblems, check if tempc[0] + z[1] <= 0*/

//Global variables that i only want to allocate once
double *tempc;
double *qdiag;
int *temp_indices;

//Global variables i only want to allocate once in project_S
double *EigValue, *EigVector, *Work;
int INFO, tempN, incX;
char JOBZ, UPLO;

void project_S(double *);
void project_S_new(double *);
void print_tempc();

void init_objarrays()
{
  int i;
  tempc = (double *) calloc(n+1, sizeof(double));
  qdiag = (double *) calloc(n+1, sizeof(double));
  temp_indices = (int *) calloc(n+1, sizeof(int));

  for(i = 0; i <= n; i++)
    temp_indices[i] = i;

  EigValue = (double *) malloc((n+1)*sizeof(double));
  EigVector = (double *) malloc((n+1)*(n+1)*sizeof(double));
  Work = (double *) malloc((n+1)*3*sizeof(double));
  tempN = n+1;
  incX = 1;
  JOBZ='V';
  UPLO='U';
}

void finish_objarrays()
{
  free(tempc);
  free(qdiag);
  free(temp_indices);
  free(EigValue);
  free(EigVector);
  free(Work);
}


// Sam: Change #3 part 2

double compute_dir(double **Y, double **Z, double *U, double **sym_dir, double *diag_dir, double **z_dir, double *S_dir)
{
  int i, j;
  double tempval, sum = 0.0, zero_or_one = 1.0;


  if(do_psd == 0 && sigmawt == 0.0) zero_or_one = 0.0;

  for(i = 0; i <= n; i++)
    {
      for(j = i + 1; j <= n; j++)
        {
          sym_dir[i][j - (i + 1)] = tempval = Y[i][j] - Y[j][i];
          sum += tempval*tempval;
        }
      if (i > 0)
        {
          diag_dir[i] = tempval = Y[i][i] - Y[0][i];
          sum += tempval*tempval;
          if(Z_VARS == 1) {
            for(j = 0; j <= n; j++) {
              z_dir[i][j] = tempval = Z[i][j] - Y[0][j] + Y[i][j];
              sum += tempval*tempval;
            }
          }
        }
    }

    for(i = 0; i <= n; i++)
      for(j = i; j <= n; j++) {
        S_dir[updiag_index(i,j)] = tempval = 0.5*(Y[i][j] + Y[j][i]) - U[updiag_index(i,j)];
        if(j == i) sum += zero_or_one*tempval*tempval;
        else sum += 2.0*zero_or_one*tempval*tempval;
      }

//    printf("Solution Violation: %.6f\n", sqrt(sum));
    return sqrt(sum);

}

 



void update_duals(double stepsize, double Lss, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S, double **sym_dir, double *diag_dir, double **z_dir, double *S_dir)
{
  int i, j;

  for(i = 0; i <= n ; i++)
    {
      for(j = i + 1; j <= n; j++)
	{
	  sym_lambda[i][j - (i + 1)] -= stepsize*sym_dir[i][j - (i + 1)];
	}
      if (i > 0)
	{
	  diag_lambda[i] -= stepsize*diag_dir[i];
          if(Z_VARS == 1) {
            for(j = 0; j <= n; j++)
	      z_lambda[i][j] -= stepsize*z_dir[i][j];
          }
	}
    }


  if (Lss > DBL_MIN)  /*Update dual S matrix*/
    {
      for(i = 0; i <= n; i++)
	for(j = i; j <= n; j++)
	  {
	    S[updiag_index(i,j)] -= Lss*S_dir[updiag_index(i,j)];
	  }

      //Project S matrix on psd cone
//       project_S(S);
      project_S_new(S);

    }

}

void project_S(double *S)
{
  
  int i,j;
  
  dspev_(&JOBZ, &UPLO, &tempN, S, EigValue, EigVector, &tempN, Work, &INFO);

  if (INFO != 0)
    {
      printf("Problem computing eigvalues/vectors\n info = %d\n", INFO);
      exit(0);
    }

  for(i = 0; i <= n; i++)
    for(j = i; j <= n; j++)
      S[updiag_index(i,j)] = 0.0;

  for(j = 0; j <= n; j++)
    {
      if (EigValue[j] >= 0.0)
	{
	  dspr_(&UPLO, &tempN, &(EigValue[j]), EigVector+(tempN*j), &incX, S);
	}
    }

  
  
}

void project_S_new(double *S)
{
  int i, j;
  int iOne = 1;

  char JOBZ  = 'V';
  char RANGE = 'V';
  char UPLO  = 'U';

  int nn;

  double *TempMatrix;

  double VL = 0, VU = 1.0e10;
  int    IL, IU;

  double ABSTOL = 1e-10;

  int     NumEigs;
  double *EigVals;
  double *EigVecs;
  int    *SuppEigVals;

  double  temp_dWork;
  int     temp_iWork;

  double *dWork;
  int     dWorkLength;
  int    *iWork;
  int     iWorkLength;

  int INFO;

  /* */

  nn = tempN;

  MYCALLOC(EigVals, double,   nn);
  MYCALLOC(EigVecs, double, nn*nn);

  MYCALLOC(TempMatrix, double, nn*nn);
  for(i = 0; i < nn; i++)
    for(j = i; j < nn; j++) {
      TempMatrix[row_square_index(i,j,nn)] = S[updiag_index(i,j)];
      TempMatrix[row_square_index(j,i,nn)] = S[updiag_index(i,j)];
    }

  MYCALLOC(SuppEigVals, int, 2*nn);

  dWorkLength = -1;
  iWorkLength = -1;

  dsyevr_(&JOBZ, &RANGE, &UPLO, &nn, TempMatrix, &nn, &VL, &VU, &IL,
          &IU, &ABSTOL, &NumEigs, EigVals, EigVecs, &nn, SuppEigVals,
          &temp_dWork, &dWorkLength, &temp_iWork, &iWorkLength, &INFO);

  if (INFO != 0) {
    printf("project: Problem with dsyevr_ (first stage).\n");
    exit(0);
  }

  dWorkLength = (int) temp_dWork;
  iWorkLength = mymax(10*nn, temp_iWork);

  if (dWorkLength > 0) {
    MYCALLOC(dWork, double, dWorkLength);
  }
  else {
    dWork = NULL;
  }
  if (iWorkLength > 0) {
    MYCALLOC(iWork, int, iWorkLength);
  }
  else {
    iWork = NULL;
  }

  /* */

  VL = 0.0;
  VU = 0.0;
  for(i = 0; i < n*n; i++)
    VU += TempMatrix[i]*TempMatrix[i];
  VU = sqrt(VU);

  /* */

  dsyevr_(&JOBZ, &RANGE, &UPLO, &nn, TempMatrix, &nn, &VL, &VU, &IL,
          &IU, &ABSTOL, &NumEigs, EigVals, EigVecs, &nn, SuppEigVals,
          dWork, &dWorkLength, iWork, &iWorkLength, &INFO);

  if (INFO != 0) {

    VL = -VU;
    dsyevr_(&JOBZ, &RANGE, &UPLO, &nn, TempMatrix, &nn, &VL, &VU, &IL,
            &IU, &ABSTOL, &NumEigs, EigVals, EigVecs, &nn, SuppEigVals,
            dWork, &dWorkLength, iWork, &iWorkLength, &INFO);

    if (INFO != 0) {
      printf("project: Problem with dsyevr_ (second stage).\n");
      exit(0);
    }

  }

  /* */

  for(i = 0; i < nn; i++)
    for(j = i; j < nn; j++)  
      S[updiag_index(i,j)] = 0.0;

  for(j = 0; j < NumEigs; j++)
    if (EigVals[j] >= 0.0) 
      dspr_(&UPLO, &nn, &(EigVals[j]), EigVecs + j*nn, &iOne, S);
    
  /* */

  MYFREE(EigVals);
  MYFREE(EigVecs);
  MYFREE(TempMatrix);
  MYFREE(SuppEigVals);
  MYFREE(dWork);
  MYFREE(iWork);

  return;

}





// void project_S(double *S)
// {

//         int i, j;
//                 char RANGE = 'V';
//                 double VL, VU;
//                 int IL, IU;
//                 double ABSTOL = 1e-10;
//                 int numeig;
//                 
//                 double tempdwork;
//                 int tempiwork;

//         
//                 int tempmatlength;

//                 tempmatlength = tempN*tempN;
//                 
//                 EASYDSCAL(tempmatlength, 0.0,tempmatrix);
//                 // Copy S into tempmatrix (because tempmatrix must be full size, with
//                 // upper diagonal containing the actual matrix.  I don't think there's a faster
//                 // to copy this?  Can you think of one Sam?
//                 // Unfortunately no. --Sam
//                 for(i = 0; i < tempN; i++)
//                         for(j = i; j < tempN; j++)  
//                                 tempmatrix[row_square_index(i,j,tempN)] = S[updiag_index(i,j)];


//                 VL = 0.0;
//                 //The following is an approximate upper bound on the largest eigenvalue 
//                 VU = 2*EASYDNRM2(UDIM, S) + 1 ;


//                 dsyevr_(&JOBZ, &RANGE, &UPLO, &tempN, tempmatrix, &tempN, &VL, &VU, &IL, &IU,
//                                 &ABSTOL, &numeig, EigValue, EigVector, &tempN, suppeigvec, dwork, &dworklength,
//                                 intwork, &intworklength, &INFO);
//                 if (INFO != 0)
//                 {
//                         printf("Problem with second lapack function\n");
//                         exit(0);
//                 }

//                 cblas_dscal (UDIM, 0.0, S, 1);

//                 for(j = 0; j < numeig; j++)
//                         if (EigValue[j] >= 0.0)
//                                 dspr_(&UPLO, &tempN, &(EigValue[j]), EigVector+(tempN*j), &incX, S);


//         }
// }

