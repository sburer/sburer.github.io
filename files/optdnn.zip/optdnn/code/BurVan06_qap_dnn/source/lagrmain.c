
/* Bring in the CPLEX function declarations and the C library 
   header file stdio.h with the include of cplex.h. */

#include "cplex.h"
#include <stdlib.h>
#include <string.h>

#include <stdio.h>


#include <sys/times.h>
#include <unistd.h>

#include "create.h"

#include "globalmain.h"



 
int run_subgrad(CPXENVptr, CPXLPptr *, CPXLPptr *);
 
int main (
           int nArgs,
           char *arg[]
           )
{
   CPXENVptr     env = NULL;
   CPXLPptr      lp[3];
   CPXLPptr      qp[3];

   int           status, k;
   int clocks_per_second = 0;
   clocks_per_second = sysconf( _SC_CLK_TCK );
   double t0, t;
   struct tms timearr; clock_t tres;
   
   
   if (nArgs != 4)
     {
       fprintf(stderr, "Usage: lagr psdoff/psdon type input\nwhere type is one of {erdos, stable, qap, mps}\n\tIf type is erdos, then input must be a positive integer\n\tIf type is stable, input is a filename\n\tIf type is qap, input is a filename\n");
       exit(0);
     }




   /* Initialize the CPLEX environment */
   env = CPXopenCPLEX (&status);

   /* If an error occurs, the status value indicates the reason for
      failure.  A call to CPXgeterrorstring will produce the text of
      the error message.  Note that CPXopenCPLEX produces no output,
      so the only way to see the cause of the error is to use
      CPXgeterrorstring.  For other CPLEX routines, the errors will
      be seen if the CPX_PARAM_SCRIND indicator is set to CPX_ON.  */

   if ( env == NULL ) {
      char  errmsg[1024];
      fprintf (stderr, "Could not open CPLEX environment.\n");
      CPXgeterrorstring (env, status, errmsg);
      fprintf (stderr, "%s", errmsg);
      goto TERMINATE;
   }

   /* Turn on output to the screen */

   status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
   if ( status ) {
      fprintf (stderr, 
               "Failure to turn on screen indicator, error %d.\n", status);
      goto TERMINATE;
   }

  status = CPXsetintparam(env, CPX_PARAM_SIMDISPLAY, 0);
  status = CPXsetintparam(env, CPX_PARAM_ADVIND, 1);

	
   /* Create the problems. */
  for(k = 0; k < 3; k++)
    {
      lp[k] = CPXcreateprob (env, &status, "lpsubprob");
  

      if ( lp[k] == NULL ) {
	fprintf (stderr, "Failed to create LP.\n");
      goto TERMINATE;
  }
     
    }

  for(k = 0; k < 3; k++)
    {
      qp[k] = CPXcreateprob (env, &status, "qpsubprob");
  

      if ( qp[k] == NULL ) {
	fprintf (stderr, "Failed to create QP.\n");
      goto TERMINATE;
  }
     
    }

  if (strcmp("psdon", arg[1]) == 0)
    {
      printf("Computing N+ operator\n");
      do_psd = 1;
      sigmawt = 1.0;
    }
  else if (strcmp("psdoff", arg[1]) == 0)
    {
      printf("Computing N operator\n");
      do_psd = 0;
      sigmawt = 0.0;
    }
  else
    {
      printf("Must choose psdon or psdoff as first argument, exiting...\n");
      goto TERMINATE;
    }

  isqap = 0;
  ismps = 0;
 
      if (strcmp("erdos", arg[2]) == 0)
	{
	  Z_VARS = 1;
	  read_erdos_data(arg[3]);
	  printf("Done reading in data\n");
	  status = create_erdos_subprob(env, lp, qp);
	  if (status)
	    {
	      fprintf(stderr, "Error creating subproblem lp\n");
	      goto TERMINATE;
	    }
	}
      else if (strcmp("stable", arg[2]) == 0)
	{
	  Z_VARS = 1;
	  read_stable_data(arg[3]);
	  printf("Done reading in stable set data\n");
	  status = create_stable_subprob(env, lp, qp);

	  if (status)
	    {
	      fprintf(stderr, "Error creating stable subproblem lp\n");
	      goto TERMINATE;
	    }	  
	}
      else if (strcmp("qap", arg[2]) == 0)
	{
	  Z_VARS = 0;
	  read_qap_data(arg[3]);
	  printf("done reading in qap data\n");
	  isqap = 1;
	  if (Z_VARS)
	    {
	      printf("Turn off Z vars for QAP\n");
	      goto TERMINATE;
	    }
	  status = create_qap_subprob(env, lp, qp);

	  if (status)
	    {
	      fprintf(stderr, "Error creating qap subproblem lp\n");
	      goto TERMINATE;
	    }	  	  
	}
      else if (strcmp("mps", arg[2]) == 0)
	{
	  Z_VARS = 1;
	  ismps = 1;
	  status = create_mps_subprob(arg[3], env, lp, qp);
	  if (status)
	    {
	      fprintf(stderr, "Error creating mps subproblem lp\n");
	      goto TERMINATE;
	    }	  	  
	}
      else
	{
	  fprintf(stderr, "Incorrect problem types in argument list\n");
	  goto TERMINATE;
	}

  if (status)
    {
      fprintf(stderr, "Error creating subproblem lp and qp\n");
      goto TERMINATE;
    }	  

  // Sam: Change #1
  status = CPXsetintparam(env, CPX_PARAM_QPMETHOD, 2);



   tres = times(&timearr); 
   t0 = timearr.tms_utime; 

   status = run_subgrad(env, lp, qp);

   tres = times(&timearr);
   t = (timearr.tms_utime-t0)/clocks_per_second;  
   // printf(" Total CPU Time: %.4f secs\n", t);

TERMINATE:

   /* Free up the problem as allocated by CPXcreateprob, if necessary */
       for(k = 0; k < 3; k++)
	 {
	   if ( lp[k] != NULL ) {
	     status = CPXfreeprob (env, &(lp[k]));
	     if ( status ) {
	       fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
	     }
             usleep(5000000); // Wait for CPLEX license to be freed.
	   }  
	 }

   

       for(k = 0; k < 3; k++)
	 {
	   if ( qp[k] != NULL ) {
	     status = CPXfreeprob (env, &(qp[k]));
	     if ( status ) {
	       fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
	     }
             usleep(5000000); // Wait for CPLEX license to be freed.
	   }  
	 }

   /* Free up the CPLEX environment, if necessary */

   if ( env != NULL ) {
      status = CPXcloseCPLEX (&env);
      usleep(5000000); // Wait for CPLEX license to be freed.

      /* Note that CPXcloseCPLEX produces no output,
         so the only way to see the cause of the error is to use
         CPXgeterrorstring.  For other CPLEX routines, the errors will
         be seen if the CPX_PARAM_SCRIND indicator is set to CPX_ON. */

      if ( status ) {
         char  errmsg[1024];
         fprintf (stderr, "Could not close CPLEX environment.\n");
         CPXgeterrorstring (env, status, errmsg);
         fprintf (stderr, "%s", errmsg);
      }
   }
     
   /* Free up the problem data arrays, if necessary. */

 
   return (status);

}  /* END main */




/* This simple routine frees up the pointer *ptr, and sets *ptr to NULL */


void free_and_null (char **ptr)
{
   if ( *ptr != NULL ) {
      free (*ptr);
      *ptr = NULL;
   }
} /* END free_and_null */  



