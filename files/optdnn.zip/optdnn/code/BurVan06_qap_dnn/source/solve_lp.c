
#include "cplex.h"
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "globalsub.h"

extern double *tempc;
extern int *temp_indices;

/* function computes objective for y^0 lp subproblem*/
int set_y0_lp_obj(CPXENVptr env, CPXLPptr lp, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S)
{
  int i, j, status;

  // N oper plain Lag w/o Z
  if (isqap)  //If QAP, then original objective is different
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = sym_lambda[0][j - 1] - diag_lambda[j];
    }
  else if (ismps)
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = mps_obj[j] + sym_lambda[0][j - 1] - diag_lambda[j];
    }
  else
    {
      tempc[0] = 0.0;
      for(j = 1; j <= n; j++) tempc[j] = 1 + sym_lambda[0][j - 1] - diag_lambda[j];
    }

  // N oper plain Lag w/ Z
  if(Z_VARS == 1)
    {
      for(i = 1; i <= n; i++) tempc[0] += -z_lambda[i][0];
      for(j = 1; j <= n; j++) for(i = 1; i <= n; i++) tempc[j] += -z_lambda[i][j];
    }

  // N+ oper plain Lag
  for(i = 0; i <= n; i++) tempc[i] += S[updiag_index(0,i)];

  status = CPXchgobj(env, lp, n+1, temp_indices, tempc);

  return(status);

}

/*Computes objective for y^i lp subproblem*/
int set_yi_lp_obj(CPXENVptr env, CPXLPptr lp, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S, int i)
{
  int j, k, l, status;
  int p, q;  //Original x_{pq} corresponding to row Y_{i.}

  // N oper plain Lag w/o Z
  tempc[0] = -sym_lambda[0][i-1];
  for(j = 1; j <= n; j++)
    if(j == i)      tempc[j] = diag_lambda[j];
    else if (i < j) tempc[j] = sym_lambda[i][j-(i+1)];
    else            tempc[j] = -sym_lambda[j][i-(j+1)];

//If this is relaxation of QAP then index Y_{pq},{kl} has original coefficient 
// a_{pk} b_{ql}
    if (isqap)  
      { //First compute p and q (Note that i >= 1)
	p = (i-1)/qap_n;
	q = (i-1)%qap_n;
	
	for(k = 0; k < qap_n; k++)
	  for(l = 0; l < qap_n; l++)
	    {
	      tempc[1+square_index(k,l,qap_n)] += -a[p][k]*b[q][l];
	    }
      }


  // N oper plain Lag w/ Z
  if(Z_VARS == 1)
    {
      tempc[0] += z_lambda[i][0];
      for(j = 1; j <= n; j++) tempc[j] += z_lambda[i][j];
    }

  // N+ oper plain Lag
  for(j = 0; j <= n; j++)
    if(i <= j) tempc[j] += S[updiag_index(i,j)];
    else       tempc[j] += S[updiag_index(j,i)];


 
  status = CPXchgobj(env, lp, n+1, temp_indices, tempc);


  return(status);
}

/*Computes objective for z^i lp subproblem*/
int set_zi_lp_obj(CPXENVptr env, CPXLPptr lp, double **sym_lambda, double *diag_lambda, double **z_lambda, int i)
{
  int j, status;


  tempc[0] = z_lambda[i][0];
  for(j = 1; j <= n; j++)
    tempc[j] = z_lambda[i][j];

  
  status = CPXchgobj(env, lp, n+1, temp_indices, tempc);



  return(status);
}





/*Solves LP subproblem and puts solution in vector soln*/
int solve_lp_subprob(CPXENVptr env, CPXLPptr lp, double *soln, double *objval)
{
  int status, lpstat;


   

  status = CPXprimopt(env, lp);
  if (status)
    {
      fprintf(stderr, "Problem solving a subproblem\n");
      return(status);
    }
  
  lpstat = CPXgetstat(env,lp);
  if (lpstat != CPX_STAT_OPTIMAL)
    {
      fprintf(stderr, "Incorrect lpstat in subproblem\n");
      return(1);
    }  
  


  status = CPXgetobjval (env, lp, objval);
  if (status)
    {
      fprintf(stderr, "Problem getting obj val of subproblem\n");
      return(status);
    }

  if (soln != NULL)
    {
      status = CPXgetx(env, lp, soln, 0, n); 
      if (status)
	{
	  fprintf(stderr, "Problem getting x values of subproblem\n");
	  return(status);
	}
    }

  return(0);
}

int compute_upper_bnd(CPXENVptr env, CPXLPptr *lp, double *curval, double **sym_lambda, double *diag_lambda, double **z_lambda, double *S)
{
  int i, status;
  double tempval;
//  char tempname[50];

  *curval = 0;

  status = set_y0_lp_obj(env, lp[0], sym_lambda, diag_lambda, z_lambda, S);
  if (status) {fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status);}
  //sprintf(tempname, "lp0.lp");
  //CPXwriteprob(env, lp, tempname, NULL);
  status = solve_lp_subprob(env, lp[0], NULL, &tempval);
  if (status) {fprintf(stderr, "Problem solving y^0 LP obj\n"); return(status);}

  *curval += tempval;

  for(i = 1; i <= n; i++)
    {
      status = set_yi_lp_obj(env, lp[1], sym_lambda, diag_lambda, z_lambda, S, i);
      if (status) {fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status);}
      //sprintf(tempname, "lp%d.lp", i);
      //CPXwriteprob(env, lp, tempname, NULL);
      status = solve_lp_subprob(env, lp[1], NULL, &tempval);
      if (status) {fprintf(stderr, "Problem solving y^0 LP obj\n"); return(status);}

      *curval += tempval;

      if(Z_VARS == 1)
        {
          status = set_zi_lp_obj(env, lp[2], sym_lambda, diag_lambda, z_lambda, i);
          if (status) {fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status);}

          status = solve_lp_subprob(env, lp[2], NULL, &tempval);
          if (status) {fprintf(stderr, "Problem solving y^0 LP obj\n"); return(status);}

          *curval += tempval;
        }

    }

  return(0);
}
