#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "globalsub.h"


void read_stable_data(char *inputname)
{
FILE *infile;
int i, j;
int ret;

                                                                                        
  infile = fopen(inputname, "r");
                                                                                        
  if (infile == NULL) {
    fprintf(stderr, "Error getting file\n");
    exit(0);
  }
                                                                                        
  ret = fscanf(infile, " %d ", &n);
                                                                                        
  A = (char **) calloc(n, sizeof(char *));
                                                                                        
  for(m = 0, i = 0; i < n; i++)
    {
                                                                                        
      A[i] = (char *) calloc(n, sizeof(char));
                                                                                        
      for(j = 0; j < n; j++)
        {
          ret = fscanf(infile, " %c", &(A[i][j]));
          if (A[i][j] == '1') 
            m++;
        }
    }
	
  m = m/2;
	
  fclose(infile);
  
}


void read_erdos_data(char *inputname)
{

 n = atoi(inputname);

}


void read_qap_data(char *inputname)
{
  FILE *infile;

  int i, j;
  int ret;

  infile = fopen(inputname, "r");
                                                                                        
  if (infile == NULL) {
    fprintf(stderr, "Error getting file\n");
    exit(0);
  }
                                                                                        
                                                                                        
  ret = fscanf(infile, " %d ", &qap_n);

  a = (int **) calloc(qap_n, sizeof(int*));
  b = (int **) calloc(qap_n, sizeof(int*));
  
  for(i = 0; i < qap_n; i++)
    {
                                                                                        
      a[i] = (int *) calloc(qap_n, sizeof(int));
                                                                                        
      for(j = 0; j < qap_n; j++)
        {
          ret = fscanf(infile, " %d", &(a[i][j]));
        }
    }

//   for(i = 0; i < qap_n; i++) {
//     for(j = 0; j < qap_n; j++)
//       printf("%d ", a[i][j]);
//     printf("\n");
//   }
  
  for(i = 0; i < qap_n; i++)
    {
                                                                                        
      b[i] = (int *) calloc(qap_n, sizeof(int));
                                                                                        
      for(j = 0; j < qap_n; j++)
        {
          ret = fscanf(infile, " %d", &(b[i][j]));
        }
    }

//   for(i = 0; i < qap_n; i++) {
//     for(j = 0; j < qap_n; j++)
//       printf("%d ", b[i][j]);
//     printf("\n");
//   }

  fclose(infile);


}
