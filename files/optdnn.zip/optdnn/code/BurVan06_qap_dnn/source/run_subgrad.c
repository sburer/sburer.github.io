#include "cplex.h"
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "globalsub.h"

#include "compute.h"
#include "solve_lp.h"
#include "solve_qp.h"

#include <sys/times.h>
#include <unistd.h>

double compute_primalbnd(double **);

void free_subgradarrays(double **, double **, double **, double *, double **, double **, double *, double **);

int run_subgrad(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, iter, status;

  double bestval, tempval, last_upper_bound, norm_viol;

  /*Y and Z variable matrices*/
  double **Y, **Z; 

  /*dual multipliers*/
  double **sym_lambda, *diag_lambda, **z_lambda;

  /*Search direction*/
  double **sym_dir, *diag_dir, **z_dir;

  //It's important that S only stores the upper diagonal of the dual variable
  //and that it's stored in column major form for interfacing with LAPACK/BLAS
  double *S, *S_dir;
  double *U;

  /*Misc variables*/
  double sigma, curval;

  int clocks_per_second = 0;
  clocks_per_second = sysconf( _SC_CLK_TCK );
  double t0, t;
  struct tms timearr; clock_t tres;

  int last_change = 0;
  double sigma_power = 1.0;


  //printf("isqap = %d, qap_n = %d, n = %d, m = %d\n\n", isqap, qap_n, n, m); 


  /*Allocate memory for primal and dual variables and directions, initialize duals*/
  Y = (double **) calloc(n+1, sizeof(double *));
  if(Z_VARS == 1) Z = (double **) calloc(n+1, sizeof(double *)); else Z = NULL; 


  sym_lambda = (double **) calloc(n+1, sizeof(double *));
  diag_lambda = (double *) calloc(n+1, sizeof(double));
  if(Z_VARS == 1) z_lambda = (double **) calloc(n+1, sizeof(double *)); else z_lambda = NULL;


  sym_dir = (double **) calloc(n+1, sizeof(double *));
  diag_dir = (double *) calloc(n+1, sizeof(double));
  if(Z_VARS == 1) z_dir = (double **) calloc(n+1, sizeof(double *)); else z_dir = NULL;


  S = (double *) calloc((n+2)*(n+1)/2, sizeof(double));
  S_dir = (double *) calloc((n+1)*(n+2)/2, sizeof(double));

  U = (double *) calloc((n+2)*(n+1)/2, sizeof(double));


  for(i = 0; i <= n; i++)
    {
      /*we only need to store the upper triangle for sym_lambda (i < j)*/
      /*Need to be careful later when accessing this array*/
      /* \lambda_{ij}^{sym} is in sym_lambda[i][j - (i + 1)] for i < j*/
      if (n - i > 0)
	{
	  sym_lambda[i] = (double *) calloc(n-i, sizeof(double));
	  sym_dir[i] = (double *) calloc(n-i, sizeof(double));
	}
      else
	{
	  sym_lambda[i] = NULL;
	  sym_dir[i] = NULL;
	}
	for(j = 0; j < n-i; j++) sym_lambda[i][j] = 0.0; 
	
	  
	
      Y[i] = (double *) calloc(n+1, sizeof(double));
      if (i > 0)
	{
	  
          diag_lambda[i] = 0.0;

          if(Z_VARS == 1) {

  	    Z[i] = (double *) calloc(n+1, sizeof(double));

	    z_lambda[i] = (double *) calloc(n+1, sizeof(double));
	    z_dir[i] = (double *) calloc(n+1, sizeof(double));
	  
	    for(j = 1; j <= n; j++) z_lambda[i][j] = 0.0;

          }
	}
    } 

   // Finish allocating PSD-constraint dual variables, etc.
  for(i = 0; i <= n; i++)
    for(j = i; j <= n; j++)
      {
	S[updiag_index(i,j)] = 0;
        U[updiag_index(i,j)] = 0;
      }

  /*Init some vectors used in compute.c*/
  init_objarrays();
  
  sigma = 0.1;
  sigma_reset_flag = 1;

  //  num_psd_cycles = 1;
  //  num_qp_cycles = NUM_CYCLES;
  num_psd_cycles = 1;
  num_qp_cycles = 1;

  last_upper_bound = 1.0e10;
  norm_viol = NORM_VIOL;

  bestval = 1.0e10;

  /*Begin Subgradient*/
  tres = times(&timearr); 
  t0 = timearr.tms_utime; 
  for(iter = 1; iter <= ITERLIM; iter++)
    {

//       printf("sigma = %f\n", sigma);

      status = solve_auglagr(env, qp, &curval, sigma, Y, Z, sym_lambda, diag_lambda, z_lambda, S, U);
      if (status) { fprintf(stderr, "Problem solving in solve_auglagr()\n"); goto END_RUN_SUBGRAD;}

      curr_infeas = compute_dir(Y,Z,U,sym_dir,diag_dir,z_dir,S_dir);

      if (curr_infeas < norm_viol) break;

      update_duals(sigma, sigmawt*sigma, sym_lambda, diag_lambda, z_lambda, S, sym_dir, diag_dir, z_dir, S_dir);

      if ((iter > 0) && (SIGMA_FACTOR != 1.0) && (iter % SIGMA_FREQ == 0))
	{
//          printf("Updating sigma\n");
	  sigma *= pow(SIGMA_FACTOR, sigma_power);
	  sigma_reset_flag = 1;
          if(sigma > 1.0e+9) {
            printf("Sigma too large!\n"); fflush(stdout);
            goto END_RUN_SUBGRAD;
          }
 
	}


      if (iter % UB_FREQ == 0)
        {
	  status = compute_upper_bnd(env, lp, &curval, sym_lambda, diag_lambda, z_lambda, S);
	  if (status) {fprintf(stderr, "Problem computing UB\n"); goto END_RUN_SUBGRAD;}
	  tres = times(&timearr);
	  t = (timearr.tms_utime-t0)/clocks_per_second;

	  tempval = compute_primalbnd(Y);
	  
          if(curval < bestval)
          {
            bestval = curval;
            last_change = iter;
          }
          else {
            if(iter - last_change >= n)
            {
              // Being more aggressive with sigma
              last_change = iter;
              sigma_power += 1.0;
            }
          }

          if (iter % (10*UB_FREQ) == 0) {
            printf("================================================================================================================================\n"); 
            printf("ITER    CURRENT QAP BOUND (neg)      BEST QAP BOUND (neg)         CURRENT PRIMAL VALUE         INFEAS   SIGMA    TIME (sec)\n");
            printf("================================================================================================================================\n");
          }
	  //printf("\t\t#######Current bounds: %.10f  %.10f (t = %.4f) (viol = %.1e)\n", tempval, curval, t, curr_infeas);
          printf("%6d  % .20e  % .20e  % .20e  %.1e  %.1e  %.10e\n", iter, curval, bestval, tempval, curr_infeas, sigma, t); fflush(stdout);

        }

        


    }  /*End subgradient iterations*/


  tempval = compute_primalbnd(Y);

  status = compute_upper_bnd(env, lp, &curval, sym_lambda, diag_lambda, z_lambda, S);
  if (status) {fprintf(stderr, "Problem computing UB\n"); goto END_RUN_SUBGRAD;}
  // printf("\n\n\t\t######Current upper bound: %.10f\n\n", curval);
  if(curval < bestval) bestval = curval;
  tres = times(&timearr);
  t = (timearr.tms_utime-t0)/clocks_per_second;
  printf("%6d  %.20e  %.20e  %.20e  %.1e  %.1e  %.10e\n", iter, curval, bestval, tempval, curr_infeas, sigma, t); fflush(stdout);
  //printf("\n\nCurrent Lower bound: %.10f\n\n", curval);
  //printf("Algorithm stopped at iteration: %d\n", iter);
  
  printf("================================================================================================================================\n"); 
  printf("ITER    CURRENT QAP BOUND (neg)      BEST QAP BOUND (neg)         CURRENT PRIMAL VALUE         INFEAS   SIGMA    TIME (sec)\n");
  printf("================================================================================================================================\n");

  END_RUN_SUBGRAD:

  finish_objarrays();

  free_subgradarrays(Y, Z, sym_lambda, diag_lambda, z_lambda, sym_dir, diag_dir, z_dir);
  free(S);
  free(S_dir);
  free(U);


  return(status);
}





void free_subgradarrays(double **Y, double **Z, double **sym_lambda, double *diag_lambda, double **z_lambda, double **sym_dir, double *diag_dir, double **z_dir)
{
  int i;

  free(diag_lambda);
  free(diag_dir);

  for(i = 0; i <= n; i++)
    {
     
      free(Y[i]);
      free(sym_lambda[i]);
      free(sym_dir[i]);
      if (i > 0 && Z_VARS == 1)
	{
	      
	  free(Z[i]);
	  free(z_lambda[i]);
	  free(z_dir[i]);
	}

    }
  free(Y);
  if(Z_VARS == 1) { free(Z); free(z_lambda); free(z_dir); }
  free(sym_lambda);
  free(sym_dir);
}



double compute_primalbnd(double **Y)
{
  int i, j, k, l;
  double tempval;

  if (isqap == 0)
    {
      tempval = 0;
      for(j = 1; j <= n; j++) tempval += Y[0][j]; 
    }
  else
    {
      tempval = 0;
      for(i = 0; i < qap_n; i++)
	for(j = 0; j < qap_n; j++)
	  for(k = 0; k < qap_n; k++)
	    for(l = 0; l < qap_n; l++)
	      {
		tempval += -a[i][j]*b[k][l]*Y[0][1+square_index(i,j,qap_n)]*Y[0][1+square_index(k,l,qap_n)];
	      }
    }

  return(tempval);



}

