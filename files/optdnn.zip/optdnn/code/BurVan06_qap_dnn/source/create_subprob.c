#include "cplex.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "globalsub.h"
#define MAXVAL 55
#define SIGMA 30


int create_mps_subprob(char *mpsinput, CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, k, status, objsen;
  CPXLPptr templp;
  char *ctype;

  double *ub, *lb;
  double *rmatval, rhs;
  char sense;
  int rmatbeg, *rmatind, surplus, nzcnt;
  double y00lb;
  char y00bdtype;
 
  double objval;

  templp = CPXcreateprob (env, &status, "tempip");

  status = CPXreadcopyprob(env, templp, mpsinput, NULL);
  if (status)
    {
      fprintf(stderr, "Problem reading mps file\n");
      return(1);
    }

  n = CPXgetnumcols(env, templp);
  m = CPXgetnumrows(env, templp);

  ctype = (char *) calloc(n, sizeof(char));

  status = CPXgetctype(env, templp, ctype, 0, n - 1);
  if (status)
    {
      fprintf(stderr, "Problem getting column types\n");
      return(1);
    }

  for(i = 0; i < n; i++)
    if (ctype[i] != 'B')
      {
	fprintf(stderr, "Not all variables are binary");
	return(1);
      }

  mps_obj = (double *) calloc(n+1, sizeof(double));
  ub = (double *) calloc(n+1, sizeof(double));
  lb = (double *) calloc(n+1, sizeof(double));
  
  mps_obj[0] = 0;
  lb[0] = 0.0;
  ub[0] = 1.0;
  status = CPXgetobj(env, templp, mps_obj+1,0,n-1);
  if (status)
    {
      fprintf(stderr, "Problem getting obj\n");
      return(1);
    }
  objsen = CPXgetobjsen(env, templp);

  for(i = 1; i <=n ; i++)
    {
      if (objsen == CPX_MIN)
	mps_obj[i] *= -1.0; 
      lb[i] = 0.0;
      ub[i] = 1.0;
    }

  CPXchgobjsen(env, lp[0], CPX_MAX);

  status = CPXnewcols (env, lp[0], n+1, mps_obj, lb, ub, NULL, NULL);
  if (status)
    {
      fprintf(stderr, "Error adding new columns\n");
      return(1);
    }      

  rmatval = (double *) calloc(n+1, sizeof(double));
  rmatind = (int *) calloc(n+1, sizeof(int));

  for(i = 0; i < m; i++)
    {
      status = CPXgetrows(env, templp, &nzcnt, &rmatbeg, rmatind, rmatval, n+1, &surplus, i, i);
      if (status)
	{
	  fprintf(stderr, "Problem getting rows from mps file\n");
	  return(1);
	}
      for(j = 0; j < nzcnt; j++)
	rmatind[j] += 1;

      status = CPXgetrhs(env, templp, &rhs, i, i);
      if (status)
	{
	  fprintf(stderr, "Problem getting rhs from mps file\n");
	  return(1);
	}
      status = CPXgetsense(env, templp, &sense, i,i);
      if (status)
	{
	  fprintf(stderr, "Problem getting sense from mps file\n");
	  return(1);
	}
      rmatind[nzcnt] = 0;
      rmatval[nzcnt] = -1.0*rhs;
      nzcnt++;
      rhs = 0.0;

      status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status)
	{
	  fprintf(stderr, "Problem adding rows from mps\n");
	  return(1);
	}
    }


  for(i = 1; i <= n; i++)
    {
      m++;
      rmatbeg = 0;
      rhs = 0.0;
      sense = 'L';
      nzcnt = 2;
      rmatind[0] = i;
      rmatval[0] = 1.0;
      rmatind[1] = 0;
      rmatval[1] = -1.0;
      status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status)
	{
	  fprintf(stderr, "Problem adding rows from mps\n");
	  return(1);
	}

    }
      
  
  for(k = 1; k < 3; k++)
    {
      lp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to other lp's\n"); 
      return(1);
      }
    }  
  
  for(k = 0; k < 3; k++)
    {
      qp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to qp\n"); return(1);}

      status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
      if (status) { fprintf(stderr, "Problem changing to qp\n"); return(1);}
      
    }

  // Change y00 lower bound to 1
  i = 0;
  y00lb = 1.0;
  y00bdtype = 'L';
  
  status = CPXchgbds(env, lp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); return(1);}
  status = CPXchgbds(env, qp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); return(1);}
  
  
  status = CPXprimopt(env, lp[0]);
  if (status) 
    {
      fprintf(stderr, "Problem solving lprelaxation\n");
      return(1);
    }
  CPXgetobjval(env, lp[0], &objval);
  printf("LP relaxation objval = %.5f\n", objval);

 

  return(0);
}



int create_stable_subprob(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, nzr, status, rowcnt;
  int *rmatbeg, *rmatind;
  double *obj, *rhs, *rmatval, *lb, *ub;
  char *sense, **colname;
  int k;
  double y00lb;
  char y00bdtype;
 
  obj = (double *) calloc(n+1, sizeof(double));
  lb = (double *) calloc(n+1, sizeof(double));
  ub = (double *) calloc(n+1, sizeof(double));
  colname = (char **) calloc(n+1, sizeof(char *));


  rhs = (double *) calloc(m, sizeof(double));
  sense = (char *) calloc(m, sizeof(char));

  /*For each edge there are 3 nonzeroes xi + xj <= x_0*/
  rmatval = (double *) calloc(3*m, sizeof(double)); 

  rmatbeg = (int *) calloc(m, sizeof(int)); 
  /*beginning index of each row in rmatind and rmatval*/
 
  rmatind = (int *) calloc(3*m, sizeof(int));  /*column index of each nonzero*/
  

  for(i = 0; i <= n; i++)
    {
      colname[i] = (char *) calloc(MAX_STRING, sizeof(char));
      sprintf(colname[i], "x%d", i);
      lb[i] = 0.0;
      ub[i] = 1.0;
      obj[i] = 1.0;
    }



  CPXchgobjsen(env, lp[0], CPX_MAX); 

  
  status = CPXnewcols (env, lp[0], n+1, obj, lb, ub, NULL, colname);
  if (status)
    {
      fprintf(stderr, "Error adding new columns\n");
      goto END_CREATE_SUBPROB;
    }

  nzr = 0;
  rowcnt = 0;
  for(i = 1; i <= n; i++)
    {
      for(j = i+1; j <= n; j++)
	{
	  if (A[i-1][j-1] == '1')
	    {
	      sense[rowcnt] = 'L';
	      rhs[rowcnt] = 0;
	      rmatbeg[rowcnt++] = nzr;

	      rmatind[nzr] = i;
	      rmatval[nzr++] = 1.0;
	      rmatind[nzr] = j;
	      rmatval[nzr++] = 1.0;
	      rmatval[nzr] = -1.0;
	      rmatind[nzr++] = 0;
	    }
	}
    }
  if (rowcnt != m)
    {
      fprintf(stderr, "Problem with rowcnt\n");
      status = 1;
      goto END_CREATE_SUBPROB;
    }
  

  status = CPXaddrows(env, lp[0], 0, m, 3*m, rhs, sense, rmatbeg, rmatind, rmatval, NULL, NULL);
  if (status)
    {
      fprintf(stderr, "Problem with addrows\n");
      goto END_CREATE_SUBPROB;
    }
  for(k = 1; k < 3; k++)
    {
      lp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to other lp's\n"); 
      goto END_CREATE_SUBPROB;
      }
    }  
  
  for(k = 0; k < 3; k++)
    {
      qp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to qp\n"); goto END_CREATE_SUBPROB;}

      status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
      if (status) { fprintf(stderr, "Problem changing to qp\n"); goto END_CREATE_SUBPROB;}
      
    }

  // Change y00 lower bound to 1
  i = 0;
  y00lb = 1.0;
  y00bdtype = 'L';
  
  status = CPXchgbds(env, lp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}
  status = CPXchgbds(env, qp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}
  

 END_CREATE_SUBPROB:
  free(lb);
  free(ub);
  free(obj);
  free(sense);
  free(rhs);
  free(rmatind);
  free(rmatval);
  free(rmatbeg);
 
  return(status);

}

//////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

int create_erdos_subprob(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, k, status;
  //int i, j, k, nzr, status, rowcnt;
  int rmatbeg, rmatind[4];
  double *obj, rhs, rmatval[4], *lb, *ub;
  char sense, **colname;
  double y00lb;
  char y00bdtype;

  obj = (double *) calloc(n+1, sizeof(double));
  lb = (double *) calloc(n+1, sizeof(double));
  ub = (double *) calloc(n+1, sizeof(double));
  colname = (char **) calloc(n+1, sizeof(char *));
 
  

  for(i = 0; i <= n; i++)
    {
      colname[i] = (char *) calloc(MAX_STRING, sizeof(char));
      sprintf(colname[i], "x%d", i);
      lb[i] = 0.0;
      ub[i] = 1.0;
      obj[i] = 1.0;
    }
  obj[0] = 0.0;

  CPXchgobjsen(env, lp[0], CPX_MAX); 

  
  status = CPXnewcols (env, lp[0], n+1, obj, lb, ub, NULL, colname);
  if (status)
    {
      fprintf(stderr, "Error adding new columns\n");
      goto END_CREATE_SUBPROB;
    }


  sense = 'L';
  rhs = 0.0;
  rmatbeg = 0;
  m = 0;
  for(i = 1; i <= n; i++)
    {
      for(j = i+1; j <= n; j++)
	{
	  
	  if (( (int) fmod(i+j, 2) == 0) && ((i+j)/2 <= n))
	    {
	      m++;
	      rmatval[0] = -2.0;
	      rmatval[1] = 1.0;
	      rmatval[2] = 1.0;
	      rmatval[3] = 1.0;
	      rmatind[0] = 0;
	      rmatind[1] = i;
	      rmatind[2] = j;
	      rmatind[3] = (i+j)/2;
	      status = CPXaddrows(env, lp[0], 0, 1, 4, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
	      if (status)
		{
		  fprintf(stderr, "Problem adding a row\n");
		  goto END_CREATE_SUBPROB;
		}
	    }
	}
    }
   for(i = 1; i <= n; i++)                                                         
    { 
      m++;                                                                            
      rmatbeg = 0;                                                                
      rhs = 0.0;                                                                  
      sense = 'L';                                                                
      rmatind[0] = i;                                                             
      rmatval[0] = 1.0;                                                           
      rmatind[1] = 0;                                                             
      rmatval[1] = -1.0;                                                          
      status = CPXaddrows(env, lp[0], 0, 1, 2, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status)                                                                 
        {                                                                         
          fprintf(stderr, "Problem adding rows from mps\n");                      
          return(1);
        }                                                                         
                                                                                  
    }        
  for(k = 1; k < 3; k++)
    {
      lp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to other lp's\n"); 
      goto END_CREATE_SUBPROB;
      }
    }

  for(k = 0; k < 3; k++)
    {
      qp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to qp\n"); goto END_CREATE_SUBPROB;}

      status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
      if (status) { fprintf(stderr, "Problem changing to qp\n"); goto END_CREATE_SUBPROB;}
    }

  // Change y00 lower bound to 1
  i = 0;
  y00lb = 1.0;
  y00bdtype = 'L';
  
  status = CPXchgbds(env, lp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}
  status = CPXchgbds(env, qp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}

 END_CREATE_SUBPROB:
  free(lb);
  free(ub);
  free(obj);

 
  return(status);
}


int create_qap_subprob(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, k, nzr, status, colcnt, rowcnt;
  int *rmatbeg, *rmatind;
  double *obj, *rhs, *rmatval, *lb, *ub;
  char *sense, **colname;
  double y00lb;
  char y00bdtype;

  n = qap_n*qap_n;
  m = 2*qap_n;

  status = 0;
  colcnt = qap_n*qap_n+1;

  obj = (double *) calloc(colcnt, sizeof(double));
  lb = (double *) calloc(colcnt, sizeof(double));
  ub = (double *) calloc(colcnt, sizeof(double));
  colname = (char **) calloc(colcnt, sizeof(char *));

  rowcnt = 2*qap_n;
  m = 2*qap_n;
  nzr = 2*qap_n*(qap_n+1);

  rhs = (double *) calloc(rowcnt, sizeof(double));
  sense = (char *) calloc(rowcnt, sizeof(char));

  rmatval = (double *) calloc(nzr, sizeof(double)); 

  rmatbeg = (int *) calloc(rowcnt, sizeof(int)); 
  /*beginning index of each row in rmatind and rmatval*/
 
  rmatind = (int *) calloc(nzr, sizeof(int));  /*column index of each nonzero*/

  obj[0] = 0;
  lb[0] = 0.0;
  ub[0] = 1.0;
  colname[0] = (char *) calloc(MAX_STRING, sizeof(char));
  sprintf(colname[0], "x0");

  for(i = 0; i < qap_n; i++)
    {
      for(j = 0; j < qap_n; j++)
	{
	  colname[1+square_index(i,j,qap_n)] = (char *) calloc(MAX_STRING, sizeof(char));
	  sprintf(colname[1+square_index(i,j,qap_n)], "x(%d,%d)", i+1,j+1);
	  lb[1+square_index(i,j,qap_n)] = 0.0;
	  ub[1+square_index(i,j,qap_n)] = 1.0;
	  obj[1+square_index(i,j,qap_n)] = 1.0;
	}
    }

  status = CPXnewcols (env, lp[0], colcnt, obj, lb, ub, NULL, colname);
  if (status)
    {
      fprintf(stderr, "Error adding new columns\n");
      goto END_CREATE_SUBPROB;
    }

  nzr = 0;
  rowcnt = 0;
  for(i = 0; i < qap_n; i++)
    {
      sense[rowcnt] = 'E';
      rhs[rowcnt] = 0.0;
      rmatbeg[rowcnt++] = nzr;
      
      rmatind[nzr] = 0;
      rmatval[nzr++] = -1.0;

      for(j = 0; j < qap_n; j++)
	{
	  rmatind[nzr] = 1+square_index(i,j,qap_n);
	  rmatval[nzr++] = 1.0;
	}
    }
  for(j = 0; j < qap_n; j++)
    {
      sense[rowcnt] = 'E';
      rhs[rowcnt] = 0.0;
      rmatbeg[rowcnt++] = nzr;
      
      rmatind[nzr] = 0;
      rmatval[nzr++] = -1.0;

      for(i = 0; i < qap_n; i++)
	{
	  rmatind[nzr] = 1+square_index(i,j,qap_n);
	  rmatval[nzr++] = 1.0;
	}
    }




  if ((rowcnt != 2*qap_n) || (nzr != 2*qap_n*(qap_n+1)))
    {
      fprintf(stderr, "Problem with rowcnt or nzr\n");
      status = 1;
      goto END_CREATE_SUBPROB;
    }

  status = CPXaddrows(env, lp[0], 0, rowcnt, nzr, rhs, sense, rmatbeg, rmatind, rmatval, NULL, NULL);
  if (status)
    {
      fprintf(stderr, "Problem with addrows\n");
      goto END_CREATE_SUBPROB;
    }
  CPXchgobjsen(env, lp[0], CPX_MAX);


  for(k = 1; k < 3; k++)
    {
      lp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to other lp's\n"); 
      goto END_CREATE_SUBPROB;
      }
    }
  
  for(k = 0; k < 3; k++)
    {
      qp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to qp\n"); goto END_CREATE_SUBPROB;}

      status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
      if (status) { fprintf(stderr, "Problem changing to qp\n"); goto END_CREATE_SUBPROB;}
      
    }

  // Change y00 lower bound to 1
  i = 0;
  y00lb = 1.0;
  y00bdtype = 'L';
  
  status = CPXchgbds(env, lp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}
  status = CPXchgbds(env, qp[0], 1, &i, &y00bdtype, &y00lb);
  if (status) { fprintf(stderr, "Problem changing y00 bound\n"); goto END_CREATE_SUBPROB;}



 END_CREATE_SUBPROB:
  free(lb);
  free(ub);
  free(obj);
  free(sense);
  free(rhs);
  free(rmatind);
  free(rmatval);
  free(rmatbeg);
 
  return(status);
  

}
