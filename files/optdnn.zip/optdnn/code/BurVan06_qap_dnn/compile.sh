make clean
make
mv auglagr auglagr1
make clean
mv auglagr1 auglagr
