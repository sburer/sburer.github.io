#include "defs.h"
extern int n, m;  /*numer of nodes and edges*/
extern char **A; /*adjacency matrix*/

extern int **a, **b, isqap, qap_n;

extern int ismps;
extern double *mps_obj;

extern int rank;
extern int sigma_reset_flag;

extern int maxitcnt, minitcnt, numlpsolved, num0soln;
extern double avgitcnt;
extern int itcnt[1000];

extern int num_qp_cycles;
extern int num_psd_cycles;
extern double best_infeas;
extern double curr_infeas;
extern int do_psd;
extern double sigmawt;
extern int Z_VARS;
extern void dspev_();
extern void dsyevr_();
extern void dspr_();

//Index into array storing upper triangle of symmetric matrix for 0 <= i <= j <= n
#define updiag_index(i,j) (i + ((int) (j*(j+1)/2)) )


//Index into square matrix stored row-wise for 0 <= i <= numcols, 0 <= j <= numcols
#define square_index(i,j,numcols)  ((i*(numcols)) + j)
