void init_objarrays();
void finish_objarrays();

double compute_dir(double **, double **, double *, double **, double *, double **, double *);
void update_duals(double, double, double **, double *, double **, double *, double **, double *, double **, double *);
double compute_norm_viol(double **, double **);
