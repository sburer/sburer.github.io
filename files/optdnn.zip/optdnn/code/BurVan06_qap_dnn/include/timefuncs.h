void wallclock(double *);

