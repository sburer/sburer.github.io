int compute_upper_bnd(CPXENVptr, CPXLPptr *, double *, double **, double *, double **, double *);
