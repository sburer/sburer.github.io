int solve_auglagr(CPXENVptr, CPXLPptr *, double *, double, double **, double **, double **, double *, double **, double *, double *);
