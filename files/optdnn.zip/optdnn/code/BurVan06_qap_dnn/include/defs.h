#define MAX_STRING 10
#define MY_EPS 0.000001



// ITERLIM set at 6000 b/c we expect at least one order of magnitude
// every 1000 iterations
#define ITERLIM 6000

// Following is so sigma increases by a factor of 10 every 500 iters
#define SIGMA_FACTOR 1.58489319246111
#define SIGMA_FREQ 100

#define NUM_CYCLES 1
#define NORM_VIOL 1e-6

#define UB_FREQ 25

#define mymax(A, B) ((A) > (B) ? (A) : (B))
#define mymin(A, B) ((A) < (B) ? (A) : (B))


