#include "defs.h"
int n, m;  /*numer of nodes and edges*/
char **A;  /*adjacency matrix*/

int **a, **b, isqap, qap_n;

int ismps;
double *mps_obj;

int rank;
int sigma_reset_flag;

int maxitcnt, minitcnt, numlpsolved, num0soln;
double avgitcnt;
int itcnt[1000];

int num_qp_cycles;
int num_psd_cycles;
double best_infeas;
double curr_infeas;
int do_psd;
double sigmawt;
int Z_VARS;
