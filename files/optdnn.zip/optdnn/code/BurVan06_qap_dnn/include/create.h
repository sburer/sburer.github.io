int create_stable_subprob(CPXENVptr, CPXLPptr *, CPXLPptr *);
int create_erdos_subprob(CPXENVptr, CPXLPptr *, CPXLPptr *);
int create_qap_subprob(CPXENVptr, CPXLPptr *, CPXLPptr *);
int create_mps_subprob(char *, CPXENVptr, CPXLPptr *, CPXLPptr *);

void read_stable_data(char *);
void read_erdos_data(char *);
void read_qap_data(char *);
