#include "all.h"

int create_qp_subprob(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, k, nzcnt, rmatbeg, status;
  double rhs;
  char sense;
  int *rmatind;
  double *rmatval;

  // Make sure sense of obj is maximization
  CPXchgobjsen(env, lp[0], CPX_MAX); 

  // Create new columns in LP problem (with default obj and lower bounds, set to 0)
  status = CPXnewcols (env, lp[0], n+1, NULL, NULL, NULL, NULL, NULL);
  if (status) { fprintf(stderr, "Error adding new columns\n"); return(1); }

  // Upper bound 0-th variable by 1
  // (this assumes data (A,b) scaled so that each xj <= 1)
  // (also assumes each yi and zj <= 1)
  mychgbds(env, lp[0], 0, 1.0, 'U');

  // Add rows corresponding to Ax <= x0 b

  // Setup structures for adding rows
  rmatval = (double *) calloc(n+1, sizeof(double));
  rmatind = (int *)    calloc(n+1, sizeof(int));

  // Some constants that will stay fixed row to row
  rmatbeg = 0;
  rhs     = 0.0;
  sense   = 'L';

  for(i = 0; i < m; i++) {

    nzcnt = 0;

    rmatind[nzcnt]   = 0;
    rmatval[nzcnt++] = -qpb[i];

    for(j = 0; j < n; j++) {
      if(fabs(qpA[j*m + i]) > 1.0e-15) {
        rmatind[nzcnt]   = j+1; // shift +1 to allow for x0
        rmatval[nzcnt++] = qpA[j*m + i];
      }
    }

    status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
    if (status) { fprintf(stderr, "Problem adding rows for qp\n"); return(1); }

  }

  free(rmatval); rmatval = NULL;
  free(rmatind); rmatind = NULL;

  // If KKTLVL = 0, just plain copy first LP to second and third
  if(KKTLVL == 0) {
    for(k = 1; k < 3; k++) {
      lp[k] = CPXcloneprob(env, lp[0], &status);
      if (status) { fprintf(stderr, "Problem copying to other lp's\n"); return(1); }
    }
  }

  // If KKTLVL > 0, do additional work
  if(KKTLVL > 0) {

    // If KKTLVL == 1, first copy lp[0] to second and third LPs
    if(KKTLVL == 1) {
      for(k = 1; k < 3; k++) {
        lp[k] = CPXcloneprob(env, lp[0], &status);
        if (status) { fprintf(stderr, "Problem copying to other lp's\n"); return(1); }
      }
    }

    // Change lp[0] appropriately

    // add m+n new variables (with default obj, lower bounds, upper bounds)
    status = CPXnewcols (env, lp[0], m+n, NULL, NULL, NULL, NULL, NULL);
    if (status) { fprintf(stderr, "Error adding new columns\n"); return(1); }

    // add new constraints
    // First n constraints form A'y - z = Qx + c
    // Last 2 constraints form e'y <= yBAR and e'z <= zBAR (or e'y <= x0 yBAR and e'z <= x0 zBAR)
    // y scaled by yBAR and z scaled by zBAR

    rmatval = (double*)calloc(n+m+2, sizeof(double)); // n+m+1 b/c at most n from Qi, m from Ai, 1 from -Ii , 1 from x0 (KKTLVL = 2)
    rmatind = (int*)   calloc(n+m+2, sizeof(int));

    // Some constants that will stay fixed row to row
    rmatbeg = 0;
    rhs     = 0.0;
    sense   = 'E';

    for(i = 0; i < n; i++) {

      nzcnt = 0;

      rmatind[nzcnt] = 0;
      rmatval[nzcnt++] = -qpc[i];

      for(j = 0; j < n; j++) {
        if(fabs(qpQ[i*n + j]) > 1.0e-15) {
          rmatind[nzcnt]   = j+1; // shift +1 to allow for x0
          rmatval[nzcnt++] = -qpQ[i*n + j];
        }
      }

      for(j = 0; j < m; j++) {
        if(fabs(qpA[i*m + j]) > 1.0e-15) {
          rmatind[nzcnt]   = n+1 + j;
          rmatval[nzcnt++] = qpA[i*m + j]*yBAR;
        }
      }

      rmatind[nzcnt]   = n+1 + m + i;
      rmatval[nzcnt++] = -1.0*zBAR;

      status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status) { fprintf(stderr, "Problem adding rows for qp\n"); return(1); }

    }

	 //Two alternatives: Could add y_i <= x_0 and z_i <= x_0 
	 // (since the y and z vars are scaled)
	 // or could add
    // e'y <= yBAR or e'y <= x0 yBAR
	 if (AGG_YZ_BND) //turns on e'y <= ybar and e'z <= zbar constraints
	 {
		 rmatbeg = 0; sense = 'L'; rhs = yBAR/yBAR;
		 for(i = 0; i < m; i++) { rmatind[i] = n+1 + i; rmatval[i] = 1.0; }
		 if(KKTLVL == 2) { rmatind[m] = 0; rmatval[m] = -rhs; }
		 if(KKTLVL == 1) status = CPXaddrows(env, lp[0], 0, 1, m,   &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 
		 else            status = CPXaddrows(env, lp[0], 0, 1, m+1, NULL, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 

		 // e'z <= zBAR or e'z <= x0 zBAR
		 rmatbeg = 0; sense = 'L'; rhs = zBAR/zBAR;
		 for(i = 0; i < n; i++) { rmatind[i] = n+1+m + i; rmatval[i] = 1.0; }
		 if(KKTLVL == 2) { rmatind[n] = 0; rmatval[n] = -rhs; }
		 if(KKTLVL == 1) status = CPXaddrows(env, lp[0], 0, 1, n,   &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 
		 else            status = CPXaddrows(env, lp[0], 0, 1, n+1, NULL, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 
	 }
	 else // turns on y_i <= x_0 and z_i <= x_0 constraints
	 {
		 rmatbeg = 0; sense = 'L'; 
		 for(i = 0; i < m; i++)
		 {
			 rmatind[0] = n+1+i;
			 rmatval[0] = 1.0;
			 rmatind[1] = 0;
			 rmatval[1] = -1.0;
			 status = CPXaddrows(env, lp[0], 0, 1, 2, NULL, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 
		 }

		 for(i = 0; i < n; i++)
		 {
			 rmatind[0] = n+1+m+i;
			 rmatval[0] = 1.0;
			 rmatind[1] = 0;
			 rmatval[1] = -1.0;
			 status = CPXaddrows(env, lp[0], 0, 1, 2, NULL, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL); 
		 }


	 } //End AGG_YZ_BND

    // Now, have to set yBAR and zBAR equal to 1,
    // but save original values for Q*X + c'x = b'y constraint
    origyBAR = yBAR;
    origzBAR = zBAR;
    yBAR = zBAR = 1.0;
    
    free(rmatval); rmatval = NULL;
    free(rmatind); rmatind = NULL;

    // If KKTLVL == 2, now copy lp[0] to second and third LPs
    if(KKTLVL == 2) {
      for(k = 1; k < 3; k++) {
        lp[k] = CPXcloneprob(env, lp[0], &status);
        if (status) { fprintf(stderr, "Problem copying to other lp's\n"); return(1); }
      }
    }

    // NOTE: Upper bounds of 0 corresponding to diag(xz') = 0 will be
    // set dynamically before each subproblem is solved. (Is this best?)

  }

  // Copy each LP to each of the three QPs -- also change problem type to QP 
  for(k = 0; k < 3; k++) {

    qp[k] = CPXcloneprob(env, lp[k], &status);
    if (status) { fprintf(stderr, "Problem copying to qp\n"); return(1); }

    status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
    if (status) { fprintf(stderr, "Problem changing to qp\n"); return(1); }

  }

  // Change y00 lower bound to 1 for both LP and QP
  // This fixes this variable
  mychgbds(env, lp[0], 0, 1.0, 'L');
  mychgbds(env, qp[0], 0, 1.0, 'L');


  return(0);
}

int create_qp_subprob_getubs(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp)
{
  int i, j, k, nzcnt, rmatbeg, status;
  double rhs;
  char sense;
  int *rmatind;
  double *rmatval;

  // This subroutine assumes KKTLVL = 1
  // This subroutine assumes KKTLVL = 1
  // This subroutine assumes KKTLVL = 1

  // Make sure sense of obj is maximization
  CPXchgobjsen(env, lp[0], CPX_MAX); 

  // Create new columns in LP problem (with default obj and lower bounds, set to 0)
  status = CPXnewcols (env, lp[0], n+1, NULL, NULL, NULL, NULL, NULL);
  if (status) { fprintf(stderr, "Error adding new columns\n"); return(1); }

  // Upper bound 0-th variable by 1 (this assumes data (A,b) scaled so that each xj <= 1)
  mychgbds(env, lp[0], 0, 1.0, 'U');

  // Add rows corresponding to Ax <= x0 b

  // Setup structures for adding rows
  rmatval = (double *) calloc(n+1, sizeof(double));
  rmatind = (int *)    calloc(n+1, sizeof(int));

  // Some constants that will stay fixed row to row
  rmatbeg = 0;
  rhs     = 0.0;
  sense   = 'L';

  for(i = 0; i < m; i++) {

    nzcnt = 0;

    rmatind[nzcnt]   = 0;
    rmatval[nzcnt++] = -qpb[i];

    for(j = 0; j < n; j++) {
      if(fabs(qpA[j*m + i]) > 1.0e-15) {
        rmatind[nzcnt]   = j+1; // shift +1 to allow for x0
        rmatval[nzcnt++] = qpA[j*m + i];
      }
    }

    status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
    if (status) { fprintf(stderr, "Problem adding rows for qp\n"); return(1); }

  }

  free(rmatval); rmatval = NULL;
  free(rmatind); rmatind = NULL;

  for(k = 1; k < 3; k++) {
    lp[k] = CPXcloneprob(env, lp[0], &status);
    if (status) { fprintf(stderr, "Problem copying to other lp's\n"); return(1); }
  }

  // Change lp[0] appropriately

  // add m+n new variables (with default obj, lower bounds, upper bounds)
  status = CPXnewcols (env, lp[0], m+n, NULL, NULL, NULL, NULL, NULL);
  if (status) { fprintf(stderr, "Error adding new columns\n"); return(1); }

  // add new constraints
  rmatval = (double *) calloc(n+m+1, sizeof(double)); // n+m+1 b/c at most n from Qi, m from Ai, 1 from -Ii
  rmatind = (int *)    calloc(n+m+1, sizeof(int));

  // Some constants that will stay fixed row to row
  rmatbeg = 0;
  rhs     = 0.0;
  sense   = 'E';

  for(i = 0; i < n; i++) {

    nzcnt = 0;

    rmatind[nzcnt] = 0;
    rmatval[nzcnt++] = -qpc[i];

    for(j = 0; j < n; j++) {
      if(fabs(qpQ[i*n + j]) > 1.0e-15) {
        rmatind[nzcnt]   = j+1; // shift +1 to allow for x0
        rmatval[nzcnt++] = -qpQ[i*n + j];
      }
    }

    for(j = 0; j < m; j++) {
      if(fabs(qpA[i*m + j]) > 1.0e-15) {
        rmatind[nzcnt]   = n+1 + j;
        rmatval[nzcnt++] = qpA[i*m + j];
      }
    }

    rmatind[nzcnt]   = n+1 + m + i;
    rmatval[nzcnt++] = -1.0;

    status = CPXaddrows(env, lp[0], 0, 1, nzcnt, &rhs, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
    if (status) { fprintf(stderr, "Problem adding rows for qp\n"); return(1); }

  }

  free(rmatval); rmatval = NULL;
  free(rmatind); rmatind = NULL;

  // Copy each LP to each of the three QPs -- also change problem type to QP 
  for(k = 0; k < 3; k++) {

    qp[k] = CPXcloneprob(env, lp[k], &status);
    if (status) { fprintf(stderr, "Problem copying to qp\n"); return(1); }

    status = CPXchgprobtype(env, qp[k], CPXPROB_QP); 
    if (status) { fprintf(stderr, "Problem changing to qp\n"); return(1); }

  }

  // Change y00 lower and upper bounds to 1 for both LP and QP
  // This fixes this variable
  mychgbds(env, lp[0], 0, 1.0, 'L');
  mychgbds(env, qp[0], 0, 1.0, 'L');

  return(0);
}

int create_qp_subprob_bmAxBAR(CPXENVptr env, CPXLPptr lp)
{
  int i, j, nzcnt, rmatbeg, status;
  char sense;
  int *rmatind;
  double *rmatval;

  // We solve problems of the form
  //   max f'x
  //   st  Ax + s = b
  //        x, s >= 0

  // Make sure sense of obj is maximization
  CPXchgobjsen(env, lp, CPX_MAX); 

  // Create new columns in LP problem (with default obj and lower bounds, set to 0)
  status = CPXnewcols (env, lp, n+m, NULL, NULL, NULL, NULL, NULL);
  if (status) { fprintf(stderr, "Error adding new columns\n"); return(1); }

  // Add rows corresponding to Ax + s = b

  // Setup structures for adding rows
  rmatval = (double *) calloc(n+m, sizeof(double));
  rmatind = (int *)    calloc(n+m, sizeof(int));

  // Some constants that will stay fixed row to row
  rmatbeg = 0;
  sense   = 'E';

  for(i = 0; i < m; i++) {

    nzcnt = 0;

    rmatind[nzcnt]   = n + i;
    rmatval[nzcnt++] = 1.0;

    for(j = 0; j < n; j++) {
      if(fabs(qpA[j*m + i]) > 1.0e-15) {
        rmatind[nzcnt]   = j;
        rmatval[nzcnt++] = qpA[j*m + i];
      }
    }

    status = CPXaddrows(env, lp, 0, 1, nzcnt, qpb+i, &sense, &rmatbeg, rmatind, rmatval, NULL, NULL);
    if (status) { fprintf(stderr, "Problem adding rows for qp\n"); return(1); }

  }

  free(rmatval); rmatval = NULL;
  free(rmatind); rmatind = NULL;

  return(0);
}

