#include "all.h"

int      n;             // size of Q
int      m;             // rows in A
double  *qpQ    = NULL; // Q matrix
double  *qpc    = NULL; // c vector
double  *qpA    = NULL; // A matrix (column-major format)
double  *qpb    = NULL; // b vector
double  *ybar   = NULL;
double  *zbar   = NULL;

void alloc_qp_data(void)
{
  // Assumes that n has been specified (currently, this is inside read_qp_data)

  qpA  = (double *) calloc(m*n, sizeof(double));
  qpb  = (double *) calloc(m,   sizeof(double));
  qpc  = (double *) calloc(n,   sizeof(double));
  qpQ  = (double *) calloc(n*n, sizeof(double));
  if(KKTLVL == 0) {
    ybar = (double *) calloc(n, sizeof(double));
    zbar = (double *) calloc(n, sizeof(double));
  }
}

void dealloc_qp_data(void)
{
  if(qpQ  != NULL) { free(qpQ);  qpQ  = NULL; }
  if(qpc  != NULL) { free(qpc);  qpc  = NULL; }
  if(qpA  != NULL) { free(qpA);  qpA  = NULL; }
  if(qpb  != NULL) { free(qpb);  qpb  = NULL; }
  if(KKTLVL == 0) {
    if(ybar != NULL) { free(ybar); ybar = NULL; }
    if(zbar != NULL) { free(zbar); zbar = NULL; }
  }
}

void read_qp_data(char *inputname)
{
  FILE *infile;
  int i, j;
  int ret;
  char *retc;
  char tmp[1000];

  // Note: the command
  //   fgets(tmp, 1000, infile);
  // advances to the end of the current line

  infile = fopen(inputname, "r");
  if (infile == NULL) { fprintf(stderr, "Error getting file %s\n", inputname); exit(0); }

  // Get n and m
  if(FILETYPE == 'b') {
    ret = fscanf(infile, "%d\n", &n);
    m = n;
  }
  else if(FILETYPE == 'g') {
    retc = fgets(tmp, 1000, infile);
    ret = fscanf(infile, "%d %d\n", &n, &m);
    m += n; // m in datafile does not include upper bounds on variables
  }

  // allocate memory based on n and m
  alloc_qp_data();

  if(FILETYPE == 'g') retc = fgets(tmp, 1000, infile);

  // scan c vector
  for(j = 0; j < n; j++) ret = fscanf(infile, "%lf", &(qpc[j]));
  retc = fgets(tmp, 1000, infile);

  if(FILETYPE == 'g') retc = fgets(tmp, 1000, infile);

  // scan Q matrix
  for(i = 0; i < n; i++) {
    for(j = 0; j < n; j++)
      ret = fscanf(infile, "%lf", &(qpQ[j*n + i]));
    retc = fgets(tmp, 1000, infile);
  }

  // setup A (assumes calloc has initialized A to zero)
  if(FILETYPE == 'b') {
    for(i = 0; i < m; i++) qpA[i*m + i] = 1.0;
  }
  else if(FILETYPE == 'g') {
    retc = fgets(tmp, 1000, infile);
    for(i = 0; i < m-n; i++) {
      for(j = 0; j < n; j++)
        ret = fscanf(infile, "%lf", &(qpA[j*m + i])); 
      retc = fgets(tmp, 1000, infile);
    }
    for(i = m-n; i < m; i++)
      qpA[(i-(m-n))*m + i] = 1.0;
  }

  // setup b
  if(FILETYPE == 'b') {
    for(i = 0; i < m; i++) qpb[i] = 1.0;
  }
  else if(FILETYPE == 'g') {
    retc = fgets(tmp, 1000, infile);
    for(i = 0;   i < m-n; i++) ret = fscanf(infile, "%lf", &(qpb[i]));
    retc = fgets(tmp, 1000, infile);
    for(i = m-n; i < m;   i++) qpb[i] = 1.0;
  }

  // If KKTLVL = 0, calculate ybar and zbar
  if(KKTLVL == 0) {
    for(i = 0; i < n; i++) {
      ybar[i] = qpc[i] + qpQ[i*n + i];
      zbar[i] = -1.0*qpc[i];
      for(j = 0; j < n; j++) {
        if ((j != i) && (qpQ[j*n + i] > 0)) ybar[i] += qpQ[j*n + i];
        if ((j != i) && (qpQ[j*n + i] < 0)) zbar[i] -= qpQ[j*n + i];
      }
      if (ybar[i] < 0) ybar[i] = 0.0;
      if (zbar[i] < 0) zbar[i] = 0.0;
    }
  }

  fclose(infile);
}
