#include "all.h"

int     UBE;    // indicates whether to multiply Ax <= by e-x >= 0 (assumes x <= e implied by Ax <= b)
int     PSD;    // indicates whether N or N+
int     KKTLVL; // indicates whether to do first-level KKT relaxation
double  *xbar, xBAR, *bmAxbar, yBAR, zBAR, origyBAR, origzBAR;
int     OBJOPER = 0; // indicates whether to relax Q*X + c'x = b'y (necessary during calculation of yBAR and zBAR)
char    FILETYPE;

int getubs(CPXENVptr env);

int main (int nArgs, char *arg[])
{
  // CPLEX variables (1 environment, 3 LP pointers, 3 QP pointers)
  CPXENVptr env = NULL;
  CPXLPptr  lp[3];
  CPXLPptr  qp[3];

  // Simple integer variables
  int status, k;

  // Timing information
#ifdef ISWINDOZE
  clock_t t0, t1;
  double  t, preprocess_t;
#endif
#ifdef ISLINUX
  int     clocks_per_second;
  double  t0, t, preprocess_t;
  struct  tms timearr;
  clock_t tres;
  clocks_per_second = sysconf ( _SC_CLK_TCK );
#endif

#ifdef ISLINUX
  tres = times(&timearr); 
  t0 = timearr.tms_utime; 
#endif
#ifdef ISWINDOZE
  t0 = clock();
#endif

  // Input check
  if (nArgs != 5) {
   fprintf(stderr, "Usage: %s kkt{0,1,2} psd{off,on} {box,gen} <input>\n", arg[0]);
   exit(0);
  }

  // Print options (others?)
  printf("Instance = %s\n", arg[4]);
  if(REL_OR_ABS == 1) printf("OPT_TOLERANCE = %f\n", OPT_TOLERANCE);
  if(REL_OR_ABS == 2) printf("ABS_TOLERANCE = %e\n", ABS_TOLERANCE);
  printf("MY_CPX_TOL = %e\n", MY_CPX_TOL);
  printf("MY_UB_ADJ = %e\n", MY_UB_ADJ);
  printf("HOTSTART = %d\n", HOTSTART);
  printf("MY_EARLYTERM_TOL = %f\n", MY_EARLYTERM_TOL);
  printf("SKIPCOLS = %d\n", SKIPCOLS);
  printf("YZX_BRANCH = %d\n", YZX_BRANCH);
  printf("AGG_YZ_BND = %d\n", AGG_YZ_BND);
  printf("OBJOPER    = %d\n", OBJOPER);
  printf("ITERLIM    = %d\n", ITERLIM);
  printf("OBJOPER_RESOLVE = %d\n", OBJOPER_RESOLVE);

  // BEGIN: Initialize CPLEX
  // BEGIN: Initialize CPLEX
  // BEGIN: Initialize CPLEX

  // Open CPLEX environment
  env = CPXopenCPLEX (&status);
  if (env == NULL) {
    char errmsg[1024];
    CPXgeterrorstring (env, status, errmsg);
    fprintf (stderr, "Could not open CPLEX environment: %s\n", errmsg);
    goto TERMINATE;
  }

  // Set various CPLEX options (no error checking)
  status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_OFF);
//   status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
  status = CPXsetintparam (env, CPX_PARAM_SIMDISPLAY, 0);
  status = CPXsetintparam (env, CPX_PARAM_BARDISPLAY, 0);
  status = CPXsetintparam (env, CPX_PARAM_ADVIND, 1);
  status = CPXsetdblparam (env, CPX_PARAM_EPRHS, MY_CPX_TOL);  // feasibility tolerance
  status = CPXsetdblparam (env, CPX_PARAM_EPOPT, MY_CPX_TOL);  // optimality  tolerance
  status = CPXsetintparam (env, CPX_PARAM_QPMETHOD, 2);        // QP pivoting algorithm
	
  // Create the LPs and QPs (note similar code)
  for(k = 0; k < 3; k++) {
    lp[k] = CPXcreateprob (env, &status, "lpsubprob");
    if (lp[k] == NULL) { fprintf (stderr, "Failed to create LP.\n"); goto TERMINATE; }
  }
  for(k = 0; k < 3; k++) {
    qp[k] = CPXcreateprob (env, &status, "qpsubprob");
    if ( qp[k] == NULL ) { fprintf (stderr, "Failed to create QP.\n"); goto TERMINATE; }
  }

  // Based on choice of user, specify which KKT level
  if      (strcmp("kkt0", arg[1]) == 0) KKTLVL = 0;
  else if (strcmp("kkt1", arg[1]) == 0) KKTLVL = 1;
  else if (strcmp("kkt2", arg[1]) == 0) KKTLVL = 2;
  else { printf("Must choose 'kkt0' or 'kkt1' or 'kkt2' as first argument, exiting...\n"); goto TERMINATE; }

  // Based on KKTLVL, set UBE
  if(KKTLVL == 0) UBE = 1;
  else            UBE = 1;

  // Based on choice of user, specify whether to include positive semidefiniteness
  if      (strcmp("psdon",  arg[2]) == 0) PSD = 1;
  else if (strcmp("psdoff", arg[2]) == 0) PSD = 0;
  else { printf("Must choose 'psdon' or 'psdoff' as second argument, exiting...\n"); goto TERMINATE; }

  // Based on choice of user, determine which filetype to read in (either 'b' for box or 'g' for general)
  if      (strcmp("box", arg[3]) == 0) FILETYPE = 'b';
  else if (strcmp("gen", arg[3]) == 0) FILETYPE = 'g';
  else { printf("Must choose 'box' or 'gen' as third argument, exiting...\n"); goto TERMINATE; }

  // FILETYPE = 'g' is not allowed with kkt0
  if(KKTLVL == 0 && FILETYPE == 'g') {
    printf("kkt0 and gen are incompatible, exiting...\n");
    goto TERMINATE;
  }

  // Read data and setup LP and QP subproblems.
  read_qp_data(arg[4]); 

  // setup some constants (including sophisticated getubs)
  if(KKTLVL > 0)  get_objoper_norm();
  if(KKTLVL == 2) get_ycompoper_norm();
  getubs(env);

  // Create LPs and QPs
  status = create_qp_subprob(env, lp, qp);
  if (status) { fprintf(stderr, "Error creating qp subproblem lp\n"); goto TERMINATE; }

  // Get preprocessing time
#ifdef ISLINUX
  tres = times(&timearr);
  preprocess_t = (timearr.tms_utime-t0)/clocks_per_second;
#endif
#ifdef ISWINDOZE
  t1 = clock();
  preprocess_t = (double) (t1 - t0)/CLOCKS_PER_SEC;
#endif

  // END: Initialize CPLEX
  // END: Initialize CPLEX
  // END: Initialize CPLEX

   
  //
  // RUN ALGORITHM
  // RUN ALGORITHM
  // RUN ALGORITHM
  // RUN ALGORITHM
  //

  bandb(env, lp, qp);

#ifdef ISLINUX
  tres = times(&timearr);
  t = (timearr.tms_utime-t0)/clocks_per_second;
#endif
#ifdef ISWINDOZE
  t1 = clock();
  t = (double) (t1 - t0)/CLOCKS_PER_SEC;
#endif

  //
  // DONE
  // DONE
  //

  // Print timings
  printf("Pre CPU Time = %.4f\n", preprocess_t);
  printf("B&B CPU Time = %.4f\n", t - preprocess_t);
  
TERMINATE:

  // Free the problem data (only does so if ptrs != NULL)
  dealloc_qp_data();
  
  // Free up the problems as allocated by CPXcreateprob, if necessary 
  for(k = 0; k < 3; k++) {
    if (lp[k] != NULL) {
      status = CPXfreeprob (env, &(lp[k]));
      if ( status ) { fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status); }
      usleep(5000000); // Wait for CPLEX license to be freed.
    }  
  }

  for(k = 0; k < 3; k++) {
    if (qp[k] != NULL) {
      status = CPXfreeprob (env, &(qp[k]));
      if ( status ) { fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status); }
      usleep(5000000); // Wait for CPLEX license to be freed.
    }
  }

  // Free up the CPLEX environment, if necessary 
  if ( env != NULL ) {
    status = CPXcloseCPLEX (&env);
    if ( status ) {
      char  errmsg[1024];
      fprintf (stderr, "Could not close CPLEX environment.\n");
      CPXgeterrorstring (env, status, errmsg);
      fprintf (stderr, "%s", errmsg);
    }
  }

  free(xbar);    // allocated in getubs()
  free(bmAxbar);
     
  return (status);

}


int getubs(CPXENVptr env)
{
  int i, k, status;
  int origKKTLVL;
  double *pvar, *dvar, *ddir;
  SOLNINFO cursoln;
  int origOBJOPER, origUBE;
  double orig_my_earlyterm_tol;
  int    tempind[n+m];
  double tempobj[n+m];

  // CPLEX variables (3 LP pointers, 3 QP pointers)
  CPXLPptr  lp[3];
  CPXLPptr  qp[3];

  // Bounds for each individual xj
  // In the future, should scale (A,b) so that upper bounds are 1.0
  // Can we then get rid of xbar?
  xbar = (double*)calloc(n, sizeof(double));
  for(i = 0; i < n; i++) xbar[i] = 1.0; // Sam here: This code should be generalized for other Ax <= b

  // Bounds for individual components of b - Ax
  bmAxbar = (double*)calloc(m, sizeof(double));

  for(i = 0; i < n+m; i++) { tempind[i] = i; tempobj[i] = 0.0; }

  lp[0] = CPXcreateprob (env, &status, "lpsubprob");
  if(lp[0] == NULL) { fprintf (stderr, "Failed to create LP.\n"); exit(0); }

  create_qp_subprob_bmAxBAR(env, lp[0]);

  for(i = 0; i < m; i++) {

    tempobj[n+i] = 1.0;

    status = CPXchgobj(env, lp[0], n+m, tempind, tempobj);
    if (status) { fprintf(stderr, "Problem changing coeff for qp y^i\n"); return(status); }

    status = CPXprimopt(env, lp[0]);
    if (status) { fprintf(stderr, "Problem solving a subproblem\n"); return(status); }

    status = CPXgetstat(env,lp[0]);
    if (status == CPX_STAT_INFEASIBLE) { printf("Subproblem infeasible\n"); exit(0); }

    if(status != CPX_STAT_UNBOUNDED && status != CPX_STAT_INForUNBD) {
      status = CPXgetobjval (env, lp[0], bmAxbar + i);
      if (status) { fprintf(stderr, "Problem getting obj val of subproblem\n"); exit(0); }
    }

    tempobj[n+i] = 0.0;

  }

  status = CPXfreeprob (env, &(lp[0]));
  if(status) { fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status); }
  usleep(5000000); // Wait for CPLEX license to be freed.
  lp[0] = NULL;

  // If KKTLVL > 0, we must calculate aggregate bounds on e'y and e'z
  if(KKTLVL > 0) {

    // These constants must be set
    // (See also create_qp_subprob() for other changes to yBAR, etc.)
    origKKTLVL  = KKTLVL;  KKTLVL  = 1;
    origOBJOPER = OBJOPER; OBJOPER = 1;
    origUBE     = UBE;     UBE     = 0;
    origyBAR = origzBAR = 1.0;
    orig_my_earlyterm_tol = my_earlyterm_tol; my_earlyterm_tol = 2.0; // greater than 1 ==> no early termination

    for(k = 0; k < 3; k++) {
      lp[k] = CPXcreateprob (env, &status, "lpsubprob");
      if (lp[k] == NULL) { fprintf (stderr, "Failed to create LP.\n"); exit(0); }
    }
    for(k = 0; k < 3; k++) {
      qp[k] = CPXcreateprob (env, &status, "qpsubprob");
      if ( qp[k] == NULL ) { fprintf (stderr, "Failed to create QP.\n"); exit(0); }
    }

    status = create_qp_subprob_getubs(env, lp, qp);
    if (status) { fprintf(stderr, "Error creating qp subproblem lp\n"); exit(0); }

    get_objoper_norm();

    alloc_pdvars(&pvar,&dvar,&ddir);

    printf("Computing bound for max e'y...\n"); fflush(stdout);
    special = 3;
    cursoln = node_run_subgrad (env, lp, qp, NULL, NULL, 0, pvar, dvar, ddir);
    yBAR = cursoln.relaxbnd;
    if(cursoln.xval) free(cursoln.xval); if(cursoln.y) free(cursoln.y); if(cursoln.z) free(cursoln.z);

    printf("Computing bound for max e'z...\n"); fflush(stdout);
    special = 4;
    cursoln = node_run_subgrad (env, lp, qp, NULL, NULL, 0, pvar, dvar, ddir);
    zBAR = cursoln.relaxbnd;
    if(cursoln.xval) free(cursoln.xval); if(cursoln.y) free(cursoln.y); if(cursoln.z) free(cursoln.z);

    dealloc_pdvars(pvar, dvar, ddir);

    for(k = 0; k < 3; k++) {
      if (lp[k] != NULL) {
        status = CPXfreeprob (env, &(lp[k]));
        if ( status ) { fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status); }
        usleep(5000000); // Wait for CPLEX license to be freed.
      }  
    }

    for(k = 0; k < 3; k++) {
      if (qp[k] != NULL) {
        status = CPXfreeprob (env, &(qp[k]));
        if ( status ) { fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status); }
        usleep(5000000); // Wait for CPLEX license to be freed.
      }
    }

    KKTLVL = origKKTLVL;
    OBJOPER = origOBJOPER;
    UBE = origUBE;
    my_earlyterm_tol = orig_my_earlyterm_tol;

  }

  special = 0;

  return 0;
}
