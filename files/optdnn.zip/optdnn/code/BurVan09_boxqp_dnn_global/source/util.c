#include "all.h"

int    daxpy_();
int    dcopy_();
double ddot_();
double dnrm2_();
int    dscal_();


int mydaxpy(int n, double da, double* dx, int incx, double* dy, int incy)
{
#ifndef __OPT_MYBLAS
  return daxpy_(&n,&da,dx,&incx,dy,&incy);
#elif __OPT_UNROLLEDLOOP
  int i=0, blocklimit, ix=0, iy=0;
  if(incx == 1 && incy == 1) {
    blocklimit = (n/8)*8; 
    while(i < blocklimit) {
      dy[i] += da*dx[i];
      dy[i+1] += da*dx[i+1];
      dy[i+2] += da*dx[i+2];
      dy[i+3] += da*dx[i+3];
      dy[i+4] += da*dx[i+4];
      dy[i+5] += da*dx[i+5];
      dy[i+6] += da*dx[i+6];
      dy[i+7] += da*dx[i+7];
      i += 8; 
    }
    if(i < n) { 
      switch(n - i) { 
        case 7 : dy[i] += da*dx[i]; i++; 
        case 6 : dy[i] += da*dx[i]; i++; 
        case 5 : dy[i] += da*dx[i]; i++; 
        case 4 : dy[i] += da*dx[i]; i++; 
        case 3 : dy[i] += da*dx[i]; i++; 
        case 2 : dy[i] += da*dx[i]; i++; 
        case 1 : dy[i] += da*dx[i]; 
      }
    }
  }
  else {
    for(i = n; i--; ) {
      dy[iy] += da*dx[ix];
      ix += incx;
      iy += incy;
    }
  }
  return 0;
#else
  int i, ix=0, iy=0;
  if(incx == 1 && incy == 1) {
    for(i = n; i--; )
      dy[i] += da*dx[i];
  }
  else {
    for(i = n; i--; ) {
      dy[iy] += da*dx[ix];
      ix += incx;
      iy += incy;
    }
  }
  return 0;
#endif
}

int mydcopy(int n, double* dx, int incx, double* dy, int incy)
{
#ifndef __OPT_MYBLAS
  return dcopy_(&n,dx,&incx,dy,&incy);
#elif __OPT_UNROLLEDLOOP
  int i=0, blocklimit, ix=0, iy=0;
  if(incx == 1 && incy == 1) {
    blocklimit = (n/8)*8; 
    while(i < blocklimit) {
      dy[i] = dx[i];
      dy[i+1] = dx[i+1];
      dy[i+2] = dx[i+2];
      dy[i+3] = dx[i+3];
      dy[i+4] = dx[i+4];
      dy[i+5] = dx[i+5];
      dy[i+6] = dx[i+6];
      dy[i+7] = dx[i+7];
      i += 8; 
    }
    if(i < n) { 
      switch(n - i) { 
        case 7 : dy[i] = dx[i]; i++; 
        case 6 : dy[i] = dx[i]; i++; 
        case 5 : dy[i] = dx[i]; i++; 
        case 4 : dy[i] = dx[i]; i++; 
        case 3 : dy[i] = dx[i]; i++; 
        case 2 : dy[i] = dx[i]; i++; 
        case 1 : dy[i] = dx[i]; 
      }
    }
  }
  else {
    for(i = n; i--; ) {
      dy[iy] = dx[ix];
      ix += incx;
      iy += incy;
    }
  }
  return 0;
#else
  int i, ix=0, iy=0;
  if(incx == 1 && incy == 1) {
    for(i = n; i--; )
      dy[i] = dx[i];
  }
  else {
    for(i = n; i--; ) {
      dy[iy] = dx[ix];
      ix += incx;
      iy += incy;
    }
  }
  return 0;
#endif
}

double myddot(int n, double* dx, int incx, double* dy, int incy)
{
/*
#ifndef __OPT_MYBLAS
*/
  return ddot_(&n, dx, &incx, dy, &incy);
/*
#elif __OPT_UNROLLEDLOOP
  int i=0, blocklimit, ix=0, iy=0;
  double sum=0.0;
  if(incx == 1 && incy == 1) {
    blocklimit = (n/8)*8; 
    while(i < blocklimit) {
      sum += dy[i]*dx[i] + dy[i+1]*dx[i+1] + dy[i+2]*dx[i+2] +
             dy[i+3]*dx[i+3] + dy[i+4]*dx[i+4] + dy[i+5]*dx[i+5] +
             dy[i+6]*dx[i+6] + dy[i+7]*dx[i+7];
      i += 8; 
    }
    if(i < n) { 
      switch(n - i) { 
        case 7 : sum += dy[i]*dx[i]; i++; 
        case 6 : sum += dy[i]*dx[i]; i++; 
        case 5 : sum += dy[i]*dx[i]; i++; 
        case 4 : sum += dy[i]*dx[i]; i++; 
        case 3 : sum += dy[i]*dx[i]; i++; 
        case 2 : sum += dy[i]*dx[i]; i++; 
        case 1 : sum += dy[i]*dx[i]; 
      }
    }
  }
  else {
    for(i = n; i--; ) {
      sum += dx[ix]*dy[iy];
      ix += incx;
      iy += incy;
    }
  }
  return sum;
#else
  int i, ix=0, iy=0;
  double sum=0.0;
  if(incx == 1 && incy == 1) {
    for(i = n; i--; )
      sum += dx[i]*dy[i];
  }
  else {
    for(i = n; i--; ) {
      sum += dx[ix]*dy[iy];
      ix += incx;
      iy += incy;
    }
  }
  return sum;
#endif
*/
}

double mydnrm2(int n, double* dx, int incx)
{
  return dnrm2_(&n, dx, &incx);
}

int mydscal(int n, double da, double* dx, int incx)
{
#ifndef __OPT_MYBLAS
  return dscal_(&n, &da, dx, &incx);
#elif __OPT_UNROLLEDLOOP
  int i=0, blocklimit, ix=0;
  if(incx == 1) {
    blocklimit = (n/8)*8; 
    while(i < blocklimit) {
      dx[i] *= da;
      dx[i+1] *= da;
      dx[i+2] *= da;
      dx[i+3] *= da;
      dx[i+4] *= da;
      dx[i+5] *= da;
      dx[i+6] *= da;
      dx[i+7] *= da;
      i += 8; 
    }
    if(i < n) { 
      switch(n - i) { 
        case 7 : dx[i] *= da; i++; 
        case 6 : dx[i] *= da; i++; 
        case 5 : dx[i] *= da; i++; 
        case 4 : dx[i] *= da; i++; 
        case 3 : dx[i] *= da; i++; 
        case 2 : dx[i] *= da; i++; 
        case 1 : dx[i] *= da; 
      }
    }
  }
  else {
    for(i = n; i--; ) {
      dx[ix] *= da;
      ix += incx;
    }
  }
  return 0;
#else
  int i, ix=0;
  if(incx == 1) {
    for(i = n; i--; )
      dx[i] *= da;
  }
  else {
    for(i = n; i--; ) {
      dx[ix] *= da;
      ix += incx;
    }
  }
  return 0;
#endif
}



int mychgbds(CPXENVptr env, CPXLPptr lp, const int index, const double bound, const char boundtype)
{
  int status;
  status = CPXchgbds(env, lp, 1, &index, &boundtype, &bound);
  if (status) { fprintf(stderr, "Problem changing bound\n"); return(1); }
  return 0;
}

void mywrite(CPXENVptr env, CPXLPptr lp, const char *filename)
{
  CPXwriteprob(env, lp, filename, NULL);
}

void printY(double *Y)
{
  int i, j;

  printf("Y =\n");
  for(i = 0; i < N+1; i++) {
    for(j = 0; j < N+1; j++) printf("%.5f  ", Y[j*(N+1) + i]);
    printf("\n");
  }
}

void printprimals(double *pvar)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  assign_pdvars(pvar,NULL,NULL,
                &Y,&U,&Z,&y,&z,
                NULL,NULL,NULL,NULL,NULL,
                NULL,NULL,NULL,NULL,NULL,
                1,0,0);
  // Print pvar
 
  printf("pvar = [\n");
  for(i = 0; i < pdim; i++) 
    printf("% .15e  ", pvar[i]);
  printf("\n       ]'\n");

  // Print Y
  
  printf("Y = [\n");
  for(i = 0; i < N+1; i++) {
    for(j = 0; j < N+1; j++) {
      printf("% .15e  ", Y[j*(N+1) + i]);
    }
    printf(";\n");
  }
  printf("    ]\n");

  // Print X
  
  printf("X = [\n");
  for(i = 1; i < N+1; i++) {
    for(j = 1; j < N+1; j++) {
      printf("% .15e  ", Y[j*(N+1) + i]);
    }
    printf(";\n");
  }
  printf("    ]\n");

  // Print x

  printf("x = [\n");
  for(j = 0; j < n; j++) 
    printf("% .15e  ", Y[1 + j]);
  printf("\n");
  printf("    ]'\n");

  // Print y 

  if(KKTLVL > 0) {
    printf("y = [\n");
    for(i = 0; i < m; i++) 
      printf("% .15e  ", y[i]);
    printf("\n");
    printf("    ]'\n");
  }

  // Print z

  if(KKTLVL > 0) {
    printf("z = [\n");
    for(j = 0; j < n; j++) 
      printf("% .15e  ", z[j]);
    printf("\n");
    printf("    ]'\n");
  }

  // Print U
  
  printf("U = [\n");
  for(i = 0; i < N+1; i++) {
    for(j = 0; j < i; j++)
      printf("% .15e  ", U[updiag_index(j,i)]);
    for(j = i; j < N+1; j++) 
      printf("% .15e  ", U[updiag_index(i,j)]);
    printf(";\n");
  }
  printf("    ]\n");


}

void printduals(double *dvar)
{
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);

  printf("obj_lambda = %f\n", obj_lambda[0]);

//   printf("sym_lambda =\n");
//   for(i = 0; i < N+1; i++) {
//     for(j = 0; j < N+1; j++) {
//       if(j <= i) printf("          ");
//       else printf("% .5f  ", sym_lambda[supdiag_index(i,j)]);
//     }
//     printf("\n");
//   }

}

void printdata(void)
{
  int i, j;
  extern int n;
  extern double *qpQ;

  // Print Q
  
  printf("Q = [\n");
  for(i = 0; i < n; i++) {
    for(j = 0; j < n; j++) {
      printf("% .15e  ", qpQ[j*n + i]);
    }
    printf(";\n");
  }
  printf("    ]\n");

  // Print A

  printf("A = [\n");
  for(i = 0; i < m; i++) {
    for(j = 0; j < n; j++) {
      printf("% .15e  ", qpA[j*m + i]);
    }
    printf(";\n");
  }
  printf("    ]\n");

  // Print b 

  printf("b = [\n");
  for(i = 0; i < m; i++) 
    printf("% .15e  ", qpb[i]);
  printf("\n");
  printf("    ]'\n");

  // Print c

  printf("c = [\n");
  for(j = 0; j < n; j++) 
    printf("% .15e  ", qpc[j]);
  printf("\n");
  printf("    ]'\n");

}
