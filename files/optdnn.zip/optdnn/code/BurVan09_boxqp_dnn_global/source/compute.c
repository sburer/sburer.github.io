#include "all.h"

int mydaxpy(int, double, double*, int, double*, int);
int mydcopy(int, double*, int, double*, int);
double myddot(int, double*, int, double*, int);
double mydnrm2(int, double*, int);
int mydscal(int, double, double*, int);

/* Modification to solving LP's without x[0]:  Keep tempc to be length n+1, but only pass tempc+1
   to CPX_chgobj.  When solving subproblems, check if tempc[0] + z[1] <= 0 */

#define EASYDAXPY(DIM,SCAL,X,Y)   mydaxpy(DIM,SCAL,X,1,Y,1)
#define EASYDCOPY(DIM,X,Y)        mydcopy(DIM,X,1,Y,1)
#define EASYDDOT(DIM,X,Y)         myddot(DIM,X,1,Y,1)
#define EASYDNRM2(DIM,X)          mydnrm2(DIM,X,1)
#define EASYDSCAL(DIM,SCAL,X)     mydscal(DIM,SCAL,X,1)
#define ZEROVEC(X,DIM)            mydscal(DIM,0.0,X,1)

//Index into square matrix stored column-wise for 0 <= i <= numcols, 0 <= j <= numcols
#define row_square_index(i,j,numrows)  ((j*(numrows)) + i)

// Global variables b/c they only need to allocated once
// These are used in solve_lp.c and solve_qp.c
double *tempc;     // Stores objective functions of 2n+1 subproblems.
int *temp_indices; // Equals [0:n]; does not change after initialized.
int **cstatus, **rstatus; // Saves basis information

// Global variables b/c they only need to allocated once
// These are used in project_S only
double *EigValue, *EigVector, *Work;
int INFO, tempN, incX;
char JOBZ, UPLO;
double *tempmatrix;
int *suppeigvec;
double *dwork;
int *intwork, dworklength, intworklength;

int *quadpart_i, *quadpart_j;
double *quadpart_val;

double *solve_auglagr_tmp;

void alloc_computearrays(CPXENVptr env, CPXLPptr *qp)
{
  int i, csz, rsz;
  int localdim;

  /////

  localdim = N+1 + (KKTLVL == 1)*(m + n);
  tempc        = (double *) calloc(localdim, sizeof(double));
  temp_indices = (int *)    calloc(localdim, sizeof(int));

  for(i = 0; i < localdim; i++) temp_indices[i] = i;

  /////

  cstatus = (int **) calloc(N+1 + UBE*N, sizeof(int *));
  rstatus = (int **) calloc(N+1 + UBE*N, sizeof(int *));
  for(i = 0; i < N+1; i++)
    {
      if(i == 0) {
        csz = CPXgetnumcols(env, qp[0]);
        rsz = CPXgetnumrows(env, qp[0]);
      }
      else {
        csz = CPXgetnumcols(env, qp[1]);
        rsz = CPXgetnumrows(env, qp[1]);
      }
      cstatus[i] = (int *) calloc(csz, sizeof(int));
      rstatus[i] = (int *) calloc(rsz, sizeof(int));
      if (i >= 1 && UBE)
        {
          csz = CPXgetnumcols(env, qp[2]);
          rsz = CPXgetnumrows(env, qp[2]);
          cstatus[i+N] = (int *) calloc(csz, sizeof(int));
          rstatus[i+N] = (int *) calloc(rsz, sizeof(int));
        }
    }

  /////

  localdim = N+1;
  EigValue  = (double *) malloc(localdim*sizeof(double));
  EigVector = (double *) malloc(localdim*localdim*sizeof(double));
  Work      = (double *) malloc(localdim*3*sizeof(double));
  tempN = localdim;
  incX  = 1;
  JOBZ  = 'V';
  UPLO  = 'U';

  MYCALLOC(tempmatrix, double, tempN*tempN);
  MYCALLOC(suppeigvec, int, 2*tempN);

  if(USE_DSYEVR) {
    get_dsyevr_lengths(); // get dworklength and intworklength
    if (dworklength > 0)
    {
            MYCALLOC(dwork, double, dworklength);
    }
    if (intworklength > 0)
    {
            MYCALLOC(intwork, int, intworklength);
    }
  }

  /////

  // Believe N+1 + (m+n+1)*(m+n)/2 is a safe upper bound for quadpart vectors
  quadpart_i = (int*)calloc(N+1 + (m+n+1)*(m+n)/2, sizeof(int));
  quadpart_j = (int*)calloc(N+1 + (m+n+1)*(m+n)/2, sizeof(int));
  quadpart_val = (double*)calloc(N+1 + (m+n+1)*(m+n)/2, sizeof(double));

  /////
  solve_auglagr_tmp = (double*)calloc(ddim, sizeof(double)); 
  
}

void dealloc_computearrays()
{
  int i;

  MYFREE(tempc);
  MYFREE(temp_indices);

  for(i = 0; i < N+1; i++) {
    MYFREE(cstatus[i]);
    MYFREE(rstatus[i]);
    if (i >= 1 && UBE == 1) {
      MYFREE(cstatus[i+N]);
      MYFREE(rstatus[i+N]);
    }
  }
  MYFREE(cstatus);
  MYFREE(rstatus);

  MYFREE(EigValue);
  MYFREE(EigVector);
  MYFREE(Work);
  if(dwork != NULL) MYFREE(dwork);
  if(intwork != NULL) MYFREE(intwork);

  MYFREE(quadpart_i);
  MYFREE(quadpart_j);
  MYFREE(quadpart_val);

  MYFREE(solve_auglagr_tmp);
}

double compute_dir(double *pvar, double *ddir)
{
  int i;
  // double zero_or_one = 1.0;
  double sum = 0.0;
  double *Y, *U, *Z, *y, *z, *sym_dir, *S_dir, *z_dir, *obj_dir, *ycomp_dir;

  assign_pdvars(pvar,NULL,ddir,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,&sym_dir,&S_dir,&z_dir,&obj_dir,&ycomp_dir,1,0,1); 
  y = z = NULL; // actually don't use these

  // Apply linear operators
                             symmetry(pvar,sym_dir);
  if(PSD)                      YUoper(pvar,S_dir);
  if(UBE)                      YZoper(pvar,z_dir);
  if(OBJOPER && KKTLVL > 0)   objoper(pvar,obj_dir);
  if(KKTLVL == 2)           ycompoper(pvar,ycomp_dir);

  // The following is equivalent to b-Ax since all rhs's are 0
  cblas_dscal (ddim, -1.0, ddir, 1);

  // Now calculate the norm
                            sum += pow( cblas_dnrm2(LDIM, sym_dir, 1) , 2.0 );
  if(UBE)                   sum += pow( cblas_dnrm2(ZDIM, z_dir, 1) ,   2.0 );
  if(OBJOPER && KKTLVL > 0) sum += obj_dir[0]*obj_dir[0];
  if(KKTLVL == 2)           sum += pow( cblas_dnrm2(m, ycomp_dir, 1),   2.0 );
  if(PSD) {
    sum += 2.0*pow( cblas_dnrm2(UDIM, S_dir, 1) , 2.0 );
    for(i = 0; i < N+1; i++) sum -= pow( S_dir[updiag_index(i,i)] , 2.0 );
  }

  return sqrt(sum);
}

void update_duals(double stepsize, double *dvar, double *ddir) 
{
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  cblas_daxpy(ddim, -stepsize, ddir, 1, dvar, 1); 

  if (PSD || (OBJOPER && KKTLVL > 0 && special > 0)) { // special > 0 is really important!
    assign_pdvars(NULL,dvar,ddir,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
    sym_lambda = z_lambda = NULL; // actually don't use these
    if(PSD) project_S(S);
    if(OBJOPER && KKTLVL > 0 && special > 0) obj_lambda[0] = mymin(0.0, obj_lambda[0]);
  }

}

void project_S(double *S)
{

	int i, j;

	if (USE_DSYEVR)  //This should be set to 1 in options.h to use dsyevr
	{
		char RANGE = 'V';
		double VL, VU;
		int IL, IU;
		double ABSTOL = 1e-10;
		int numeig;
		
//                 double *dwork;
//                 int dworklength;
//                 int *intwork;
//                 int intworklength;
//                 double tempdwork;
//                 int tempiwork;

	
		int tempmatlength;

		tempmatlength = tempN*tempN;
		
		EASYDSCAL(tempmatlength, 0.0,tempmatrix);
		// Copy S into tempmatrix (because tempmatrix must be full size, with
		// upper diagonal containing the actual matrix.  I don't think there's a faster
		// to copy this?  Can you think of one Sam?
                // Unfortunately no. --Sam
		for(i = 0; i < tempN; i++)
			for(j = i; j < tempN; j++)  
				tempmatrix[row_square_index(i,j,tempN)] = S[updiag_index(i,j)];


		VL = 0.0;
		//The following is an approximate upper bound on the largest eigenvalue 
		VU = 2*EASYDNRM2(UDIM, S) + 1 ;


//                 dworklength = -1;
//                 intworklength = -1;

		
		// This first figures out how much memory to allocate in temporary workspaces
		// It may be more efficient to just allocate enough memory up front
		// according to the description for dsyevr we must have
		// length of intwork >= 10*tempN
		// length of dwork >= 26*tempN
		// That's a lot of memory to preallocate: below you can uncomment a line
		// which prints the required sizes for both arrays as determined by the first call
		// to dsyevr.  For now, i'm reallocating these arrays each time.  Some testing may
		// be required to determine which is best.
                // I went ahead and allocated beforehand based on the assumption it couldn't be worse. --Sam

//                 dsyevr_(&JOBZ, &RANGE, &UPLO, &tempN, tempmatrix, &tempN, &VL, &VU, &IL, &IU,
//                                 &ABSTOL, &numeig, EigValue, EigVector, &tempN, suppeigvec, &tempdwork, &dworklength,
//                                 &tempiwork, &intworklength, &INFO);

//                 if (INFO != 0)
//                 {
//                         printf("Problem with second lapack function\n");
//                         exit(0);
//                 }

//                 dworklength = (int) tempdwork;
//                 intworklength = mymax(10*tempN, tempiwork);
// //        printf("dworklength = %d, intworklength = %d\n", dworklength, intworklength);
//                 if (dworklength > 0)
//                 {
//                         MYCALLOC(dwork, double, dworklength);
//                 }
//                 if (intworklength > 0)
//                 {
//                         MYCALLOC(intwork, int, intworklength);
//                 }

		dsyevr_(&JOBZ, &RANGE, &UPLO, &tempN, tempmatrix, &tempN, &VL, &VU, &IL, &IU,
				&ABSTOL, &numeig, EigValue, EigVector, &tempN, suppeigvec, dwork, &dworklength,
				intwork, &intworklength, &INFO);
		if (INFO != 0)
		{
			printf("Problem with second lapack function\n");
			exit(0);
		}

//                 MYFREE(dwork);
//                 MYFREE(intwork);
		
		cblas_dscal (UDIM, 0.0, S, 1);

		for(j = 0; j < numeig; j++)
			if (EigValue[j] >= 0.0)
				dspr_(&UPLO, &tempN, &(EigValue[j]), EigVector+(tempN*j), &incX, S);


	}
	else
	{

		dspev_(&JOBZ, &UPLO, &tempN, S, EigValue, EigVector, &tempN, Work, &INFO);
		if (INFO != 0) { printf("Problem computing eigvalues/vectors\n info = %d\n", INFO); exit(0); }

		cblas_dscal (UDIM, 0.0, S, 1);

		for(j = 0; j < N+1; j++)
			if (EigValue[j] >= 0.0)
				dspr_(&UPLO, &tempN, &(EigValue[j]), EigVector+(tempN*j), &incX, S);
	}
}

void get_dsyevr_lengths(void)
{

        char RANGE = 'V';
        double VL, VU;
        int IL, IU;
        double ABSTOL = 1e-10;
        int numeig;
        
        double tempdwork;
        int tempiwork;

        int tempmatlength;

        tempmatlength = tempN*tempN;
        
        VL = 0.0;
        VU = 1.0e10;

        dworklength = -1;
        intworklength = -1;

        dsyevr_(&JOBZ, &RANGE, &UPLO, &tempN, tempmatrix, &tempN, &VL, &VU, &IL, &IU,
                        &ABSTOL, &numeig, EigValue, EigVector, &tempN, suppeigvec, &tempdwork, &dworklength,
                        &tempiwork, &intworklength, &INFO);

        if (INFO != 0) { printf("Problem with second lapack function\n"); exit(0); }

        dworklength = (int) tempdwork;
        intworklength = mymax(10*tempN, tempiwork);
//         printf("dworklength = %d    intworklength = %d\n", tempdwork, tempiwork);

}
