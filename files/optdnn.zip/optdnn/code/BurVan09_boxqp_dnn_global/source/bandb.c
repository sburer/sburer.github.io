#include "all.h"

// This routine manages the branch and bound tree.  It is called from main.c
// after the cplex environment and the basic lp's and qp's have been set up.
// Each time a node is to be evaluated, this function calls node_run_subgrad
// and passes the appropriate bounds.

PQTREE *pq;  // branch and bound priority queue
double  ZLB; // global lower bound
int     newzlb; // whether a new ZLB has been found at a particular node
int     pdim;
int     ddim;
int     special; // whether we are solving for xbar, ybar, etc.
double  my_earlyterm_tol = MY_EARLYTERM_TOL;

int comp_branch_kkt_extended(double pval, double *x, double *y, double *z, int*, int*, int, CPXENVptr env, CPXLPptr lp);
int solve_lp_subprob(CPXENVptr, CPXLPptr, double *);

int myfathom(double val)
{
  double denom;

  denom = (ZLB < MY_EPS && ZLB > -MY_EPS) ? 1.0 : fabs(ZLB);

  if ( ( REL_OR_ABS == 1 && (val - ZLB)/denom  < MY_EPS + OPT_TOLERANCE - 1.0 ) ||
       ( REL_OR_ABS == 2 &&  val - ZLB         < MY_EPS + ABS_TOLERANCE ) ) 
    return 1;
  else
    return 0;
}

int bandb (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp)
{
  NODEINFO *nodeptr;                 // Current node information
  void     *data;
  double    key;
  SOLNINFO  cursoln;                 // Returned solution
  int       i, curindex, curtype;    // Selected index and type for branching
//   FILE     *bestsolnfile;            // File to store best found solutions
  double    tempval, maxviol;
  int       numeval, numintree, numouttree;

  // Matlab related
  Engine   *ep;
  mxArray  *mxQ, *mxc, *mxA, *mxb, *mxn;

  // Variables, multipliers, directions
  double *pvar, *dvar, *ddir;
  double *Y, *U, *Z, *y, *z;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda; 
  double *sym_dir, *S_dir, *z_dir, *obj_dir, *ycomp_dir;

  // Misc
  int fullfixedindices[1+n+m];
  int origOBJOPER;
  int nogap, nocompviol;
  int oldnumintree;
  extern int newzlb;

  // Even if the default OBJOPER is 0, we may need to enforce the
  // objective operator from time to time for correctness of B&B.
  // Thus, we temporarily set OBJOPER = 1 so that the dual variables
  // are setup in such a way that there is space for the dual variable
  // corresponding to the objective constraint when it is needed
  // (located in the last position of dvar and ddir -- this is key).
  origOBJOPER = OBJOPER; OBJOPER = 1;

  // Allocate memory for primal and dual variables and directions, initialize duals (to 0)
  alloc_pdvars(&pvar,&dvar,&ddir);
  assign_pdvars(pvar,dvar,ddir,&Y,&U,&Z,&y,&z,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,&sym_dir,&S_dir,&z_dir,&obj_dir,&ycomp_dir,1,1,1);

  // Reset OBJOPER (see comment above).
  OBJOPER = origOBJOPER;

  special = 0; // do not delete this! (also located in getubs() subroutine)

  // Initialze best solutions file
//   bestsolnfile = fopen ("bestsoln.m", "w");

  // Compute initial lower bound
  printf("Computing initial lower bound ... "); fflush(stdout);
  matlab_start (&ep, &mxQ, &mxc, &mxA, &mxb, &mxn);
  ZLB = matlab_primal (NULL, ep);
  printf("done! (%.8e)\n", ZLB); fflush(stdout);

  // Initialize pq tree
  pq = CreatePQTree ();
  if (!pq) { terminate ("Error initializing qp tree\n"); }

  // Initialize root node
  MYMALLOC (nodeptr, NODEINFO);
  nodeptr->zrelax = 0;
  nodeptr->rank = 0;
  nodeptr->objoper = OBJOPER;
  nodeptr->fixedindices = NULL;
  nodeptr->fixedtypes = NULL;
  nodeptr->numfixed = 0;
  if(HOTSTART == 2) MYCALLOC(nodeptr->dvar, double, ddim);

  // Insert Root node in tree 
  InsertPQTree (pq, (void **) &nodeptr, &(nodeptr->rank));
  numintree = 1; numeval = 0; numouttree = 0;

  // Loop until no nodes remain in tree 
  while (pq->intree > 0) {

    // Remove the top node from the priority queue 
    DeleteTopPQTree (pq, &data, &key);
    numintree--; numeval++; numouttree++;
    nodeptr = (NODEINFO *) data;

    // Begin solving the associated relaxation 
    if(PRINTSTYLE == 1) {
      printf("\n=====================================================================================================\n");
        printf("------------------------------- Commencing solution of node %3d -------------------------------------\n\n", numouttree);
      printf ("Index type\n");
      for (i = 0; i < nodeptr->numfixed; i++) {
        printf ("%d %d\n", nodeptr->fixedindices[i], nodeptr->fixedtypes[i]);
      }
      printf("\n");
    }
    else printf("NODE %3d: (% .8e,", numouttree, ZLB);

    if     (HOTSTART == 0) cblas_dscal(ddim, 0.0, dvar, 1);
    else if(HOTSTART == 2) cblas_dcopy(ddim, nodeptr->dvar, 1, dvar, 1);

    // Setup node-specific OBJOPER
    origOBJOPER = OBJOPER; OBJOPER = nodeptr->objoper;

    // Declare newzlb as 0
    newzlb = 0;

    // Actually solve the relaxation
    cursoln = node_run_subgrad (env, lp, qp, nodeptr->fixedindices, nodeptr->fixedtypes,
                                nodeptr->numfixed, pvar, dvar, ddir);

    // Reset OBJOPER
    OBJOPER = origOBJOPER;

    if(HOTSTART == 2) cblas_dcopy (ddim, dvar, 1, nodeptr->dvar, 1);

    if (cursoln.problemcode == 0) { // Problem solved just dandy

      if(PRINTSTYLE == 1) {
        printf("\n------------------------------------------- done! ---------------------------------------------------\n");
          printf("=====================================================================================================\n\n");
        printf("NODE %3d: (% .8e,% .8e", numouttree, ZLB, cursoln.relaxbnd);
      }
      printf(") ");

      nodeptr->zrelax = cursoln.relaxbnd;

      // Decide what to do with node
      if (cursoln.fathom == 1) printf ("'bound'                  "); // Node is fathomed, no children created
      else { // Node either feasible or needs to be partitioned

        // Find maximum complimentarity violation and corresponding index
        if(KKTLVL == 0) maxviol = comp_branch    (&curindex, &curtype, cursoln.xval);
        else            maxviol = comp_branch_kkt(&curindex, &curtype, cursoln.xval, cursoln.y, cursoln.z);

        // Decide if there's no violation at all (up to tolerance)
        if(maxviol < MY_EPS) nocompviol = 1;
        else                 nocompviol = 0;

        // Decide if the node just solved had a gap or not
        if(fabs(cursoln.relaxbnd - cursoln.primalbnd)/(0.5*(fabs(cursoln.relaxbnd) + fabs(cursoln.primalbnd))) < MY_EPS) nogap = 1;
        else                                                                                                             nogap = 0;

        // If there's no violation and the objective constraint/operator
        // has not been included, then to be sure that fathoming
        // is okay, we need no gap. Even if the SDP has a gap, it
        // is possible that the LP will not. So we check the LP as
        // well. Otherwise, it makes sense to add in the objective
        // constraint (which will affect all descendant nodes) and
        // resolve (indicated by curindex = -1); hopefully this will
        // help us close the gap.
        if(nocompviol == 1 && nodeptr->objoper == 0 && OBJOPER_RESOLVE) {
          if( nogap == 1 || comp_branch_kkt_extended(cursoln.primalbnd, cursoln.xval, cursoln.y, cursoln.z,
                            nodeptr->fixedindices, nodeptr->fixedtypes, nodeptr->numfixed, env, lp[0])      )
            curindex = 0;
          else
            curindex = -1;
        }

        // If there's no violation and the objective constraint/operator
        // *has* been included, then we still need no gap to fathom.
        // (This is because we cannot guarantee that we've solved the
        // SDP to optimality. If we could be sure of that, fathoming
        // would be fine.) So we branch either on curindex or on the
        // first complementarity that hasn't already been enforced.
        // (There will be some index to branch on because our no-gap
        // check also includes the LP.)
        if( (nocompviol == 1 && nodeptr->objoper == 1 && OBJOPER_RESOLVE) || (nocompviol == 1 && !OBJOPER_RESOLVE) ) {
          if( nogap == 1 || comp_branch_kkt_extended(cursoln.primalbnd, cursoln.xval, cursoln.y, cursoln.z,
                            nodeptr->fixedindices, nodeptr->fixedtypes, nodeptr->numfixed, env, lp[0])      )
            curindex = 0;
          else {
            // Expand which indices have already been fixed into full 0-1 vector
            for(i = 1; i <= n+m; i++) fullfixedindices[i] = 0;
            for(i = 0; i < nodeptr->numfixed; i++) fullfixedindices[nodeptr->fixedindices[i]] = 1;
            // If curindex (as set above) has not already been fixed,
            // then branch on curindex. Otherwise, select the first
            // non-fixed index.
            if(fullfixedindices[curindex] == 1) {
              curindex = 0;
              for(i = 1; i <= n+m; i++)
                if(fullfixedindices[i] == 0) {
                  curindex = i;
                  if(curindex <= n) curtype = 21;
                  else              curtype = 11;
                  break;
                }
              if(curindex == 0) { printf("Uh-oh! No index to branch on. Something wrong.\n"); exit(0); }
            }
          }
        }
        
//         if(maxviol < MY_EPS) {

//           if(fabs(cursoln.relaxbnd - cursoln.primalbnd)/(0.5*(fabs(cursoln.relaxbnd) + fabs(cursoln.primalbnd))) < MY_EPS || nodeptr->objoper == 1)
//             curindex = 0;
//           else {
//             if( comp_branch_kkt_extended(cursoln.primalbnd, cursoln.xval, cursoln.y, cursoln.z, nodeptr->fixedindices, nodeptr->fixedtypes, nodeptr->numfixed, env, lp[0]) ) {
//               curindex = 0;
// //               temp_success = 1;
//             }
//             else {
// //               temp_success = -1;
//               curindex = -1;
//               // Setting curindex = -1 will indicate that we should
//               // enforce the objective operator at this node and
//               // resolve.
//               // First, some sanity checks
//               if(curindex == -1 && OBJOPER == 1) {
//                 printf("Warning: Encountered situation that (in theory) should only occur when OBJOPER = 0.\n");
//                 fflush(stdout);
//               }

//               // my_earlyterm_tol = 0.5*(1.0 + my_earlyterm_tol);
//               // cblas_dscal(ddim, 0.0, dvar, 1);
//             }
//           }
//         }

        if(curindex > 0) { // Something to branch on, creating two children nodes
          partition (nodeptr, curindex, curtype);
          numintree += 2;
          printf ("'branch' (vio = %.1e) ", maxviol);
        }
        else if(curindex == -1) {
          nodeptr->objoper = 1;
          nodeptr->rank = 1.0e10;
          InsertPQTree(pq, (void **) &nodeptr, &(nodeptr->rank));
          numintree++; numouttree--;
          printf("'resolve'                ");
        }
        else printf ("'feas'                   ");

      } 

      // Try to update ZLB
      tempval = matlab_primal (cursoln.xval, ep);
      if (mymax(tempval, cursoln.primalbnd) > ZLB) {
        ZLB = mymax (tempval, cursoln.primalbnd);
        newzlb = 1;
//         fprintf (bestsolnfile, "%% may be possible to improve locally\nxprimal = [ ");
//         for (i = 0; i < n; i++)
//           fprintf (bestsolnfile, "%.16e\n", mymin (mymax (cursoln.xval[i], 0.0), 1.0));
//         fprintf (bestsolnfile, "];\n\n");
      }

      // Check tree for nodes to be fathomed
      oldnumintree = numintree;
      FathomTree (ZLB, &numintree);

      printf("[trsz %3d] ", numintree);

      if(oldnumintree > numintree) printf("(%d nodes fathomed)\n", oldnumintree - numintree);
      else printf("\n");

      // Free node memory
      if (cursoln.xval) MYFREE (cursoln.xval);
      if (cursoln.y) MYFREE (cursoln.y);
      if (cursoln.z) MYFREE (cursoln.z);
      if(curindex != -1) free_nodeinfo (nodeptr); // Should not free memory when we resolve to add OBJOPER=1
    }
    else if (cursoln.problemcode == 1977) {
      if(PRINTSTYLE == 1) {
//         printf("NODE %3d:                                 ", numouttree, ZLB, cursoln.relaxbnd);
        printf("NODE %3d:                                 ", numouttree);
      }
      printf("  ");
      printf ("'infeas'                 ");
      printf("[trsz %3d]\n", numintree);
    }
    else if (cursoln.problemcode != 1977) // Subproblem not infeasible nor optimal
      terminate ("Subproblem returned unexpected return code");

  } // End 'while tree not empty' loop

  printf ("Optimal value = % .8e\n", ZLB);
  printf ("Number of total nodes = %d\n", numouttree);
  printf ("Number of node evaluations = %d\n", numeval);

  dealloc_pdvars(pvar,dvar,ddir);

  MYFREE(xbar);
  engClose (ep);
  mxDestroyArray (mxQ);
  mxDestroyArray (mxc);
  mxDestroyArray (mxA);
  mxDestroyArray (mxb);
  mxDestroyArray (mxn);
//   fclose (bestsolnfile);

  return (0);
}

int comp_branch_kkt_extended(double pval, double *x, double *y, double *z, int *fixedindices, int *fixedtypes, int numfixedindices, CPXENVptr env, CPXLPptr lp0)
{
  CPXLPptr lp;
//   int *fixedindices, *fixedtypes, numfixedindices;
  int status, i, j;
  int     k, localdim;
  int    *bdinds, *indices;
  char   *bdtypes, *sense;
  double *bds;
  int    numbnds;
  int    numsense;
  double *tempc;
  // Soln from run_subgrad
  SOLNINFO            finalsoln;
  double objval;

  // Just to be careful, copy lp[0] over to new LP structure
  lp = CPXcloneprob(env, lp0, &status);
  if (status) { fprintf(stderr, "Problem copying lp0 to lp\n"); return(1); }

  // 
  // Setup the lp problem to be solved. A lot of this copied from
  // reset_bounds() and run_node_subgrad(). We assume KKTLVL > 0.
  //

  // First: Make sure all explicit bounds are reset
  // First: Make sure all explicit bounds are reset
  // First: Make sure all explicit bounds are reset

  // Setup relevant dimension
  if(KKTLVL != 1) localdim = N+1;
  else            localdim = N+1 + n+m;

  // Allocate memory
  bds     = (double*)calloc(2*localdim, sizeof(double));
  bdtypes = (char*)  calloc(2*localdim, sizeof(char));
  bdinds  = (int*)   calloc(2*localdim, sizeof(int));

  // Fill memory with lower bounds of 0 and upper bounds of +infty
  for (i = 0; i < localdim; i++) {
    // lower
    bds    [i] = 0.0;
    bdtypes[i] = 'L';
    bdinds [i] = i;
    // upper
    bds    [localdim+i] = CPX_INFBOUND;
    bdtypes[localdim+i] = 'U';
    bdinds [localdim+i] = i;
  }
  bds[localdim] = 1.0; // except 0-th component has upper bound of 1.0

  // Call CPLEX to reset bounds
  status = CPXchgbds (env, lp, 2*localdim, bdinds, bdtypes, bds);
  if (status) { fprintf (stderr, "comp_branch_kkt_extended: Problem changing lp bounds.\n"); exit (0); }

  // Fix x0 to 1.0 (already upper bounded by 1.0)
  mychgbds(env, lp, 0, 1.0, 'L');

  // Free memory
  MYFREE (bds);
  MYFREE (bdtypes);
  MYFREE (bdinds);

  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset
  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset
  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset

  // This assumes Ax <= x0 b are the first m constraints
 
  indices = (int*) calloc(m, sizeof(int));
  sense   = (char*)calloc(m, sizeof(char));

  for(i = 0; i < m; i++) {
    indices[i] = i;
    sense  [i] = 'L';
  }

  for(k = 0; k < 3; k++) {
    status = CPXchgsense(env, lp, m, indices, sense);
    if (status) { fprintf (stderr, "comp_branch_kkt_extended: Problem changing implicit upper bounds.\n"); exit(0); }
  }

  MYFREE(indices);
  MYFREE(sense);

  // Third: Change bounds to enforce x=0 (code 22)
  // Third: Change bounds to enforce x=0 (code 22)
  // Third: Change bounds to enforce x=0 (code 22)
  
  // Allocate space for bound info
  bds     = (double *) calloc (numfixedindices, sizeof (double));
  bdtypes = (char *)   calloc (numfixedindices, sizeof (char));
  bdinds  = (int *)    calloc (numfixedindices, sizeof (int));

  // Alter according to 'fixed' information
  k = 0;
  for (j = 0; j < numfixedindices; j++)
    if (fixedtypes[j] == 22) {
      bds    [k] = 0.0;
      bdtypes[k] = 'U';
      bdinds [k] = fixedindices[j];
      k++;
  }

  numbnds = k; // Number of bounds to change

  // Call CPLEX to change bounds
  status = CPXchgbds (env, lp, numbnds, bdinds, bdtypes, bds);
  if (status) { fprintf (stderr, "comp_branch_kkt_extended: Problem changing lp bounds.\n"); finalsoln.problemcode = 1; exit(0); }

  // Deallocate space
  MYFREE (bds);     bds     = NULL;
  MYFREE (bdtypes); bdtypes = NULL;
  MYFREE (bdinds);  bdinds  = NULL;

  // Fourth: Change sense to enforce Ax = b (code 12)
  // Fourth: Change sense to enforce Ax = b (code 12)
  // Fourth: Change sense to enforce Ax = b (code 12)

  indices = (int*) calloc(numfixedindices, sizeof(int));
  sense   = (char*)calloc(numfixedindices, sizeof(char));

  k = 0; 
  for (j = 0; j < numfixedindices; j++)
    if (fixedtypes[j] == 12) {
      if(KKTLVL == 0) indices[k] = fixedindices[j] - 1;
      else            indices[k] = fixedindices[j] - (n+1);
      sense[k] = 'E';
      k++;
  }

  numsense = k;

  status = CPXchgsense(env, lp, numsense, indices, sense); 
  if (status) { fprintf (stderr, "comp_branch_kkt_extended: Problem changing sense of inequalities.\n"); finalsoln.problemcode = 1; exit(0); }

  MYFREE(indices); indices = NULL;
  MYFREE(sense);   sense = NULL;

  // Fifth: If KKTLVL > 0 (we assume this), change bounds to enforce y=0 and z=0 (codes 11 and 21)
  // Fifth: If KKTLVL > 0 (we assume this), change bounds to enforce y=0 and z=0 (codes 11 and 21)
  // Fifth: If KKTLVL > 0 (we assume this), change bounds to enforce y=0 and z=0 (codes 11 and 21)

  bds     = (double *) calloc (numfixedindices, sizeof (double));
  bdtypes = (char *)   calloc (numfixedindices, sizeof (char));
  bdinds  = (int *)    calloc (numfixedindices, sizeof (int));

  k = 0;
  for (j = 0; j < numfixedindices; j++)
    if (fixedtypes[j] == 11 || fixedtypes[j] == 21) {
      bds    [k] = 0.0;
      bdtypes[k] = 'U';
      if(fixedindices[j] > n) bdinds[k] = (n+1) + (fixedindices[j] - (n+1))                      ;
      else                    bdinds[k] = (n+1) +             m             + (fixedindices[j]-1);
      k++;
    }

  numbnds = k; // Number of bounds to change

  status = CPXchgbds (env, lp, numbnds, bdinds, bdtypes, bds);
  if (status) { fprintf (stderr, "comp_branch_kkt_extended: Problem changing lp bounds.\n"); finalsoln.problemcode = 1; exit(0); }

  MYFREE (bds);     bds     = NULL;
  MYFREE (bdtypes); bdtypes = NULL;
  MYFREE (bdinds);  bdinds  = NULL;

  // Sixth: Setup linear objective
  // Sixth: Setup linear objective
  // Sixth: Setup linear objective

  // Allocate tempc and temp_indices
  MYCALLOC(tempc, double, localdim);
  MYCALLOC(temp_indices, int, localdim); for(i = 0; i < localdim; i++) temp_indices[i] = i;

  // Setup objective function
  if(localdim != 1+n+m+n) { printf("comp_branch_kkt_extended: Dims don't match"); exit(0); } // Sanity
  tempc[0] = 0.0;
  for(i = 1; i <= n; i++)         tempc[i] = 0.5*qpc[i-1];
  for(i = n+1; i <= n+m; i++)     tempc[i] = 0.5*qpb[i-(n+1)];
  for(i = n+m+1; i <= n+m+n; i++) tempc[i] = 0.0;

  // Change CPLEX objective 
  status = CPXchgobj(env, lp, localdim, temp_indices, tempc);
  if (status) { fprintf(stderr, "comp_branch_kkt_extended: Problem changing lp objective\n"); exit(1); }

  // Free tempc and temp_indices
  MYFREE(tempc); tempc = NULL;
  MYFREE(temp_indices); temp_indices = NULL;

  // Seventh: Solve LP
  // Seventh: Solve LP
  // Seventh: Solve LP
 
  solve_lp_subprob(env, lp, &objval);

//   printf("\n\npval = %f\nobjval = %f\n", pval, objval);

  // Cleanup
  // Cleanup
  // Cleanup
  
  status = CPXfreeprob(env, &lp);
  if (status) { fprintf(stderr, "comp_branch_kkt_extended: Problem freeing lp\n"); return(1); }
  usleep(5000000); // Wait for CPLEX license to be freed.

//   MYFREE(fixedindices);
//   MYFREE(fixedtypes);

//   printf("** %e **", fabs(objval - pval)/(0.5*(fabs(objval) + fabs(pval))));
  if(fabs(objval - pval)/(0.5*(fabs(objval) + fabs(pval))) < MY_EPS)
    return 1;
  else
    return 0;
}

