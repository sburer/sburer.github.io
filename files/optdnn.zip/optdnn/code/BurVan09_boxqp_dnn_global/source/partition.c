#include "all.h"

//This function creates two child nodes based on curindex and curtype
int partition(NODEINFO *nodeptr, int curindex, int curtype)
{
  int i;
  NODEINFO *upnode, *downnode;  

  // Allocate memory for children
  MYMALLOC(downnode, NODEINFO);
  MYMALLOC(upnode,   NODEINFO);

  MYCALLOC(downnode->fixedindices, int, nodeptr->numfixed+1);
  MYCALLOC(downnode->fixedtypes,   int, nodeptr->numfixed+1);
  MYCALLOC(upnode  ->fixedindices, int, nodeptr->numfixed+1);
  MYCALLOC(upnode  ->fixedtypes,   int, nodeptr->numfixed+1);

  // Copy upper bounds
  downnode->zrelax = nodeptr->zrelax;
  upnode  ->zrelax = nodeptr->zrelax;
  downnode->rank   = nodeptr->zrelax;
  upnode  ->rank   = nodeptr->zrelax;

  // Specify number of fixings
  downnode->numfixed = nodeptr->numfixed+1;
  upnode  ->numfixed = nodeptr->numfixed+1;

  // Copy parent fixings
  for(i = 0; i < nodeptr->numfixed; i++) {
    downnode->fixedindices[i] = nodeptr->fixedindices[i];
    upnode  ->fixedindices[i] = nodeptr->fixedindices[i];
    downnode->fixedtypes[i]   = nodeptr->fixedtypes[i];
    upnode  ->fixedtypes[i]   = nodeptr->fixedtypes[i];
  }

  // Set additional fixing for each child
  downnode->fixedindices[nodeptr->numfixed] = curindex;
  upnode  ->fixedindices[nodeptr->numfixed] = curindex;
  if(KKTLVL == 0) {
    if(qpQ[(curindex-1)*n + curindex-1] < 0.0) {
      downnode->fixedtypes[nodeptr->numfixed] = curtype;
      upnode  ->fixedtypes[nodeptr->numfixed] = curtype+1;
    }
    else {
      downnode->fixedtypes[nodeptr->numfixed] = 12;
      upnode  ->fixedtypes[nodeptr->numfixed] = 22;
    }
  }
  else {
    downnode->fixedtypes[nodeptr->numfixed] = curtype;
    upnode  ->fixedtypes[nodeptr->numfixed] = curtype+1;
  }
    
  // Setup and copy dual variables (if HOTSTART = 2)
  if(HOTSTART == 2) {
    MYCALLOC(downnode->dvar, double, ddim);
    MYCALLOC(upnode  ->dvar, double, ddim);
    cblas_dcopy(ddim, nodeptr->dvar, 1, downnode->dvar, 1);
    cblas_dcopy(ddim, nodeptr->dvar, 1, upnode  ->dvar, 1);
   }

  // Insert default value of OBJOPER (dependent on resetting OBJOPER
  // after solution of node in bandb.c)
  downnode->objoper = nodeptr->objoper;
  upnode  ->objoper = nodeptr->objoper;

  // Insert new nodes into tree
  InsertPQTree(pq, (void **) &downnode, &(downnode->rank));
  InsertPQTree(pq, (void **) &upnode, &(upnode->rank));
  
  return(0);

} // End partition function
