/*
 * MEMORY SUB SYSTEM
 *
 * The memory sub system will help to detect some bugs involving
 * improper memory use. Furthermore it will give some statistics.
 */

#ifdef MEMORYSUB

#include <stdio.h>
#include <stdlib.h>

/*
 * Forward references
 */

#ifdef PROTOTYPING
char * _new_ (unsigned, char *, unsigned);
void _free_ (char *, char *, unsigned);
void START (void);
void TERMINATE (void);
int VERIFY (void);
#else
char * _new_ ();
void _free_ ();
void START ();
void TERMINATE ();
int VERIFY ();
#endif

#define MAGICKEY  0x5296     /* for a 16 bits CPU */

#define ALLOC_VAL 0xA5       /* NEW'ed memory is filled with this   */
                             /* value so that references to it will */
                             /* end up being very strange.          */
#define FREE_VAL  0x8F       /* FREE'ed memory is filled with this  */
                             /* value so that references to it will */
                             /* also end up being strange.          */

#define MAGICEND0  0x68    /* Magic values for overrun keys  */
#define MAGICEND1  0x34    /*               "                */
#define MAGICEND2  0x7A    /*               "                */
#define MAGICEND3  0x15    /*               "                */
        /* Warning: do not change the MAGICEND? values to */
        /* something with the high bit set.  Various C    */
        /* compilers (like the 4.2bsd one) do not do the  */
        /* sign extension right later on in this code and */
        /* you will get erroneous errors.                 */

typedef unsigned uns;    /* Shorthand */

struct REMEMBER_INTERNAL {
    struct REMEMBER *_pNext;  /* Linked list of structures       */
    struct REMEMBER *_pPrev;  /* Other link                      */
    char *_sFileName;         /* File in which memory was new'ed */
    uns   _uLineNum;          /* Line number is above file       */
    uns   _uDataSize;         /* Size requested                  */
    uns   _lSpecialValue;     /* Underrun marker value           */
    };

struct REMEMBER {
    struct REMEMBER_INTERNAL tInt;
    char     aData[1];
    };

#define pNext         tInt._pNext
#define pPrev         tInt._pPrev
#define sFileName     tInt._sFileName
#define uLineNum      tInt._uLineNum
#define uDataSize     tInt._uDataSize
#define lSpecialValue tInt._lSpecialValue

static long lCurMemory = 0;  /* Current memory usage              */
static long lMaxMemory = 0;  /* Maximum memory usage              */
                 /* Note: both these refer to the NEW'ed  */
                 /*       data only.  they do not include */
                 /*       malloc() roundoff or the extra  */
                 /*       space required by the REMEMBER  */
                 /*       structures.                     */

static uns cNewCount = 0;    /* Number of times NEW() was called */

static struct REMEMBER *pRememberRoot = NULL;
            /* Root of the linked list of REMEMBERs */

static    FILE    *fp_alloc;    /* file pointer to memory information */

/*
 * _new_ 
 */
 
char *
_new_ (uSize, sFile, uLine)
uns uSize, uLine;
char *sFile;
{
    struct REMEMBER *pTmp;
    char *pPtr;

    /*
     * Allocate the physical memory
     */
     
    pTmp = (struct REMEMBER *) malloc (
          sizeof(struct REMEMBER_INTERNAL) /* REMEMBER data  */
          + uSize                /* size requested */
          + 4                   /* overrun mark   */
        );

    /*
     * Check if there isn't anymore memory avaiable
     */
     
    if (pTmp == NULL) {
        fprintf (fp_alloc,
            "Out of memory at line %d, \"%s\"\n",
            uLine, sFile );
        fprintf (fp_alloc,
            "\t(memory in use: %ld bytes (%ldk))\n",
            lMaxMemory, (lMaxMemory + 1023L)/1024L );
        return (NULL);
    }

    /* Fill up the structure */
    pTmp->lSpecialValue  = MAGICKEY;
    pTmp->aData[uSize+0] = MAGICEND0;
    pTmp->aData[uSize+1] = MAGICEND1;
    pTmp->aData[uSize+2] = MAGICEND2;
    pTmp->aData[uSize+3] = MAGICEND3;
    pTmp->sFileName      = sFile;
    pTmp->uLineNum       = uLine;
    pTmp->uDataSize      = uSize;
    pTmp->pNext          = pRememberRoot;
    pTmp->pPrev          = NULL;

    /*
     * Add this REMEMBER structure to the linked list
     */
     
    if (pRememberRoot)
        pRememberRoot->pPrev = pTmp;
    pRememberRoot = pTmp;

    /*
     * Keep the statistics
     */
     
    lCurMemory += uSize;
    if (lCurMemory > lMaxMemory)
        lMaxMemory = lCurMemory;
    cNewCount++;

    /*
     * Set the memory to the aribtrary wierd value
     */
     
    for (pPtr = &pTmp->aData[uSize]; pPtr > &pTmp->aData[0]; )
        *(--pPtr) = ALLOC_VAL;

    /*
     * Return a pointer to the real data
     */
     
    return ((char *) &(pTmp->aData[0]));
}

/*
 * _free_
 */
 
void
_free_ (pPtr, sFile, uLine)
char *pPtr,*sFile;
uns uLine;
{
    struct REMEMBER *pRec;
    char *pTmp;
    uns uSize;

    /*
     * Check if we have a non-null pointer
     */
     
    if (pPtr == NULL) {
        fprintf(fp_alloc,
            "Freeing NULL pointer at line %d, \"%s\"\n",
            uLine, sFile );
        return;
    }

    /*
     * Calculate the address of the REMEMBER structure
     */
     
    pRec = (struct REMEMBER *) (pPtr - (sizeof(struct REMEMBER_INTERNAL)));

    /*
     * Check to make sure that we have a real REMEMBER structure
     */
     
    /*
     * Note: this test could fail for four reasons:
     * (1) The memory was already free'ed
     * (2) The memory was never new'ed
     * (3) There was an underrun
     * (4) A stray pointer hit this location
     */

    if (pRec->lSpecialValue != MAGICKEY) {
        fprintf(fp_alloc,
            "Freeing unallocated data at line %d, \"%s\"\n",
            uLine, sFile );
        return;
    }

    /*
     * Check for an overrun
     */
     
    uSize = pRec->uDataSize;
    if (pRec->aData[uSize+0] != MAGICEND0 ||
        pRec->aData[uSize+1] != MAGICEND1 ||
        pRec->aData[uSize+2] != MAGICEND2 ||
        pRec->aData[uSize+3] != MAGICEND3) {
          fprintf(fp_alloc,
            "Memory being free'ed at line %d, \"%s\" was overrun\n",
            uLine, sFile );
          fprintf(fp_alloc,
            "\t(allocated at line %d, \"%s\")\n",
            pRec->uLineNum, pRec->sFileName );
          return;
    }

    /*
     * Remove this structure from the linked list
     */
     
    if (pRec->pPrev)
        pRec->pPrev->pNext = pRec->pNext;
    else
        pRememberRoot = pRec->pNext;
    if (pRec->pNext)
        pRec->pNext->pPrev = pRec->pPrev;

    /*
     * Mark this data as free'ed
     */
     
    for (pTmp = &pRec->aData[pRec->uDataSize]; pTmp > &pRec->aData[0] ; )
        *(--pTmp) = FREE_VAL;
    pRec->lSpecialValue = ~MAGICKEY;

    /*
     * Handle the statistics
     */
     
    lCurMemory -= pRec->uDataSize;
    cNewCount--;

    /*
     * Actually free the memory
     */
     
    free ((char*)pRec);
}

/*
 * START
 */
 
void
START ()
{
    if ((fp_alloc = fopen("myalloc.log", "w")) == NULL) {
        fprintf (stderr, "Couldn't open `myalloc.log'\n");
        exit (1);
    }

    fprintf (fp_alloc,"MEMORY REPORT\n");
}

/*
 * TERMINATE
 */
 
void
TERMINATE ()
{
    struct REMEMBER *pPtr;

    /*
     * Report the difference between number of calls to NEW and the number of
     * calls to FREE. >0 means more NEWs than FREEs. <0, etc.
     */
     
    if (cNewCount)
        fprintf (fp_alloc, "#calls NEW - #calls FREE: %d\n", cNewCount);

    /*
     * Report on all the memory that was allocated with NEW but not free'ed
     * with FREE.
     */
     
    if (pRememberRoot != NULL)
        fprintf (fp_alloc, "Memory that was not free'ed:\n");
    pPtr = pRememberRoot;
    while (pPtr) {
        fprintf (fp_alloc,
            "\t%5d bytes allocated at line %3d in \"%s\"\n",
            pPtr->uDataSize, pPtr->uLineNum, pPtr->sFileName);
        pPtr = pPtr->pNext;
    }

    /*
     * Report the memory usage statistics
     */
     
    fprintf (fp_alloc,
        "Maximum memory usage: %ld bytes (%ldk)\n",
        lMaxMemory, (lMaxMemory + 1023L)/1024L);

    fclose (fp_alloc);
}

/*
 * VERIFY
 */
 
int
VERIFY ()
{
    struct REMEMBER *pPtr;
    uns uSize;
    uns status = 1;
    
    if (pRememberRoot != NULL) {
        pPtr = pRememberRoot;
        while (pPtr) {
        
            /*
             * Check for an overrun
             */
     
            uSize = pPtr->uDataSize;
            if (pPtr->aData[uSize+0] != MAGICEND0 ||
                pPtr->aData[uSize+1] != MAGICEND1 ||
                pPtr->aData[uSize+2] != MAGICEND2 ||
                pPtr->aData[uSize+3] != MAGICEND3) {
                  status = 0;
                  fprintf(fp_alloc,
                    "Memory allocated at line %d (\"%s\") has been overrun\n",
                    pPtr->uLineNum, pPtr->sFileName );
            }
            
            pPtr = pPtr->pNext;
        }
    }

    return (status);
}

#endif
