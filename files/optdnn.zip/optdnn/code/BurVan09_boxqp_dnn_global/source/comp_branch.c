#include "all.h"

double comp_branch(int *newind, int *newtype, double *xval)
{
	int i, j;
   double tempval;
	double *yval, *zval;

	yval = (double *) calloc(n, sizeof(double));
	zval = (double *) calloc(n, sizeof(double));

	for(i = 0; i < n; i++)
	{
		tempval = qpc[i];
		for(j = 0; j < n; j++)
		{
			tempval += qpQ[j*n + i]*xval[j];
		}
		if (tempval >= 0)
		{
			yval[i] = tempval;
			zval[i] = 0.0;
		}
		else
		{
			zval[i] = -tempval;
			yval[i] = 0.0;
		}
	}  //End i loop
	
//         tempval = MY_EPS;
	tempval = -1.0e10;
	*newind = -1;
	for(i = 0; i < n; i++)
	{
		if (ybar[i] > 0)
		{
			if ((1 - xval[i])*yval[i]/ybar[i] > tempval)
			{
				*newind = i;
				*newtype = 11;
				tempval = (1 - xval[i])*yval[i]/ybar[i];
			}
		}
		else  //if ybar[i] = 0 (strange case, could add constraints for this)
		{
		   if ((1 - xval[i])*yval[i] > tempval)
			{
				*newind = i;
				*newtype = 11;
				tempval = (1 - xval[i])*yval[i];
			}
		}

		if (zbar[i] > 0)
		{
			if (xval[i]*zval[i]/zbar[i] > tempval)
			{
				*newind = i;
				*newtype = 21;
				tempval = xval[i]*zval[i]/zbar[i];
			}
		}
		else // zbar[i] = 0
		{		
			if (xval[i]*zval[i] > tempval)
			{
				*newind = i;
				*newtype = 21;
				tempval = xval[i]*zval[i];
			}
		}
	} //End for i
	(*newind)++;
	if (yval != NULL)
		MYFREE(yval);
	if (zval != NULL)
		MYFREE(zval);
//	printf("maxviol = %.6e\n", tempval);
	return(tempval);
}


double comp_branch_kkt(int *newind, int *newtype, double *x, double *y, double *z)
{
  int i, j;
  double *bmAx;
  double maxviol = -1.0e10;
  double sc_yBAR, sc_zBAR;

  sc_yBAR    = yBAR   /(double)m;
  sc_zBAR    = zBAR   /(double)n;

  // Allocate space for b - Ax
  bmAx = (double*)calloc(m, sizeof(double));

  // Calculate b - Ax
  for(i = 0; i < m; i++) {
    bmAx[i] = qpb[i];
    for(j = 0; j < n; j++)
      bmAx[i] -= qpA[j*m + i]*x[j];
  }

  // Check (b - Ax) * y
  for(i = 0; i < m; i++)
    if(  (bmAx[i]/bmAxbar[i])*(y[i]/sc_yBAR)  > maxviol  ) {
      maxviol = (bmAx[i]/bmAxbar[i])*(y[i]/sc_yBAR);
      *newind = n+1 + i;
      *newtype = 11;
    }

  // Free space
  MYFREE(bmAx);

  // Check x * z 
  for(i = 0; i < n; i++)
    if(  (x[i]/xbar[i])*(z[i]/sc_zBAR)  > maxviol  ) {
      maxviol = (x[i]/xbar[i])*(z[i]/sc_zBAR);
      *newind = 1 + i;
      *newtype = 21;
    }

  return maxviol;
}
