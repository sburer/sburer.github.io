#include "all.h"

int N;
int YDIM;
int ZDIM;
int UDIM;
int LDIM;

void get_pddims(void)
{
  N = n + (KKTLVL == 2)*(m + n);

  YDIM = ((N+1)*(N+1));
  ZDIM = ((N+1)*(N+1));
  UDIM = ((N+2)*(N+1)/2);
  LDIM = ((N+1)*N/2);

  pdim = YDIM + PSD*UDIM + UBE*ZDIM + (KKTLVL == 1)*(m + n);
  ddim = LDIM + PSD*UDIM + UBE*ZDIM + (KKTLVL == 2)*m + (OBJOPER && KKTLVL  > 0)*1;
}

void alloc_pdvars(double **passed_pvar, double **passed_dvar, double **passed_ddir)
{
  double *pvar = NULL;
  double *dvar = NULL;
  double *ddir = NULL;

  get_pddims();

  pvar = (double*)calloc(pdim, sizeof(double));
  dvar = (double*)calloc(ddim, sizeof(double));
  ddir = (double*)calloc(ddim, sizeof(double));

  *passed_pvar = pvar;
  *passed_dvar = dvar;
  *passed_ddir = ddir;
}

void dealloc_pdvars(double *pvar, double *dvar, double *ddir)
{
  free(pvar);
  free(dvar);
  free(ddir);
}

void assign_pdvars(double *pvar, double *dvar, double *ddir, double **Y, double **U, double **Z, double **y, double **z, double **sym_lambda, double **S, double **z_lambda, double **obj_lambda, double **ycomp_lambda, double **sym_dir, double **S_dir, double **z_dir, double **obj_dir, double **ycomp_dir, int pvar_yes, int dvar_yes, int ddir_yes)
{
  double *ptr;

  if(pvar_yes) {
                                ptr =  pvar;
                      *Y = ptr; ptr += YDIM;
    if(PSD)         { *U = ptr; ptr += UDIM; }
    if(UBE)         { *Z = ptr; ptr += ZDIM; }
    if(KKTLVL == 1) { *y = ptr; ptr += m;    
                      *z = ptr; ptr += n;    }
    // Extra added by Sam 1/25/06 (just for compatibility)
    if(KKTLVL == 2) { *y = Y + 1 + n;
                      *z = Y + 1 + n + m;    }

  }

  if(dvar_yes) {
                                                     ptr =  dvar;
                                *sym_lambda   = ptr; ptr += LDIM;
    if(PSD)                   { *S            = ptr; ptr += UDIM; }
    if(UBE)                   { *z_lambda     = ptr; ptr += ZDIM; }
    if(KKTLVL == 2)           { *ycomp_lambda = ptr; ptr += m;    } 
    if(OBJOPER && KKTLVL > 0) { *obj_lambda   = ptr; ptr += 1;    } 
  }

  if(ddir_yes) {
                                                  ptr =  ddir;
                                *sym_dir   = ptr; ptr += LDIM;
    if(PSD)                   { *S_dir     = ptr; ptr += UDIM; }
    if(UBE)                   { *z_dir     = ptr; ptr += ZDIM; }
    if(KKTLVL == 2)           { *ycomp_dir = ptr; ptr += m;    } 
    if(OBJOPER && KKTLVL > 0) { *obj_dir   = ptr; ptr += 1;    } 
  }

}

