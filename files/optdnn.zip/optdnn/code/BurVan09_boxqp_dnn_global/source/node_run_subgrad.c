#include "all.h"

// This routine solves a node of our b&b tree.

// We assume that the LP and QP problems have the basic box QP
// structure or the basic KKT structure.

// Numfixedindices is the number of branching decisions already made,
// i.e., the number of indices already branched on.

// Fixedindices lists the indices i branched on (not necessarily in
// order).

// Fixedtypes lists the types of branches for the indices:
//    (KKTLVL = 0)             (KKTLVL = 1 or 2)
//   11  --  y = 0              11  --   y = 0       
//   12  --  x = 1, z = 0       12  --  Ax = b 
//   21  --  z = 0              21  --   z = 0
//   22  --  x = 0, y = 0       22  --   x = 0

// In a nutshell, this routine
//   * strips any non-basic constraints from the LP and QP problem
//     (such constraints would come from solving previous nodes)
//   * adds constraints specific for this node
//   * solves with run_subgrad

// Not much is provided in the way of output at this moment.

int reset_bounds (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp)
{
  int     i, k, status, localdim;
  int    *bdinds, *indices;
  char   *bdtypes, *sense;
  double *bds;

  // First: Make sure all explicit bounds are reset
  // First: Make sure all explicit bounds are reset
  // First: Make sure all explicit bounds are reset

  // Setup relevant dimension
  if(KKTLVL != 1) localdim = N+1;
  else            localdim = N+1 + n+m;

  // Allocate memory
  bds     = (double*)calloc(2*localdim, sizeof(double));
  bdtypes = (char*)  calloc(2*localdim, sizeof(char));
  bdinds  = (int*)   calloc(2*localdim, sizeof(int));

  // Fill memory with lower bounds of 0 and upper bounds of +infty
  for (i = 0; i < localdim; i++) {
    // lower
    bds    [i] = 0.0;
    bdtypes[i] = 'L';
    bdinds [i] = i;
    // upper
    bds    [localdim+i] = CPX_INFBOUND;
    bdtypes[localdim+i] = 'U';
    bdinds [localdim+i] = i;
  }
  bds[localdim] = 1.0; // except 0-th component has upper bound of 1.0

  // Call CPLEX to reset bounds (note different code for different KKTLVL)
  if(KKTLVL == 0 || KKTLVL == 2) {
    for (k = 0; k < 3; k++) {
      status = CPXchgbds (env, lp[k], 2*localdim, bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "reset_bounds: Problem changing lp bounds.\n"); exit (0); }
      status = CPXchgbds (env, qp[k], 2*localdim, bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "reset_bounds: Problem changing qp bounds.\n"); exit (0); }
    }
  }
  else {

    status = CPXchgbds (env, lp[0], 2*localdim, bdinds, bdtypes, bds);
    if (status) { fprintf (stderr, "reset_bounds: Problem changing lp bounds.\n"); exit (0); }
    status = CPXchgbds (env, qp[0], 2*localdim, bdinds, bdtypes, bds);
    if (status) { fprintf (stderr, "reset_bounds: Problem changing qp bounds.\n"); exit (0); }

    for (i = 0; i < n+1; i++) {
      bds    [i] = 0.0;
      bdtypes[i] = 'L';
      bdinds [i] = i;
      bds    [n+1 + i] = CPX_INFBOUND;
      bdtypes[n+1 + i] = 'U';
      bdinds [n+1 + i] = i;
    }
    bds[n+1] = 1.0;

    for (k = 1; k < 3; k++) {
      status = CPXchgbds (env, lp[k], 2*(n+1), bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "reset_bounds: Problem changing lp bounds.\n"); exit (0); }
      status = CPXchgbds (env, qp[k], 2*(n+1), bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "reset_bounds: Problem changing qp bounds.\n"); exit (0); }
    }

  }

  // For 0-th subproblems, fix x0 to 1.0 (already upper bounded by 1.0)
  mychgbds(env, lp[0], 0, 1.0, 'L');
  mychgbds(env, qp[0], 0, 1.0, 'L');

  // Free memory
  MYFREE (bds);
  MYFREE (bdtypes);
  MYFREE (bdinds);

  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset
  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset
  // Second: Make sure all implicit bounds (i.e., Ax <= x0 b) are reset

  // This assumes Ax <= x0 b are the first m constraints
 
  indices = (int*) calloc(m, sizeof(int));
  sense   = (char*)calloc(m, sizeof(char));

  for(i = 0; i < m; i++) {
    indices[i] = i;
    sense  [i] = 'L';
  }

  for(k = 0; k < 3; k++) {
    status = CPXchgsense(env, lp[k], m, indices, sense);
    if (status) { fprintf (stderr, "reset_bounds: Problem changing implicit upper bounds.\n"); exit(0); }
    status = CPXchgsense(env, qp[k], m, indices, sense);
    if (status) { fprintf (stderr, "reset_bounds: Problem changing implicit upper bounds.\n"); exit(0); }
  }

  MYFREE(indices);
  MYFREE(sense);

  return 0;
}

SOLNINFO node_run_subgrad (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp, int *fixedindices, int *fixedtypes,
                           int numfixedindices,  double *pvar, double *dvar, double *ddir)
{
  int     h, i, j, k, status;
  int     nzcnt;
  int    *bdinds, *rmatbeg, *rmatind, numbnds;
  char   *bdtypes, *sense;
  double *bds, *rmatval;
  int    *indices, numsense;
  char   *skipcols;
  double *Y;

  // Soln from run_subgrad
  SOLNINFO            finalsoln;

  // First things first: Reset all subproblems to original form 
  // First things first: Reset all subproblems to original form 
  // First things first: Reset all subproblems to original form 

  // Reset bounds to original bounds (includes resetting xi = x0 to xi <= x0)
  reset_bounds (env, lp, qp);

  // If KKTLVL = 0, delete non-boxqp-basic rows
  if(KKTLVL == 0)
    for (k = 0; k < 3; k++) {
      if (CPXgetnumrows (env, lp[k]) > n) {
        status = CPXdelrows (env, lp[k], n, CPXgetnumrows (env, lp[k]) - 1);
        if (status) {
          fprintf (stderr, "Problem deleting lp rows.\n");
          finalsoln.problemcode = 1;
          finalsoln.z = NULL;
          finalsoln.y = NULL;
          finalsoln.xval = 0;
          finalsoln.primalbnd = 0;
          finalsoln.relaxbnd = 0; 
          finalsoln.fathom = 0;
          return (finalsoln);
        }
      }
      if (CPXgetnumrows (env, qp[k]) > n) {
        status = CPXdelrows (env, qp[k], n, CPXgetnumrows (env, qp[k]) - 1);
        if (status) {
          fprintf (stderr, "Problem deleting qp rows.\n");
          finalsoln.problemcode = 1;
          finalsoln.z = NULL;
          finalsoln.y = NULL;
          finalsoln.xval = 0;
          finalsoln.primalbnd = 0;
          finalsoln.relaxbnd = 0; 
          finalsoln.fathom = 0;
          return (finalsoln);
        }
      }
    }

  // Change bounds to enforce x=0 (code 22)
  // Change bounds to enforce x=0 (code 22)
  // Change bounds to enforce x=0 (code 22)
  
  // Allocate space for bound info
  bds     = (double *) calloc (numfixedindices, sizeof (double));
  bdtypes = (char *)   calloc (numfixedindices, sizeof (char));
  bdinds  = (int *)    calloc (numfixedindices, sizeof (int));

  // Alter according to 'fixed' information
  k = 0;
  for (j = 0; j < numfixedindices; j++)
    if (fixedtypes[j] == 22) {
      bds    [k] = 0.0;
      bdtypes[k] = 'U';
      bdinds [k] = fixedindices[j];
      k++;
    }

  numbnds = k; // Number of bounds to change

  // Call CPLEX to change bounds
  for (k = 0; k < 3; k++) {
    status = CPXchgbds (env, lp[k], numbnds, bdinds, bdtypes, bds);
    if (status) {
      fprintf (stderr, "Problem changing lp bounds.\n"); 
      finalsoln.problemcode = 1; 
      finalsoln.z = NULL;
      finalsoln.y = NULL;
      finalsoln.xval = 0;
      finalsoln.primalbnd = 0;
      finalsoln.relaxbnd = 0; 
      finalsoln.fathom = 0;
      return (finalsoln);
    }
    status = CPXchgbds (env, qp[k], numbnds, bdinds, bdtypes, bds);
    if (status) {
      fprintf (stderr, "Problem changing qp bounds.\n");
      finalsoln.problemcode = 1;
      finalsoln.z = NULL;
      finalsoln.y = NULL;
      finalsoln.xval = 0;
      finalsoln.primalbnd = 0;
      finalsoln.relaxbnd = 0; 
      finalsoln.fathom = 0;
      return (finalsoln);
    }
  }

  // Deallocate space
  MYFREE (bds);     bds     = NULL;
  MYFREE (bdtypes); bdtypes = NULL;
  MYFREE (bdinds);  bdinds  = NULL;


  // Change sense to enforce Ax = b (code 12)
  // Change sense to enforce Ax = b (code 12)
  // Change sense to enforce Ax = b (code 12)

  indices = (int*) calloc(numfixedindices, sizeof(int));
  sense   = (char*)calloc(numfixedindices, sizeof(char));

  k = 0; 
  for (j = 0; j < numfixedindices; j++)
    if (fixedtypes[j] == 12) {
      if(KKTLVL == 0) indices[k] = fixedindices[j] - 1;
      else            indices[k] = fixedindices[j] - (n+1);
      sense[k] = 'E';
      k++;
    }

  numsense = k;

  for(k = 0; k < 3; k++) {
    status = CPXchgsense(env, lp[k], numsense, indices, sense); 
    if (status) {
      fprintf (stderr, "Problem changing sense of inequalities.\n");
      finalsoln.problemcode = 1;
      finalsoln.z = NULL;
      finalsoln.y = NULL;
      finalsoln.xval = 0;
      finalsoln.primalbnd = 0;
      finalsoln.relaxbnd = 0; 
      finalsoln.fathom = 0;
      return (finalsoln);
    }
    status = CPXchgsense(env, qp[k], numsense, indices, sense); 
    if (status) { fprintf (stderr, "Problem changing sense of inequalities.\n"); finalsoln.problemcode = 1;
      finalsoln.z = NULL;
      finalsoln.y = NULL;
      finalsoln.xval = 0;
      finalsoln.primalbnd = 0;
      finalsoln.relaxbnd = 0; 
      finalsoln.fathom = 0;
      return (finalsoln); }
  }

  MYFREE(indices);
  MYFREE(sense); sense = NULL;

  // If KKTLVL > 0, change bounds to enforce y=0 and z=0 (codes 11 and 21)

  if(KKTLVL > 0) {

    bds     = (double *) calloc (numfixedindices, sizeof (double));
    bdtypes = (char *)   calloc (numfixedindices, sizeof (char));
    bdinds  = (int *)    calloc (numfixedindices, sizeof (int));

    k = 0;
    for (j = 0; j < numfixedindices; j++)
      if (fixedtypes[j] == 11 || fixedtypes[j] == 21) {
        bds    [k] = 0.0;
        bdtypes[k] = 'U';
        if(fixedindices[j] > n) bdinds[k] = (n+1) + (fixedindices[j] - (n+1))                      ;
        else                    bdinds[k] = (n+1) +             m             + (fixedindices[j]-1);
        k++;
      }

    numbnds = k; // Number of bounds to change

    if(KKTLVL == 1) {
      status = CPXchgbds (env, lp[0], numbnds, bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "Problem changing lp bounds.\n"); finalsoln.problemcode = 1;
        finalsoln.z = NULL;
        finalsoln.y = NULL;
        finalsoln.xval = 0;
        finalsoln.primalbnd = 0;
        finalsoln.relaxbnd = 0; 
        finalsoln.fathom = 0;
        return (finalsoln); }
      status = CPXchgbds (env, qp[0], numbnds, bdinds, bdtypes, bds);
      if (status) { fprintf (stderr, "Problem changing qp bounds.\n"); finalsoln.problemcode = 1;
        finalsoln.z = NULL;
        finalsoln.y = NULL;
        finalsoln.xval = 0;
        finalsoln.primalbnd = 0;
        finalsoln.relaxbnd = 0; 
        finalsoln.fathom = 0;
        return (finalsoln); }
    }
    else {
      for (k = 0; k < 3; k++) {
        status = CPXchgbds (env, lp[k], numbnds, bdinds, bdtypes, bds);
        if (status) { fprintf (stderr, "Problem changing lp bounds.\n"); finalsoln.problemcode = 1;
          finalsoln.z = NULL;
          finalsoln.y = NULL;
          finalsoln.xval = 0;
          finalsoln.primalbnd = 0;
          finalsoln.relaxbnd = 0; 
          finalsoln.fathom = 0;
          return (finalsoln); }
        status = CPXchgbds (env, qp[k], numbnds, bdinds, bdtypes, bds);
        if (status) { fprintf (stderr, "Problem changing qp bounds.\n"); finalsoln.problemcode = 1;
          finalsoln.z = NULL;
          finalsoln.y = NULL;
          finalsoln.xval = 0;
          finalsoln.primalbnd = 0;
          finalsoln.relaxbnd = 0; 
          finalsoln.fathom = 0;
          return (finalsoln); }
      }
    }

//    Add bounds for if x = 0 then y = 0 and if x = 1 then z = 0 
//    Disable by setting YZX_BRANCH to 0 in options.h
	 if (YZX_BRANCH)
	 {
		 k = 0;
		 for(j = 0; j < numfixedindices; j++)
		 {
			 if ((fixedtypes[j] == 12) && (fixedindices[j] >= n + 1 + (m - n))) //if x_i = 1 fixing
			 {
				 bds[k] = 0.0;
				 bdtypes[k] = 'U';
				 bdinds[k] = n+1 + m + (fixedindices[j] - (n+1) - (m-n)); //fix z_i = 0
				 k++;
			 }

			 if (fixedtypes[j] == 22)  // if x_i = 0 fixing
			 {
				 bds[k] = 0.0;
				 bdtypes[k] = 'U';
				 bdinds[k] = n+1 + (m - n) + fixedindices[j] - 1;  //fix y_i = 0
				 k++;
			 }
		 }
		 numbnds = k; // Number of bounds to change

		 if(KKTLVL == 1) {
			 status = CPXchgbds (env, lp[0], numbnds, bdinds, bdtypes, bds);
			 if (status) { fprintf (stderr, "Problem changing lp bounds.\n"); finalsoln.problemcode = 1;
                           finalsoln.z = NULL;
                           finalsoln.y = NULL;
                           finalsoln.xval = 0;
                           finalsoln.primalbnd = 0;
                           finalsoln.relaxbnd = 0; 
                           finalsoln.fathom = 0;
                           return (finalsoln); }
			 status = CPXchgbds (env, qp[0], numbnds, bdinds, bdtypes, bds);
			 if (status) { fprintf (stderr, "Problem changing qp bounds.\n"); finalsoln.problemcode = 1;
                           finalsoln.z = NULL;
                           finalsoln.y = NULL;
                           finalsoln.xval = 0;
                           finalsoln.primalbnd = 0;
                           finalsoln.relaxbnd = 0; 
                           finalsoln.fathom = 0;
                           return (finalsoln); }
		 }
		 else {
			 for (k = 0; k < 3; k++) {
				 status = CPXchgbds (env, lp[k], numbnds, bdinds, bdtypes, bds);
				 if (status) { fprintf (stderr, "Problem changing lp bounds.\n"); finalsoln.problemcode = 1;
                                   finalsoln.z = NULL;
                                   finalsoln.y = NULL;
                                   finalsoln.xval = 0;
                                   finalsoln.primalbnd = 0;
                                   finalsoln.relaxbnd = 0; 
                                   finalsoln.fathom = 0;
                                   return (finalsoln); }
				 status = CPXchgbds (env, qp[k], numbnds, bdinds, bdtypes, bds);
				 if (status) { fprintf (stderr, "Problem changing qp bounds.\n"); finalsoln.problemcode = 1;
                                   finalsoln.z = NULL;
                                   finalsoln.y = NULL;
                                   finalsoln.xval = 0;
                                   finalsoln.primalbnd = 0;
                                   finalsoln.relaxbnd = 0; 
                                   finalsoln.fathom = 0;
                                   return (finalsoln); }
			 }
		 }

	 } //End YZX_BRANCH
	 
	 MYFREE (bds);
	 MYFREE (bdtypes);
	 MYFREE (bdinds);

  }

  // If KKTLVL = 0, add rows corresponding to y=0 and z=0 (all codes)

  if(KKTLVL == 0) {

    //
    // Add rows
    //

    // Allocate space for row ptrs and sense
    rmatbeg = (int*) calloc(numfixedindices+1, sizeof(int));
    sense   = (char*)calloc(numfixedindices,   sizeof(char));

    // Setup rmatbeg and count number of nonzeros
    nzcnt = 0;
    for (j = 0; j < numfixedindices; j++) {
      rmatbeg[j] = nzcnt;
      for(i = 0; i <= n; i++) {
        if(i == 0) {
          if(fabs(qpc[fixedindices[j] - 1]) > 1.0e-10) nzcnt++;
        }
        else {
          if(fabs(qpQ[(i-1)*n + fixedindices[j]-1]) > 1.0e-10) nzcnt++;
        }
      } 
    }
    rmatbeg[numfixedindices] = nzcnt;

    // Allocate space for col indices and values
    rmatind = (int*)   calloc(nzcnt, sizeof(int));
    rmatval = (double*)calloc(nzcnt, sizeof(double));

    // Setup rows
    for (j = 0; j < numfixedindices; j++) {
      if (fixedtypes[j] == 12 || fixedtypes[j] == 21) sense[j] = 'G';
      else                                            sense[j] = 'L';
      h = 0;
      for (i = 0; i <= n; i++) {
        if (i == 0) {
          if(fabs(qpc[fixedindices[j] - 1]) > 1.0e-10) {
            rmatind[rmatbeg[j] + h] = i;
            rmatval[rmatbeg[j] + h] = qpc[fixedindices[j] - 1];
            h++;
          }
        }
        else {
          if(fabs(qpQ[(i-1)*n + fixedindices[j]-1]) > 1.0e-10) {
            rmatind[rmatbeg[j] + h] = i;
            rmatval[rmatbeg[j] + h] = qpQ[(i-1)*n + fixedindices[j]-1];
            h++;
          }
        }
      }
    }

    // Call CPLEX to add rows
    for (k = 0; k < 3; k++) {
      status = CPXaddrows (env, lp[k], 0, numfixedindices, nzcnt, NULL, sense, rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status) { fprintf (stderr, "Problem adding lp bounds.\n"); finalsoln.problemcode = 1;
        finalsoln.z = NULL;
        finalsoln.y = NULL;
        finalsoln.xval = 0;
        finalsoln.primalbnd = 0;
        finalsoln.relaxbnd = 0; 
        finalsoln.fathom = 0;
        return (finalsoln); }
      status = CPXaddrows (env, qp[k], 0, numfixedindices, nzcnt, NULL, sense, rmatbeg, rmatind, rmatval, NULL, NULL);
      if (status) { fprintf (stderr, "Problem adding qp bounds.\n"); finalsoln.problemcode = 1;
        finalsoln.z = NULL;
        finalsoln.y = NULL;
        finalsoln.xval = 0;
        finalsoln.primalbnd = 0;
        finalsoln.relaxbnd = 0; 
        finalsoln.fathom = 0;
        return (finalsoln); }
    }

    // Deallocate space
    MYFREE (rmatbeg);
    MYFREE (rmatind);
    MYFREE (rmatval);
    MYFREE (sense);

  }

  // Setup skipcols
  if(SKIPCOLS) {
    skipcols = (char*)calloc(1+N, sizeof(char));
    for(i = 0; i < 1+N; i++) skipcols[i] = 0;
    if(KKTLVL == 0 || KKTLVL == 1) {
      for(j = 0; j < numfixedindices; j++)
        if(fixedtypes[j] == 22)
          skipcols[fixedindices[j]] = 1;
    }
    else if(KKTLVL == 2) {
      for(j = 0; j < numfixedindices; j++) {
             if(fixedtypes[j] == 11 || fixedtypes[j] == 22) skipcols[fixedindices[j]    ] = 1;
        else if(fixedtypes[j] == 21)                        skipcols[fixedindices[j]+n+m] = 1;

		  //        Check for (if x = 1 then z = 0) and (if x = 0 then y = 0)
		  //        Disable this by setting YZX_BRANCH to 0 in options.h 
		  // 		 
		  if (YZX_BRANCH)
		  {
			  if ((fixedtypes[j] == 12) && (fixedindices[j] >= n+1 + m - n))
			  {
				  skipcols[(fixedindices[j] - (n+1) - (m - n)) + (n + 1) + m] = 1;
			  }
			  if (fixedtypes[j] == 22)
			  {
				  skipcols[(fixedindices[j] - 1) + (n+1) + (m - n)] = 1;
			  }
		  }// end YZX_BRANCH 
		}
	 }
    Y = pvar;
    for(i = 0; i < 1+N; i++) if(skipcols[i])
      cblas_dscal(1+N, 0.0, Y + (1+N)*i, 1);
  }
  else skipcols = NULL;

  //                                                                                                                                                            
  // RUN ALGORITHM
  // RUN ALGORITHM
  // RUN ALGORITHM
  // RUN ALGORITHM
  //                                                                                                                                                            

  finalsoln = run_subgrad (env, lp, qp, pvar, dvar, ddir, PRINTSTYLE, skipcols);

//Uncomment this code to print solution
//  printf("relaxbnd = %.4f, primalbnd = %.4f\n", finalsoln.relaxbnd, finalsoln.primalbnd);
//  for(i = 0; i < n; i++)
//        printf("%.4f\n", finalsoln.xval[i]);
//  int newindex, newtype;
//  comp_branch(&newindex, &newtype, finalsoln.xval);
//  printf("newindex = %d\n, newtype = %d\n", newindex, newtype);

  //                                                                                                                                                            
  // DONE                                                                                                                                                       
  // DONE                                                                                                                                                       
  //  
  
  // Finish skipcols
  if(skipcols) MYFREE(skipcols);

  return (finalsoln);
}

