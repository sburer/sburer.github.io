#include "all.h"

// Computes objective for y^i lp subproblem (including i=0)
int set_yi_lp_obj(CPXENVptr env, CPXLPptr lp, double *dvar, int i)
{
  int j, status, localdim;

  if(KKTLVL == 1 && i == 0) localdim = N+1 + m+n;
  else                      localdim = N+1;

  // Zero out tempc (b/c routines below add to tempc)
  cblas_dscal(localdim, 0.0, tempc, 1);

  // Apply transpose of linear equations to dual variable
                             symmetryT(dvar, i, tempc);
  if(UBE)                      YZoperT(dvar, i, tempc);
  if(PSD)                      YUoperT(dvar, i, tempc);
  if(OBJOPER && KKTLVL > 0)   objoperT(dvar, i, tempc);
  if(KKTLVL == 2)           ycompoperT(dvar, i, tempc);

  // Take negative (as prescribed by formulas)
  cblas_dscal(localdim,-1.0,tempc,1); 

  // Adjust for objective function
  if(KKTLVL == 0 || special == 0) {
    if     (i ==  0) for(j = 1; j <= n; j++) tempc[j] += qpc[j-1];
    else if(i < n+1) for(j = 1; j <= n; j++) tempc[j] += 0.5*qpQ[(j-1)*n + i-1];
  }
  else if(special == 3) { // max e'y
    if(i == 0) for(j = 0; j < m; j++) tempc[n+1 + j] += 1.0;
  }
  else if(special == 4) { // max e'z
    if(i == 0) for(j = 0; j < n; j++) tempc[n+1 + m + j] += 1.0;
  }

  // Finally, change CPLEX objective 
  status = CPXchgobj(env, lp, localdim, temp_indices, tempc);

  return(status);
}

// Computes objective for z^i lp subproblem
int set_zi_lp_obj(CPXENVptr env, CPXLPptr lp, double *dvar, int i)
{
  int status;

  // Zero out tempc (b/c routines below add to tempc)
  cblas_dscal(N+1, 0.0, tempc, 1);

  // Apply transpose of linear equations to dual variable
  YZoperT(dvar, i, tempc);

  // Take negative (as prescribed by formulas)
  cblas_dscal(N+1, -1.0, tempc, 1); 

  // Finally, change CPLEX objective 
  status = CPXchgobj(env, lp, N+1, temp_indices, tempc);

  return(status);
}

// Solves LP subproblem and saves optimal value
int solve_lp_subprob(CPXENVptr env, CPXLPptr lp, double *objval)
{
  int status, lpstat;

  // Solve LP
  status = CPXprimopt(env, lp);
  if (status) { fprintf(stderr, "Problem solving a subproblem\n"); return(status); }
 
  // Check status of LP 
  lpstat = CPXgetstat(env,lp);
  if (lpstat == CPX_STAT_INFEASIBLE) { printf("Subproblem infeasible\n"); return(1977); }

  // Get optimal value of LP 
  if(lpstat != CPX_STAT_UNBOUNDED && lpstat != CPX_STAT_INForUNBD) {
    status = CPXgetobjval (env, lp, objval);
    if (status) { fprintf(stderr, "Problem getting obj val of subproblem\n"); return(status); }
  }
  else *objval = 1.0e10;

  return(0);
}


int compute_upper_bnd(CPXENVptr env, CPXLPptr *lp, double *curval, double *dvar, char *skipcols)
{
  int i, status;
  double tempval;
  int    index;
  double zero = 0.0, origub;
  char   u = 'U';

  // Initialize upper bound
  *curval = 0.0;

  // Determine objective of 0-th LP
  status = set_yi_lp_obj(env, lp[0], dvar, 0);
  if (status) { fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status); }

  // Solve 0-th LP
  status = solve_lp_subprob(env, lp[0], &tempval);
  if (status) { fprintf(stderr, "Problem solving y^0 LP obj\n"); return(status); }

  // Update upper bound
  *curval += tempval;

  for(i = 1; i < N+1; i++)
    {

      if(skipcols == NULL || skipcols[i] == 0) {

        // Determine objective of i-th LP for Y
        status = set_yi_lp_obj(env, lp[1], dvar, i);
        if (status) { fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status); }

        // If KKTLVL = 2 and i is appropriate, change upper bound on certain variable to 0
        if(KKTLVL == 2 && (i <= n || i >= n + m + 1)) {
          if(i <= n) index = n + m + i;
          else       index = i - (n + m);
          status = CPXgetub(env, lp[1], &origub, index, index);
          if (status) { fprintf(stderr, "Problem getting original bound related to complementarity.\n"); return(status); }
          status = CPXchgbds(env, lp[1], 1, &index, &u, &zero);
          if (status) { fprintf(stderr, "Problem changing bounds related to complementarity.\n"); return(status); }
        }

        // Solve i-th LP for Y (note use of lp[1] no matter i)
        status = solve_lp_subprob(env, lp[1], &tempval);
        if (status) { fprintf(stderr, "Problem solving y^i LP obj\n"); return(status); }

        // If KKTLVL = 2 and i is appropriate, reset upper bound on certain variable to original value 
        if(KKTLVL == 2 && (i <= n || i >= n + m + 1)) {
          if(i <= n) index = n + m + i;
          else       index = i - (n + m);
          status = CPXchgbds(env, lp[1], 1, &index, &u, &origub);
          if (status) { fprintf(stderr, "Problem changing bounds related to complementarity.\n"); return(status); }
        }

        // Update upper bound
        *curval += tempval;

      } 

      if(UBE)
        {
          // Determine objective of i-th LP for Z
          status = set_zi_lp_obj(env, lp[2], dvar, i);
          if (status) { fprintf(stderr, "Problem setting y^0 LP obj\n"); return(status); }

          // Solve i-th LP for Y (note use of lp[2] no matter i)
          status = solve_lp_subprob(env, lp[2], &tempval);
          if (status) { fprintf(stderr, "Problem solving y^0 LP obj\n"); return(status); }

          // Update upper bound
          *curval += tempval;
        }

    }

  return(0);
}
