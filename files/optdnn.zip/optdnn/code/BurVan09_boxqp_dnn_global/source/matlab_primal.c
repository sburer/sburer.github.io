#include "all.h"

int matlab_start(Engine **ep_result, mxArray **mxQ_result, mxArray **mxc_result, mxArray **mxA_result, mxArray **mxb_result, mxArray **mxn_result)
{
  int i, j;
  mxArray *mxQ = NULL;
  mxArray *mxc = NULL;
  mxArray *mxA = NULL;
  mxArray *mxb = NULL;
  mxArray *mxn = NULL;
  double *ptrQ = NULL;
  double *ptrc = NULL;
  double *ptrA = NULL;
  double *ptrb = NULL;
  Engine *ep;
#ifdef ISINFINITY
  int retstatus;
#endif
  char matengcmd[1000];

  mxQ = mxCreateDoubleMatrix(n,n,mxREAL);
  ptrQ = mxGetPr(mxQ);
  cblas_dcopy(n*n, qpQ, 1, ptrQ, 1);

  mxc = mxCreateDoubleMatrix(n,1,mxREAL);
  ptrc = mxGetPr(mxc);
  cblas_dcopy(n, qpc, 1, ptrc, 1);

  mxA = mxCreateDoubleMatrix(m-n,n,mxREAL);
  ptrA = mxGetPr(mxA);
  for(i = 0; i < m-n; i++)
    for(j = 0; j < n; j++)
      ptrA[j*(m-n) + i] = qpA[j*m + i];

  mxb = mxCreateDoubleMatrix(m-n,1,mxREAL);
  ptrb = mxGetPr(mxb);
  cblas_dcopy(m-n, qpb, 1, ptrb, 1);
  
  mxn = mxCreateDoubleScalar((double)n);

#ifdef ISINFINITY
  ep = engOpenSingleUse(NULL,NULL,&retstatus);
  if(ep == NULL) {
    fprintf(stderr, "\nCan't start MATLAB engine.\n");
    exit(1);
  }
  // else engSetVisible(ep, 0);
#else
  sprintf(matengcmd, "%s", MATENGCMD);
  if (!(ep = engOpen(matengcmd))) {
    fprintf(stderr, "\nCan't start MATLAB engine  MATENGCMD = %s\n", MATENGCMD);
    exit(1);
  }
#endif

  engPutVariable(ep,"Q",mxQ);
  engPutVariable(ep,"c",mxc);
  engPutVariable(ep,"A",mxA);
  engPutVariable(ep,"b",mxb);
  engPutVariable(ep,"n",mxn);

  *ep_result = ep;
  *mxQ_result = mxQ;
  *mxc_result = mxc;
  *mxA_result = mxA;
  *mxb_result = mxb;
  *mxn_result = mxn;

  return 0;
}

double matlab_primal(double *xprimal, Engine *ep)
{
  int i;
  mxArray *mxxprimal = NULL;
  mxArray *result = NULL;
  double *ptrxprimal = NULL;
  double objval;
  char matlabstr[] = "if exist('xprimal'); [x,fct]=quadprog(-Q,-c,A,b,[],[],zeros(n,1),ones(n,1),xprimal); else; fct = 1.0e10; rand('state',0); for i = 1:10; [x,tempfct]=quadprog(-Q,-c,A,b,[],[],zeros(n,1),ones(n,1),rand(n,1)); if tempfct < fct; fct = tempfct; end; end; end;";
  // Does random initialization make sense in general case? Will keep as is for now?
//   char buffer[1000];

  if(xprimal != NULL) {
    mxxprimal = mxCreateDoubleMatrix(n,1,mxREAL);
    ptrxprimal = mxGetPr(mxxprimal);
    for(i = 0; i < n; i++) ptrxprimal[i] = xprimal[i];
    engPutVariable(ep,"xprimal",mxxprimal);
  }

//   engOutputBuffer(ep,buffer,1000);
//   engEvalString(ep, "save blah");
  engEvalString(ep, matlabstr);
//   printf("%s\n", buffer);

  result = engGetVariable(ep,"fct");
  if (result == NULL) { 
    printf("Oops! You didn't create a variable fct.\n\n");
   exit(1);
  }
  else objval = -1*mxGetScalar(result);

  if(xprimal != NULL) mxDestroyArray(mxxprimal);

  return(objval);
}
