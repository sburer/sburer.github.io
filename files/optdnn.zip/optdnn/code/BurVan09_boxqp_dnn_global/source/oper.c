#include "all.h"

double   objoper_norm = 1.0;
double ycompoper_norm = 1.0;

int symmetry(double *pvar, double *result)
{
  int i, j;
  double *Y;

  // assumes result has size LDIM, ordered in correct way

  Y = pvar;

  for(i = 0; i < N+1; i++)
    for(j = i + 1; j < N+1; j++)
      result[supdiag_index(i,j)] = Y[j*(N+1)+i] - Y[i*(N+1)+j];

  return 0;
}

int symmetry_single(double *pvar, int col, double *result, int option)
{
  int j;
  double *Y;

  // assumes result has size LDIM, ordered in correct way

  Y = pvar;

  // same except for increment
  if(option == 1) {
    for(j = 0; j < col; j++)
      result[supdiag_index(j,col)] +=  Y[col*(N+1)+j];
    for(j = col + 1; j < N+1; j++)
      result[supdiag_index(col,j)] += -Y[col*(N+1)+j];
  }
  else if(option == -1) {
    for(j = 0; j < col; j++)
      result[supdiag_index(j,col)] -=  Y[col*(N+1)+j];
    for(j = col + 1; j < N+1; j++)
      result[supdiag_index(col,j)] -= -Y[col*(N+1)+j];
  }

  return 0;
}

int symmetry_single_quadpart(int col, double *qpsep)
{
  int j;

  for(j = 0;       j < col; j++) qpsep[j] += 1.0;
  for(j = col + 1; j < N+1; j++) qpsep[j] += 1.0;

  return 0;
}

int symmetryT(double *dvar, int col, double *result)
{
  int j;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  // assumes result has size N+1
  // adds to contents of result

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
  S = z_lambda = obj_lambda = ycomp_lambda = NULL; // actually do not use these

  for(j = 0; j < col; j++)      result[j] +=  sym_lambda[supdiag_index(j,col)];
  for(j = col+1; j < N+1; j++)  result[j] += -sym_lambda[supdiag_index(col,j)];

  return 0;
}

int YZoper(double *pvar, double *result)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  // assumes result has size ZDIM, ordered in correct way

  if(!UBE) { printf("YZoper: UBE = 0\n"); exit(0); }

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = y = z = NULL; // actually do not use these

  for(i = 1; i < N+1; i++) 
    for(j = 0; j < N+1; j++)
      result[i*(N+1)+j] = Y[j] - Y[i*(N+1)+j] - Z[i*(N+1)+j];

  return 0;
}

int YZoper_single(double *pvar, char var, int col, double *result, int option)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  // assumes result has size ZDIM, ordered in correct way

  if(!UBE) { printf("YZoper: UBE = 0\n"); exit(0); }

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = y = z = NULL; // actually do not use these

  // same except increment
  if(option == 1) {

    if(var == 'Y') {
      if(col == 0) {
        for(i = 1; i < N+1; i++) 
          for(j = 0; j < N+1; j++)
            result[i*(N+1)+j] += Y[j];
      }
      else {
        for(j = 0; j < N+1; j++)
          result[col*(N+1)+j] += -Y[col*(N+1)+j];
      }
    }
    else if(var == 'Z') {
      for(j = 0; j < N+1; j++)
        result[col*(N+1)+j] += -Z[col*(N+1)+j];
    }
    else {
      printf("YZoper_single: Wrong variable specification.\n");
      exit(0);
    }

  }
  else if(option == -1) {

    if(var == 'Y') {
      if(col == 0) {
        for(i = 1; i < N+1; i++) 
          for(j = 0; j < N+1; j++)
            result[i*(N+1)+j] -= Y[j];
      }
      else {
        for(j = 0; j < N+1; j++)
          result[col*(N+1)+j] -= -Y[col*(N+1)+j];
      }
    }
    else if(var == 'Z') {
      for(j = 0; j < N+1; j++)
        result[col*(N+1)+j] -= -Z[col*(N+1)+j];
    }
    else {
      printf("YZoper_single: Wrong variable specification.\n");
      exit(0);
    }

  }

  return 0;
}

int YZoper_single_quadpart(int col, double *qpsep)
{
  int j;
  double tv;

  if(col == 0) tv = (double)N;
  else         tv = 1.0;

  for(j = 0; j < N+1; j++) qpsep[j] += tv;

  return 0;
}

int YZoperT(double *dvar, int col, double *result)
{
  int i, j;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  // assumes result has size n+1
  // adds to contents of result

  if(!UBE) { printf("YZoperT: UBE = 0\n"); exit(0); }

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
  S = obj_lambda = ycomp_lambda = NULL; // actually do not use S

  if(col > 0)
    for(j = 0; j < N+1; j++)
      result[j] += -z_lambda[col*(N+1) + j];
  else {
    for(i = 1; i < N+1; i++)
      for(j = 0; j < N+1; j++)
        result[j] += z_lambda[i*(N+1) + j];
  }

  return 0;
}

int YUoper(double *pvar, double *result)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  // assumes result has size UDIM, ordered in correct way

  if(!PSD) { printf("YUoper: PSD = 0\n"); exit(0); }

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  Z = y = z = NULL; // actually do not use these

  for(i = 0; i < N+1; i++)
    for(j = i; j < N+1; j++)
      result[updiag_index(i,j)] = U[updiag_index(i,j)] - 0.5*(Y[i*(N+1)+j] + Y[j*(N+1)+i]);

  return 0;
}

int YUoper_single(double *pvar, char var, int col, double *result, int option)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  // assumes result has size UDIM, ordered in correct way

  if(!PSD) { printf("YUoper: PSD = 0\n"); exit(0); }

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  Z = y = z = NULL; // actually do not use these

  // same except for increment
  if(option == 1) {

    if(var == 'Y') {
      for(j = 0; j < col; j++)
        result[updiag_index(j,col)] += -0.5*Y[col*(N+1)+j];
      for(j = col+1; j < N+1; j++)
        result[updiag_index(col,j)] += -0.5*Y[col*(N+1)+j];
      result[updiag_index(col,col)] += -Y[col*(N+1)+col];
    }
    else if(var == 'U') {
      for(i = 0; i < N+1; i++)
        for(j = i; j < N+1; j++)
          result[updiag_index(i,j)] += U[updiag_index(i,j)];
    }
    else {
      printf("YUoper_single: Wrong variable specification.\n");
      exit(0);
    }

  }
  else if(option == -1) {

    if(var == 'Y') {
      for(j = 0; j < col; j++)
        result[updiag_index(j,col)] -= -0.5*Y[col*(N+1)+j];
      for(j = col+1; j < N+1; j++)
        result[updiag_index(col,j)] -= -0.5*Y[col*(N+1)+j];
      result[updiag_index(col,col)] -= -Y[col*(N+1)+col];
    }
    else if(var == 'U') {
      for(i = 0; i < N+1; i++)
        for(j = i; j < N+1; j++)
          result[updiag_index(i,j)] -= U[updiag_index(i,j)];
    }
    else {
      printf("YUoper_single: Wrong variable specification.\n");
      exit(0);
    }

  }

  return 0;
}

int YUoper_single_quadpart(int col, double *qpsep)
{
  int j;

  // this subroutine is only wrt Y, not U 

  for(j = 0;       j < col; j++) qpsep[j] += 0.5;
  for(j = col + 1; j < N+1; j++) qpsep[j] += 0.5;
  qpsep[col] += 1.0;

  return 0;
}

int YUoperT(double *dvar, int col, double *result)
{
  int j;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  // assumes result has size n+1
  // adds to contents of result

  if(!PSD) { printf("YUoperT: PSD = 0\n"); exit(0); }

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
  sym_lambda = z_lambda = obj_lambda = ycomp_lambda = NULL; // actually do not use these

  for(j = 0; j < N+1; j++)
    if(col <= j) result[j] += -S[updiag_index(col,j)];
    else         result[j] += -S[updiag_index(j,col)];

  return 0;
}

void get_objoper_norm()
{
  int i;
  double sum = 0.0;

  for(i = 0; i < n*n; i++)
    sum += qpQ[i]*qpQ[i];

  for(i = 0; i < n; i++)
    sum += qpc[i]*qpc[i];

  for(i = 0; i < m; i++)
    sum += origyBAR*qpb[i]*origyBAR*qpb[i];

  objoper_norm = sqrt(sum);

}

int objoper(double *pvar, double *result)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;

  // assumes result is just a scalar 

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = Z = NULL; // actually don't use these

  result[0] = 0.0;

  // Q*X
  for(i = 1; i < n+1; i++)
    for(j = 1; j < n+1; j++)
      result[0] += Y[j*(N+1)+i]*qpQ[(j-1)*n + (i-1)];

  // + c'x
  result[0] += cblas_ddot(n, qpc, 1, Y+1, 1);

  // - b'y
  if     (KKTLVL == 1) result[0] -= origyBAR*cblas_ddot(m, qpb, 1, y,     1);
  else if(KKTLVL == 2) result[0] -= origyBAR*cblas_ddot(m, qpb, 1, Y+n+1, 1);

  result[0] /= objoper_norm;

  return 0;
}

int objoper_single(double *pvar, int col, double *result, int option)
{
  int i;
  double *Y, *U, *Z, *y, *z;

  // assumes result is just a scalar 

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = Z = NULL; // actually don't use these

  // same except for increment
  if(option == 1) {

    if(col == 0) {
      result[0] += cblas_ddot(n, qpc, 1, Y+1, 1)/objoper_norm;
      if     (KKTLVL == 1) result[0] -= origyBAR*cblas_ddot(m, qpb, 1, y,     1)/objoper_norm;
      else if(KKTLVL == 2) result[0] -= origyBAR*cblas_ddot(m, qpb, 1, Y+n+1, 1)/objoper_norm;
    }
    else if(col < n+1) {
      for(i = 1; i < n+1; i++)
        result[0] += Y[col*(N+1)+i]*qpQ[(col-1)*n + (i-1)]/objoper_norm;
    }

  }
  else if(option == -1) {

    if(col == 0) {
      result[0] -= cblas_ddot(n, qpc, 1, Y+1, 1)/objoper_norm;
      if     (KKTLVL == 1) result[0] += origyBAR*cblas_ddot(m, qpb, 1, y,     1)/objoper_norm;
      else if(KKTLVL == 2) result[0] += origyBAR*cblas_ddot(m, qpb, 1, Y+n+1, 1)/objoper_norm;
    }
    else if(col < n+1) {
      for(i = 1; i < n+1; i++)
        result[0] -= Y[col*(N+1)+i]*qpQ[(col-1)*n + i-1]/objoper_norm;
    }

  }
  else { printf("objoper_single: Wrong variable specification.\n"); exit(0); }

  return 0;
}

int objoper_single_quadpart(int col, int *result_length, int *result_i, int *result_j, double *result_val)
{
  int h, i, j;
  int tmpdim=0, *tmpind;
  double *tmpval;

  // handling col=0 assumes qpc and qpb are 100% dense, whereas
  // handling col>0 checks for nonzeros in qpQ
  // (or assumes 100% dense for qpEval)

  if(col == 0) *result_length = (m+n+1)*(m+n)/2;
  else if(col < n+1) {
    tmpdim = 0;
    for(j = 1; j <= n; j++) if(fabs(qpQ[(col-1)*n + j-1]) > 1.0e-15) tmpdim++;
    *result_length = (tmpdim + 1)*tmpdim/2;
  }
  else {
    *result_length = 0;
  }

  if(col == 0) {

    h = 0;
    
    for(i = 0; i < n; i++) for(j = i; j < n; j++) {
      result_i[h] = 1 + i;
      result_j[h] = 1 + j;
      result_val[h++] = qpc[i]*qpc[j]/(objoper_norm*objoper_norm);
    }

    for(i = 0; i < m; i++) for(j = i; j < m; j++) {
      result_i[h] = n+1 + i;
      result_j[h] = n+1 + j;
      result_val[h++] = origyBAR*qpb[i]*origyBAR*qpb[j]/(objoper_norm*objoper_norm);
    }

    for(i = 0; i < n; i++) for(j = 0; j < m; j++) {
      result_i[h] = 1   + i;
      result_j[h] = n+1 + j;
      result_val[h++] = -qpc[i]*origyBAR*qpb[j]/(objoper_norm*objoper_norm);
    }

    if(h != *result_length) { printf("Problem in code!\n"); exit(0); }

  }
  else if(col < n+1) {
  
    tmpind = (int*)   calloc(tmpdim, sizeof(int)   );
    tmpval = (double*)calloc(tmpdim, sizeof(double));

    h = 0;
    for(j = 1; j <= n; j++)
      if(fabs(qpQ[(col-1)*n + j-1]) > 1.0e-15) {
        tmpind[h] = j;
        tmpval[h++] = qpQ[(col-1)*n + j-1];
      }

    h = 0;

    for(i = 0; i < tmpdim; i++) for(j = i; j < tmpdim; j++) {
      result_i[h] = tmpind[i];
      result_j[h] = tmpind[j];
      result_val[h++] = tmpval[i]*tmpval[j]/(objoper_norm*objoper_norm);
    }

    if(h != *result_length) { printf("Problem in code!\n"); exit(0); }

    MYFREE(tmpind);
    MYFREE(tmpval);

  }

  return 0;
}

int objoperT(double *dvar, int col, double *result)
{
  int j;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  // assumes result has size n+1+m+n if col=0
  // assumes result has size n+1     if col>0
  // adds to contents of result

  if(KKTLVL == 0) { printf("objoperT: KKTLVL == 0\n"); exit(0); }

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
  sym_lambda = S = z_lambda = ycomp_lambda = NULL; // actually do not use these

  if(col == 0) {
    for(j = 0; j < n; j++) result[1 + j]   += obj_lambda[0]*qpc[j]/objoper_norm;
    for(j = 0; j < m; j++) result[n+1 + j] -= obj_lambda[0]*origyBAR*qpb[j]/objoper_norm;
  }
  else if(col < n+1) {
    for(j = 0; j < n; j++) result[1 + j] += obj_lambda[0]*qpQ[(col-1)*n + j]/objoper_norm;
  }

  return 0;
}

void get_ycompoper_norm()
{
  int i, j;
  double sum = 0.0;

  for(i = 0; i < m; i++)
    sum += qpb[i]*qpb[i];

  for(i = 0; i < m; i++)
    for(j = 0; j < n; j++)
      sum += qpA[j*m + i]*qpA[j*m + i];

  ycompoper_norm = sqrt(sum);

}

int ycompoper(double *pvar, double *result)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;
  double *w;

  // Assumes result has length m
 
  // This subroutine assumes KKTLVL = 2
  if(KKTLVL != 2) { printf("ycompoper: KKTLVL != 2\n"); exit(0); }

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = Z = y = z = NULL; // actually don't use these

  y = Y + (1+n);

  for(i = 0; i < m; i++) {

    w = Y + (1+n + i)*(N+1) + 1;

    result[i] = -qpb[i]*y[i];
    for(j = 0; j < n; j++)
      result[i] += qpA[j*m + i]*w[j];

    result[i] /= ycompoper_norm;

  }

  return 0;
}

int ycompoper_single(double *pvar, int col, double *result, int option)
{
  int i, j;
  double *Y, *U, *Z, *y, *z;
  double *w;

  // Assumes result has length m
 
  // This subroutine assumes KKTLVL = 2
  if(KKTLVL != 2) { printf("ycompoper: KKTLVL != 2\n"); exit(0); }

  if( ! (col == 0 || (col > n && col < n+m+1)) ) return 0;

  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);
  U = Z = y = z = NULL; // actually don't use these

  if(option == 1) {
    if(col == 0) {
      y = Y + (1+n);
      for(i = 0; i < m; i++) result[i] -= qpb[i]*y[i]/ycompoper_norm;
    }
    else {
      i = col - (1+n);
      w = Y + (1+n + i)*(N+1) + 1;
      for(j = 0; j < n; j++) result[i] += qpA[j*m + i]*w[j]/ycompoper_norm;
    }
  }
  else if(option == -1) {
    if(col == 0) {
      y = Y + (1+n);
      for(i = 0; i < m; i++) result[i] += qpb[i]*y[i]/ycompoper_norm;
    }
    else {
      i = col - (1+n);
      w = Y + (1+n + i)*(N+1) + 1;
      for(j = 0; j < n; j++) result[i] -= qpA[j*m + i]*w[j]/ycompoper_norm;
    }
  }

  return 0;
}

int ycompoper_single_quadpart(int col, int *result_length, int *result_i, int *result_j, double *result_val)
{
  int h, i, j, k;
  int tmpdim=0, *tmpind;
  double *tmpval;

  // This subroutine assumes KKTLVL = 2
  if(KKTLVL != 2) { printf("ycompoper: KKTLVL != 2\n"); exit(0); }

  // If col does not apply, leave subroutine quickly
  if( ! (col == 0 || (col > n && col < n+m+1)) ) {
    *result_length = 0;
    return 0;
  }

  // handling col=0 assumes qpb is 100% dense, whereas
  // handling col>0 checks for nonzeros in qpA
  // (or assumes 100% dense for qpEval)

  if(col == 0) *result_length = m;
  else {
    k = col - (1+n);
    tmpdim = 0;
    for(j = 0; j < n; j++) if(fabs(qpA[j*m + k]) > 1.0e-15) tmpdim++;
    *result_length = (tmpdim + 1)*tmpdim/2;
  }

  if(col == 0) {

    h = 0;
    
    for(i = 0; i < m; i++) {
      result_i[h] = result_j[h] = n+1 + i;
      result_val[h++] = qpb[i]*qpb[i]/(ycompoper_norm*ycompoper_norm);
    }

    if(h != *result_length) { printf("Problem in code!\n"); exit(0); }

  }
  else {
  
    k = col - (1+n);

    tmpind = (int*)   calloc(tmpdim, sizeof(int)   );
    tmpval = (double*)calloc(tmpdim, sizeof(double));

    h = 0;
    for(j = 0; j < n; j++)
      if(fabs(qpA[j*m + k]) > 1.0e-15) {
        tmpind[h] = 1 + j; // 1 b/c nonzero is in xy' block, not in 0-th coordinate
        tmpval[h++] = qpA[j*m + k];
      }

    h = 0;

    for(i = 0; i < tmpdim; i++) for(j = i; j < tmpdim; j++) {
      result_i[h] = tmpind[i];
      result_j[h] = tmpind[j];
      result_val[h++] = tmpval[i]*tmpval[j]/(ycompoper_norm*ycompoper_norm);
    }

    if(h != *result_length) { printf("Problem in code!\n"); exit(0); }

    MYFREE(tmpind);
    MYFREE(tmpval);

  }

  return 0;
}

int ycompoperT(double *dvar, int col, double *result)
{
  int i, j;
  double *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  // This subroutine assumes KKTLVL = 2
  if(KKTLVL != 2) { printf("ycompoperT: KKTLVL != 2\n"); exit(0); }

  // If col does not apply, leave subroutine quickly
  if( ! (col == 0 || (col > n && col < n+m+1)) ) return 0;

  // assumes result has size N+1 = n+1+m+n
  // adds to contents of result

  assign_pdvars(NULL,dvar,NULL,NULL,NULL,NULL,NULL,NULL,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,0,1,0);
  sym_lambda = S = z_lambda = NULL; // actually do not use these

  if(col == 0) {
    for(j = 0; j < m; j++) result[1+n + j] -= ycomp_lambda[j]*qpb[j]/ycompoper_norm;
  }
  else {
    i = col - (n+1);
    for(j = 0; j < n; j++) result[1 + j] += ycomp_lambda[i]*qpA[j*m + i]/ycompoper_norm;
  }

  return 0;
}
