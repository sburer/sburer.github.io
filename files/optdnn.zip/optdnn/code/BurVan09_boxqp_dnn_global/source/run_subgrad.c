#include "all.h"

int myprint(int iter, double curval, double bestval, double bestprimalbd, double curr_infeas, double sigma, double t)
{
  printf ("%5d  % .15e  % .15e  % .15e  %.1e  %.1e  %d\n", iter, curval, bestval, bestprimalbd, curr_infeas, sigma, (int) t);
  fflush(stdout);
  return 0;
}

double compute_primalbnd (double *pvar)
{
  int    i, j;
  double tempval=0.0;
  double *x, *Y, *U, *Z, *y, *z;
 
  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);

  if (special == 0)
  {
	  // 0-th col/row of Y is always feasible for box QP (slight infeasibilities?).
	  // So this function evaluates 0.5*x'Qx + c'x to get a bound.

          x = Y+1;
          
	  for (i = 0; i < n; i++)
		  for (j = 0; j < n; j++)
			  tempval += 0.5 * qpQ[j*n + i] * x[i] * x[j];

	  for (i = 0; i < n; i++)
		  tempval += qpc[i] * x[i];

   }
   else if (special == 3)
   {
	  for(i = 0; i < m; i++) tempval += y[i];
   }
   else if (special == 4)
   {
	  for(i = 0; i < n; i++) tempval += z[i];
   }

   return (tempval);
}

SOLNINFO run_subgrad (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp, double *pvar, double *dvar, double *ddir, int printstyle, char *skipcols)
{
  int     i, iter, status;        // basic variables
  int     last_change = 0;        // last iter at which bestval improved
  int     num_psd_cycles;
  int     num_qp_cycles;
  int     sigma_freq;
  int     sigma_reset_flag;
  int     basis_array_uninit;
  double  sigma;                  // penalty parameter 
  double  curval;                 // current dual value (upper bound, what we minimize) during algorithm
  double  bestval = 1.0e10;       // best dual value during algorithm 
  double  primalbd;               // current primal value (lower bound)
  double  bestprimalbd = -1.0e10; // best primal value (lower bound)
  double  sigma_power = 1.0;      // exponent of the factor by which sigma is increased
  double  curr_infeas;
  double  savedratios[5];
  int     savedctr = -1; 
  int     numdigits = 0;
  double  *Y, *U, *Z, *y, *z;
  extern double ZLB;
  extern int newzlb;

  // Timing declarations (platform dependent)

#ifdef ISLINUX
  int                 clocks_per_second = 0;
  clocks_per_second = sysconf (_SC_CLK_TCK);
  double              t0, t;
  struct tms          timearr;
  clock_t             tres;
#endif

#ifdef ISWINDOZE
  clock_t             t0, t1;
  double              t;
#endif

  // Variable that will contain solution info to be returned (also set fathom to 0)
  SOLNINFO finalsoln;
  finalsoln.fathom = 0;

  // Initialize some vectors used in compute.c
  alloc_computearrays (env, qp);

  // Set some parameters
  status             = 0;
  sigma              = 0.1;
  sigma_reset_flag   = 1;
  num_psd_cycles     = BEGIN_NUM_CYCLES;
  num_qp_cycles      = 1;
  sigma_freq         = SIGMA_FREQ;
  basis_array_uninit = 1;


  // Do initial timings
#ifdef ISLINUX
  tres = times (&timearr);
  t0 = timearr.tms_utime;
#endif
#ifdef ISWINDOZE
  t0 = clock ();
#endif

  for (i = 0; i < 5; i++) savedratios[i] = -5.0;

  // BEGIN:
  // BEGIN: Augmented Lagrangian iterations
  // BEGIN:
  
  // Compute dir for first time
  // Needed for new changes, needs some thought
  curr_infeas = compute_dir (pvar, ddir);

  for (iter = 1; iter <= ITERLIM; iter++) {

    // Solve current subproblem
    status = solve_auglagr (env, qp, &curval, sigma, pvar, dvar, ddir, num_psd_cycles, num_qp_cycles, &sigma_reset_flag, &basis_array_uninit, skipcols);

    // If error detected, then quit abruptly ( ? 1977 refers to infeasible QP or LP ? )
    if ((status != 0) && (status != 1977)) {
      fprintf (stderr, "run_subgrad: Problem solving in solve_auglagr()\n");
      goto END_RUN_AUGLAG;
    }
    if (status == 1977) { finalsoln.problemcode = 1977; goto END_RUN_AUGLAG; };

    // Get subgradient / direction (byproduct: primal infeasibility)
    curr_infeas = compute_dir (pvar, ddir);

    // If primal infeasibility is small enough, break
    if (curr_infeas < NORM_VIOL) break;

    // Move in direction / update duals
    update_duals (sigma, dvar, ddir);

    // Update sigma (quit if sigma too large)
    if ((iter > 0) && (SIGMA_FACTOR != 1.0) && (iter % sigma_freq == 0)) {
      sigma *= pow (SIGMA_FACTOR, sigma_power);
      sigma_reset_flag = 1;
      if (sigma > 1.0e+9) {
        if(printstyle == 1) printf ("Sigma too large!\n");
        goto FATHOM_RUN_AUGLAG;  // Send this to FATHOM_RUN_AUGLAG so that bounds and primal solns will be evaluated
      }
    }

    // (Only every so often)
    // Compute: (i) true upper bound by solving LP; (ii) lower bound
    // Also: (i) get timings; (ii) update bestval or change aggressiveness with penalty; (iii) print
    if (iter % UB_FREQ == 0) {

      // Quit early if special == 3 or 4
      // Upper bound will be calculated at FATHOM_RUN_AUGLAG
      if(special > 0) goto FATHOM_RUN_AUGLAG;

      // This needs more explanation (position is important!)
      savedctr++;
      savedratios[savedctr % 5] = bestval - bestprimalbd;

      // Get lower bound and save if best (local 'best' vs global 'best')
      primalbd = compute_primalbnd (pvar);
      if (primalbd > bestprimalbd) bestprimalbd = primalbd;
      if (primalbd > ZLB) { ZLB = primalbd; newzlb = 1; }

      // Get upper bound
      status = compute_upper_bnd (env, lp, &curval, dvar, skipcols);
      if (status) { fprintf (stderr, "Problem computing UB\n"); goto END_RUN_AUGLAG; }

      // Save bound info and try to fathom (if best) or be more aggressive with sigma (if not)
      // Are we really being more agressive with sigma? --Sam 12/23/2005
      if (curval < bestval) {
        bestval = curval;
        last_change = iter;
        if(special == 0 && myfathom(bestval)) { finalsoln.fathom = 1; goto FATHOM_RUN_AUGLAG; }
      }
      else {
        num_psd_cycles = mymin(num_psd_cycles+1, MAX_NUM_CYCLES);
        sigma_freq += SIGMA_FREQ;
//         printf("Updating sigma_freq to %d.\n", sigma_freq); fflush(stdout);
//         if (iter - last_change >= N) {
//           last_change = iter;
//           sigma_power += 1.0;
//         }
      }

      // This needs more explanation (position is important!)
      savedratios[savedctr % 5] = (bestval - bestprimalbd) / savedratios[savedctr % 5]; 
      if(0.2*(savedratios[0] + savedratios[1] + savedratios[2] + savedratios[3] + savedratios[4]) > my_earlyterm_tol) break;

      // Do timings
#ifdef ISLINUX
      tres = times (&timearr);
      t = (timearr.tms_utime - t0) / clocks_per_second;
#endif
#ifdef ISWINDOZE
      t1 = clock ();
      t = (double) (t1 - t0) / CLOCKS_PER_SEC;
#endif

      // Print (make sure to flush)
      if(printstyle == 1) myprint (iter, curval, bestval, bestprimalbd, curr_infeas, sigma, t);
      else {
        for(i = 0; i < numdigits; i++) printf("\b");
        printf("%.8f ", bestval);
        numdigits = (int)log10(fabs(bestval)) + 1 + 5 + 1;
        if(bestval < 0) numdigits++;
        fflush (stdout);
      }

    }

  }

  // END:
  // END: Augmented Lagrangian iterations
  // END:

FATHOM_RUN_AUGLAG:

  // Get final upper bound (save if best)
  status = compute_upper_bnd (env, lp, &curval, dvar, skipcols);
  if (status) { fprintf (stderr, "Problem computing UB\n"); goto END_RUN_AUGLAG; }
  if (curval < bestval) bestval = curval;

  // Try to fathom
  if(myfathom(bestval)) finalsoln.fathom = 1;

  // Get final lower bound (save if best)
  primalbd = compute_primalbnd (pvar);
  if (primalbd > bestprimalbd) bestprimalbd = primalbd;

  // Do final timings
#ifdef ISLINUX
  tres = times (&timearr);
  t = (timearr.tms_utime - t0) / clocks_per_second;
#endif
#ifdef ISWINDOZE
  t1 = clock ();
  t = (double) (t1 - t0) / CLOCKS_PER_SEC;
#endif

  // Print (make sure to flush)
  if (printstyle == 1) myprint (iter, curval, bestval, bestprimalbd, curr_infeas, sigma, t);
  else {
    for (i = 0; i < numdigits; i++) printf("\b");
    printf("%.4f", bestval);
    fflush (stdout);
  }

  // Assign local ptrs to pdvars
  assign_pdvars(pvar,NULL,NULL,&Y,&U,&Z,&y,&z,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0);

  // Prepare to return
  finalsoln.problemcode = status;
  finalsoln.relaxbnd    = bestval;
  finalsoln.primalbnd   = bestprimalbd;
  finalsoln.y = finalsoln.z = NULL;
  finalsoln.xval = (double *) calloc (n, sizeof (double));
  cblas_dcopy(n, Y + 1, 1, finalsoln.xval, 1);
  if(KKTLVL > 0) {
    finalsoln.y = (double*)calloc(m, sizeof(double));
    finalsoln.z = (double*)calloc(n, sizeof(double));
    if(KKTLVL == 1) {
      cblas_dcopy(m, y, 1, finalsoln.y, 1);
      cblas_dcopy(n, z, 1, finalsoln.z, 1);
    }
    else {
      cblas_dcopy(m, Y + 1+n,     1, finalsoln.y, 1);
      cblas_dcopy(n, Y + 1+n + m, 1, finalsoln.z, 1);
    }
  }

END_RUN_AUGLAG:

  // Deallocate things allocated in this routine
  dealloc_computearrays ();

  return (finalsoln);

}

