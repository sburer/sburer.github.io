#include "all.h"

int processdir(double *pvar, char var, int col, int option, double *ddir)
{
  double *sym_dir, *S_dir, *z_dir, *obj_dir, *ycomp_dir;

  assign_pdvars(NULL,NULL,ddir,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,&sym_dir,&S_dir,&z_dir,&obj_dir,&ycomp_dir,0,0,1);
    
  if(var == 'Y') {
                               symmetry_single(pvar,      col, sym_dir,   option);
    if(PSD)                      YUoper_single(pvar, 'Y', col, S_dir,     option);
    if(UBE)                      YZoper_single(pvar, 'Y', col, z_dir,     option);
    if(OBJOPER && KKTLVL > 0)   objoper_single(pvar,      col, obj_dir,   option); 
    if(KKTLVL == 2)           ycompoper_single(pvar,      col, ycomp_dir, option); 
  }
  else if(var == 'U') {
    YUoper_single(pvar, 'U', -1, S_dir, option);
  }
  else if(var == 'Z') {
    YZoper_single(pvar, 'Z', col, z_dir, option);
  }

  return 0;
}

int zerooutQ(CPXENVptr env, CPXLPptr qp)
{
  int j, k, status;
  int nzcnt, *qmatbeg, *qmatind, surplus;
  int numcols;
  double *qmatval;

  numcols = CPXgetnumcols(env,qp);

  status = CPXgetquad(env, qp, NULL, NULL, NULL, NULL, 0, &surplus, 0, numcols-1);
  if(status != 0 && status != 1207) { fprintf(stderr, "Problem zeroing out Q. (status = %d)\n", status); exit(0); } 

  nzcnt = -surplus;

  qmatbeg = (int*)calloc(numcols+1, sizeof(int));
  qmatind = (int*)calloc(nzcnt, sizeof(int));
  qmatval = (double*)calloc(nzcnt, sizeof(double));

  status = CPXgetquad(env, qp, &nzcnt, qmatbeg, qmatind, qmatval, nzcnt, &surplus, 0, numcols-1);
  if(status != 0) { fprintf(stderr, "Problem zeroing out Q. (status = %d)\n", status); exit(0); } 

  qmatbeg[numcols] = nzcnt;

  for(j = 0; j < numcols; j++)
    for(k = qmatbeg[j]; k < qmatbeg[j+1]; k++) {
      status = CPXchgqpcoef(env, qp, qmatind[k], j, 0.0);
      if(status) { fprintf(stderr, "Problem zeroing out Q. (status = %d)\n", status); exit(0); } 
    }

  MYFREE(qmatbeg);
  MYFREE(qmatind);
  MYFREE(qmatval);

  return 0;
}

int set_yi_qp_obj(CPXENVptr env, CPXLPptr qp, double sigma, double *pvar, double *dvar, double *ddir, int i, int sigma_reset_flag)
{
  int j, k, status;
  int quadpart_length = 0;
  int localdim;
  double tv;
  double qpsep[1+N];

  // BEGIN: linear part of QP objective
  // BEGIN: linear part of QP objective
  // BEGIN: linear part of QP objective

  if(KKTLVL == 1 && i == 0) localdim = N+1 + m+n;
  else                      localdim = N+1;

  // Create important vector (see formulas)
  for(k = 0; k < ddim; k++)
    solve_auglagr_tmp[k] = dvar[k] - sigma*ddir[k];

  // Zero out tempc, which will hold linear part of QP objective
  // Subsequent subroutines will add to tempc
  cblas_dscal(localdim, 0.0, tempc, 1);

  // Apply transpose of linear equations to dual variable (as prescribed by formulas)
                             symmetryT(solve_auglagr_tmp, i, tempc);
  if(PSD)                      YUoperT(solve_auglagr_tmp, i, tempc);
  if(UBE)                      YZoperT(solve_auglagr_tmp, i, tempc);
  if(OBJOPER && KKTLVL > 0)   objoperT(solve_auglagr_tmp, i, tempc);
  if(KKTLVL == 2)           ycompoperT(solve_auglagr_tmp, i, tempc);

  // Take negative (as prescribed by formulas)
  cblas_dscal(localdim, -1.0, tempc, 1); 

  // Adjust for (original, overall) objective function
  if(KKTLVL == 0 || special == 0) {
    if     (i ==  0) for(j = 1; j <= n; j++) tempc[j] += qpc[j-1];
    else if(i < n+1) for(j = 1; j <= n; j++) tempc[j] += 0.5*qpQ[(j-1)*n + i-1];
  }
  else if(special == 3) { // max e'y
    if(i == 0) for(j = 0; j < m; j++) tempc[n+1 + j] += 1.0;
  }
  else if(special == 4) { // max e'z
    if(i == 0) for(j = 0; j < n; j++) tempc[n+1 + m + j] += 1.0;
  }

  // Change CPLEX linear objective
  status = CPXchgobj(env, qp, localdim, temp_indices, tempc);
  if (status) { fprintf(stderr, "Problem changing coeff for qp y^i\n"); return(status); }


  // BEGIN: quadratic part of QP objective
  // BEGIN: quadratic part of QP objective
  // BEGIN: quadratic part of QP objective

  if(i > 0 || sigma_reset_flag) {

    // Zero out Q
    if(KKTLVL > 0) zerooutQ(env, qp);

    // For each operator, get quadratic contribution and add it to
    // CPLEX's Q Not particularly efficient b/c of limited CPLEX
    // functions, but we've done the best we can.

    // First do operators that only contribute to diagonal of Q
    cblas_dscal(1+N, 0.0, qpsep, 1);
            symmetry_single_quadpart(i, qpsep);
    if(PSD)   YUoper_single_quadpart(i, qpsep);
    if(UBE)   YZoper_single_quadpart(i, qpsep);
    cblas_dscal(1+N, -sigma, qpsep, 1);
    for(j = 0; j < 1+N; j++)
      CPXchgqpcoef(env, qp, j, j, qpsep[j]);

    // Now do other operators
    if(OBJOPER && KKTLVL > 0) {
      objoper_single_quadpart(i, &quadpart_length, quadpart_i, quadpart_j, quadpart_val);
      for(j = 0; j < quadpart_length; j++) {
        CPXgetqpcoef(env, qp, quadpart_i[j], quadpart_j[j], &tv);
        CPXchgqpcoef(env, qp, quadpart_i[j], quadpart_j[j], tv - sigma*quadpart_val[j]);
      }
    }

    if(KKTLVL == 2) {
      ycompoper_single_quadpart(i, &quadpart_length, quadpart_i, quadpart_j, quadpart_val);
      for(j = 0; j < quadpart_length; j++) {
        CPXgetqpcoef(env, qp, quadpart_i[j], quadpart_j[j], &tv);
        CPXchgqpcoef(env, qp, quadpart_i[j], quadpart_j[j], tv - sigma*quadpart_val[j]);
      }
    }

  }

  return(0);
}

int set_zi_qp_obj(CPXENVptr env, CPXLPptr qp, double sigma, double *pvar, double *dvar, double *ddir, int i, int sigma_reset_flag)
{
  int j, k, status;
  double qpsep[1+N];

  // BEGIN: linear part of QP objective
  // BEGIN: linear part of QP objective
  // BEGIN: linear part of QP objective

  // Create important vector (see formulas)
  for(k = 0; k < ddim; k++)
    solve_auglagr_tmp[k] = dvar[k] - sigma*ddir[k];

  // Zero out tempc, which will hold linear part of QP objective
  // Subsequent subroutines will add to tempc
  cblas_dscal(N+1, 0.0, tempc, 1);

  // Apply transpose of linear equations to dual variable (as prescribed by formulas)
  YZoperT(solve_auglagr_tmp, i, tempc);

  // Take negative (as prescribed by formulas)
  cblas_dscal(N+1, -1.0, tempc, 1); 

  // Change CPLEX linear objective
  status = CPXchgobj(env, qp, N+1, temp_indices, tempc);
  if (status) { fprintf(stderr, "Problem changing coeff for qp z^i\n"); return(status); }
  

  // BEGIN: quadratic part of QP objective
  // BEGIN: quadratic part of QP objective
  // BEGIN: quadratic part of QP objective

  if(sigma_reset_flag) {
    cblas_dscal(1+N, 0.0, qpsep, 1);
    YZoper_single_quadpart(i, qpsep);
    cblas_dscal(1+N, -sigma, qpsep, 1);
    for(j = 0; j < 1+N; j++)
      CPXchgqpcoef(env, qp, j, j, qpsep[j]);
  }

  return(0);
}

int solve_qp_subprob(CPXENVptr env, CPXLPptr qp, double *solnYZ, double *solny, double *solnz)
{
  int status, qpstat;

  // Solve QP
  status = CPXqpopt(env, qp);
  if (status) { fprintf(stderr, "Problem solving qp\n"); return (status); }

  // Get status of QP
  qpstat = CPXgetstat(env,qp);
  if (qpstat == CPX_STAT_INFEASIBLE || qpstat == CPX_STAT_INForUNBD) { printf("solve_qp_subprob: Subproblem is infeasible\n"); return(1977); }  

  // Get optimal solution of QP
  status = CPXgetx(env, qp, solnYZ, 0, N); 
  if (status) { fprintf(stderr, "Problem getting x values of qp subproblem\n"); return(status); }

  if(KKTLVL == 1 && solny != NULL && solnz != NULL) {
    status = CPXgetx(env, qp, solny, N+1, N+1 + m - 1); 
    if (status) { fprintf(stderr, "Problem getting y values of qp subproblem\n"); return(status); }
    status = CPXgetx(env, qp, solnz, N+1 + m, N+1 + m + n - 1); 
    if (status) { fprintf(stderr, "Problem getting z values of qp subproblem\n"); return(status); }
  }

  return(0);
}

int solve_auglagr(CPXENVptr env, CPXLPptr *qp, double *curval, double sigma,
                  double *pvar, double *dvar, double *ddir, int num_psd_cycles, int num_qp_cycles,
                  int *sigma_reset_flag, int *basis_array_uninit, char *skipcols)
{
  int i, j, loop, status = 0;
  int psd_loop;
  double *Y, *U, *Z, *y, *z, *sym_lambda, *S, *z_lambda, *obj_lambda, *ycomp_lambda;

  int    index;
  double zero = 0.0, origub;
  char   u = 'U';
  
  // Actually, sym_lambda and z_lambda not needed in this routine
  assign_pdvars(pvar,dvar,NULL,&Y,&U,&Z,&y,&z,&sym_lambda,&S,&z_lambda,&obj_lambda,&ycomp_lambda,NULL,NULL,NULL,NULL,NULL,1,1,0);
  sym_lambda = z_lambda = obj_lambda = ycomp_lambda = NULL;

  for(psd_loop = 1; psd_loop <= num_psd_cycles; psd_loop++)
    {

      //----------------------------------------------------------------------------
      //---- begin: solve subproblem for fixed U -----------------------------------
      //----------------------------------------------------------------------------

      for(loop = 1; loop <= num_qp_cycles; loop++)
        {

          // 
          // Solve y^0 qp subproblem
          //

          processdir(pvar, 'Y', 0, 1, ddir);

          status = set_yi_qp_obj(env, qp[0], sigma, pvar, dvar, ddir, 0, *sigma_reset_flag);
          if (status) { fprintf(stderr, "Problem setting y^0 qp obj\n"); return(status); }

          if (!(*basis_array_uninit)) {
            status = CPXcopybase(env, qp[0], cstatus[0], rstatus[0]);
            if (status) { fprintf(stderr, "Error copying basis into problem\n"); return(status); }
          }

          status = solve_qp_subprob(env, qp[0], Y, y, z);
          if ((status != 0) && (status != 1977)) {
            fprintf(stderr, "solve_auglagr: Problem solving y^0 qp\n"); printf("solve_auglagr: status = %d\n", status); return(status);
          }
	  if (status == 1977) { return(status); }

          status = CPXgetbase(env, qp[0], cstatus[0], rstatus[0]);
          if (status) { fprintf(stderr, "Error getting basis from problem\n"); return(status); } 

          processdir(pvar, 'Y', 0, -1, ddir);

          for(i = 1; i < N+1; i++)
	    {

              if(skipcols == NULL || skipcols[i] == 0) {

                // 
                // Solve y^i qp subprob
                // 

                processdir(pvar, 'Y', i, 1, ddir);
               
                status = set_yi_qp_obj(env, qp[1], sigma, pvar, dvar, ddir, i, *sigma_reset_flag);
                if (status) { fprintf(stderr, "Problem setting y^i qp obj\n"); return(status); }

                // If KKTLVL = 2 and i is appropriate, change upper bound on certain variable to 0
                // The code save original upper bound (which could already be implied in qp[1])
                if(KKTLVL == 2 && (i <= n || i >= n + m + 1)) {
                  if(i <= n) index = n + m + i;
                  else       index = i - (n + m);
                  status = CPXgetub(env, qp[1], &origub, index, index);
                  if (status) { fprintf(stderr, "Problem getting original bound related to complementarity.\n"); return(status); }
                  status = CPXchgbds(env, qp[1], 1, &index, &u, &zero);
                  if (status) { fprintf(stderr, "Problem changing bounds related to complementarity.\n"); return(status); }
                }

                if (!(*basis_array_uninit)) {
                  status = CPXcopybase(env, qp[1], cstatus[i], rstatus[i]);
                  if (status) { fprintf(stderr, "Error copying basis into problem\n"); return(status); }
                } 

                status = solve_qp_subprob(env, qp[1], Y + i*(N+1), NULL, NULL);
                if (status) { fprintf(stderr, "Problem solving y^i qp\n"); return(status); }

                status = CPXgetbase(env, qp[1], cstatus[i], rstatus[i]);
                if (status) { fprintf(stderr, "Error getting basis from problem\n"); return(status); }

                // If KKTLVL = 2 and i is appropriate, reset upper bound on certain variable to original value
                if(KKTLVL == 2 && (i <= n || i >= n + m + 1)) {
                  if(i <= n) index = n + m + i;
                  else       index = i - (n + m);
                  status = CPXchgbds(env, qp[1], 1, &index, &u, &origub);
                  if (status) { fprintf(stderr, "Problem changing bounds related to complementarity.\n"); return(status); }
                }
            
                processdir(pvar, 'Y', i, -1, ddir);

              }

              //
              // Solve z^i qp subproblem
              //

              if(UBE) {

                processdir(pvar, 'Z', i, 1, ddir);

                status = set_zi_qp_obj(env, qp[2], sigma, pvar, dvar, ddir, i, *sigma_reset_flag);
                if (status) { fprintf(stderr, "Problem setting y^i qp obj\n"); return(status); }

                if (!(*basis_array_uninit)) {
                  status = CPXcopybase(env, qp[2], cstatus[i+N], rstatus[i+N]);
                  if (status) { fprintf(stderr, "Error copying basis into problem\n"); return(status); }
                }

                status = solve_qp_subprob(env, qp[2], Z + (N+1)*i, NULL, NULL);
                if (status) { fprintf(stderr, "Problem solving z^i qp\n"); return(status); }

                status = CPXgetbase(env, qp[2], cstatus[i+N], rstatus[i+N]);
                if (status) { fprintf(stderr, "Error getting basis from problem\n"); return(status); }

                processdir(pvar, 'Z', i, -1, ddir);

              }

              //
              // Solve y^0 qp subproblem
              //

              processdir(pvar, 'Y', 0, 1, ddir);

              status = set_yi_qp_obj(env, qp[0], sigma, pvar, dvar, ddir, 0, *sigma_reset_flag);
              if (status) { fprintf(stderr, "Problem setting y^0 qp obj\n"); return(status); }
      
              status = CPXcopybase(env, qp[0], cstatus[0], rstatus[0]);
              if (status) { fprintf(stderr, "Error copying basis into problem\n"); return(status); }

              status = solve_qp_subprob(env, qp[0], Y, y, z);
	      if (status) { fprintf(stderr, "Problem solving y^0 qp\n"); return(status); }

              status = CPXgetbase(env, qp[0], cstatus[0], rstatus[0]);
              if (status) { fprintf(stderr, "Error getting basis from problem\n"); return(status); }

              processdir(pvar, 'Y', 0, -1, ddir);

	    }

          *sigma_reset_flag   = 0;
          *basis_array_uninit = 0;
  
        }

      //----------------------------------------------------------------------------
      //----  end:  solve subproblem for fixed U -----------------------------------
      //----------------------------------------------------------------------------


      //----------------------------------------------------------------------------
      //---- begin: solve subproblem for fixed Y -----------------------------------
      //----------------------------------------------------------------------------

      if(PSD) {

        processdir(pvar, 'U', -1, 1, ddir);

        for(i = 0; i < N+1; i++)
          for(j = i; j < N+1; j++)
            U[updiag_index(i,j)] = -(1.0/sigma)*S[updiag_index(i,j)] + 0.5*(Y[i*(N+1)+j] + Y[j*(N+1)+i]);
        project_S(U);

        processdir(pvar, 'U', -1, -1, ddir);

      } 
 
      //----------------------------------------------------------------------------
      //----  end:  solve subproblem for fixed Y -----------------------------------
      //----------------------------------------------------------------------------

    }

  return(status);

}

