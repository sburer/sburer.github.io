#include "all.h"

void free_nodeinfo(NODEINFO *nodeptr)
{
  if (nodeptr->fixedindices) MYFREE(nodeptr->fixedindices);
  if (nodeptr->fixedtypes)   MYFREE(nodeptr->fixedtypes);

  if(HOTSTART == 2) MYFREE(nodeptr->dvar);

  MYFREE(nodeptr);  
}

int FathomTree(double zprimal, int *numintree)
{
  PQTREE *newpq;
  NODEINFO *nodeptr;
  double d, key;
  void *data;


  if (!pq->tree) /*make sure there is a tree to fathom*/
    return(0);

  newpq = CreatePQTree();

  d = (zprimal < BB_EPS && zprimal > -BB_EPS) ? 1.0 : BB_ABS(zprimal);

  for (;;) {
    
    DeleteTopPQTree (pq, &data, &key);
    if (!data) {
      break;
    }

    nodeptr = (NODEINFO *) data;

    /*
     * Insert in new tree
     */

//     if( ( REL_OR_ABS == 1 && (nodeptr->zrelax + MY_UB_ADJ - zprimal) / ( 1.0e-10 + fabs (zprimal)) < OPT_TOLERANCE - 1.0 ) ||
//         ( REL_OR_ABS == 2 && nodeptr->zrelax + MY_UB_ADJ - zprimal < ABS_TOLERANCE ) )
      if(myfathom(nodeptr->zrelax))
      {
		//printf("***Fathoming node after finding primal\n");
		free_nodeinfo(nodeptr);
	   (*numintree)--;
      }
    else
      {
      data = (void *) nodeptr;
      key = nodeptr->rank;
      
      InsertPQTree (newpq, &data, &key);
    }
  }
  MYFREE(pq);
  pq = newpq;
  return(0);
 
}  /*End of FathomTree*/

void FreeSubTree(PQNODE *tree)
{
  if (tree->l) FreeSubTree(tree->l);
  if (tree->r) FreeSubTree(tree->r);

  if (tree->data)
    free_nodeinfo( (NODEINFO *) tree->data);

  MYFREE(tree);
}

void terminate(char *messg)
{

  if (messg)
   printf("#######%s", messg);


  if (pq)
    {
      if (pq->tree) FreeSubTree(pq->tree);
      MYFREE(pq);
      pq = NULL;
    }


  exit(0);
}
