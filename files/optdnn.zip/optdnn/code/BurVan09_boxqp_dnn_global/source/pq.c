/*
 *     MINTO - Mixed INTeger Optimizer
 *
 *     VERSION 2.4
 *
 *     Author:    M.W.P. Savelsbergh
 *                School of Industrial and Systems Engineering
 *                Georgia Institute of Technology
 *                Atlanta, GA 30332-0205
 *                U.S.A.
 *
 *     (C)opyright 1992-1994 - M.W.P. Savelsbergh
 */

/*
 * PQ.C
 */

#include <stdio.h>
#include <stdlib.h>
#include "myalloc.h"
#include "mypqdefs.h"


/*
 * Function prototypes
 */
 
#ifdef PROTOTYPING
PQTREE * CreatePQTree (void);
void InsertPQTree (PQTREE *, void **, double *);
void TopPQTree (PQTREE *, void **, double *);
void DeleteTopPQTree (PQTREE *, void **, double *);
void DeletePQTree (PQTREE *, void (*)());
static void FreePQSubTree (PQNODE *, void (*)());
void DeleteNodePQTree( PQTREE *, PQNODE *, void **, double * );
static unsigned SwapWithLast( PQNODE *, int, int );
void PrintPQSubTree( PQNODE * );
static void BubbleDown( PQNODE * );
static void BubbleUp( PQNODE * );
void CheckPQSubTree( PQNODE * );
static void dec (int, int *, int *);
static void ins (PQNODE *, PQNODE *, int, int);
static void del (int, int);
#else
PQTREE * CreatePQTree ();
void InsertPQTree ();
void TopPQTree ();
void DeleteTopPQTree ();
void DeletePQTree ();
static void FreePQSubTree ();
void DeleteBestBoundPQTree( );
static unsigned SwapWithLast( );
void PrintPQSubTree( );
static void BubbleDown( );
static void BubbleUp( );
void CheckPQSubTree( );
static void dec ();
static void ins ();
static void del ();
#endif

/*
 * PRIORITY QUEUE
 *
 * Pointer implementation for priority queues.
 *
 * Note: A level and position is associated with each node of the
 * tree as follows:
 *                          (0,0)                       <- level 0
 *              (1,0)                  (1,1)            <- level 1
 *        (2,0)       (2,1)       (2,2)       (2,3)     <- level 2
 *     (4,0) (4,1) (4,2) (4,3) (4,4) (4,5) (4,6) (4,7)  <- level 4
 *
 * This implies that a node with a position strictly less than its level
 * is in the left part of the tree. This property can easily be enforced
 * on a subtree by just dividing the level by the appropriate power of two.
 */

static PQNODE *tree;
static int intree;

/*
 * CreatePQTree
 */
                 
PQTREE *
CreatePQTree ()
{
    PQTREE *pq;
    
    MYMALLOC(pq, PQTREE);
    pq->tree      = NULL;
    pq->intree    = 0;
    pq->maxintree = 0;

    return (pq);
}

/*
 * InsertPQTree
 */
 
void
InsertPQTree (pq, data, key)
PQTREE *pq;
void **data;
double *key;
{
    PQNODE *nn;

    tree = pq->tree;
    intree = pq->intree;
    
    MYMALLOC(nn,PQNODE);
    nn->key = *key;
    nn->l = NULL;
    nn->r = NULL;
    nn->parent = NULL;
    nn->data = *data;

    if (intree == 0) {
        tree = nn;
        intree = 1;
    }
    else {
        int i1, i2;
        dec(++intree,&i1,&i2);
        ins(nn,tree,i1,i2);
    }

    pq->tree = tree;
    pq->intree = intree;

    /*
     * Statistics
     */
     
    if (pq->intree > pq->maxintree) {
        pq->maxintree = pq->intree;
    }
}

/*
 * TopPQTree
 */
 
void
TopPQTree (pq, data, key)
PQTREE *pq;
void **data;
double *key;
{
    if (pq->intree == 0) {
        *data = NULL;
        *key = 0.0;
    }
    else {
        *data = pq->tree->data;
        *key = pq->tree->key;
    }
}

/*
 * DeleteTopPQtree
 */
 
void
DeleteTopPQTree (pq, data, key)
PQTREE *pq;
void **data;
double *key;
{
    tree = pq->tree;
    intree = pq->intree;
    
    if (intree == 0) {
        *data = NULL;
        *key = 0.0;
    }
    else {
        *data = tree->data;
        *key = tree->key;
        if (intree == 1) {
            intree = 0;
            MYFREE(tree);
            tree = NULL;
        }
        else {
            int i1, i2;
            dec(intree--,&i1,&i2);
            del(i1,i2);
        }
    }

    pq->tree = tree;
    pq->intree = intree;
}

/*
 * DeletePQTree
 */
 
void
DeletePQTree (pq, freedata)
PQTREE *pq;
void (*freedata)();
{
    tree = pq->tree;
    intree = pq->intree;
    
    if (tree) FreePQSubTree (tree, freedata);
}

/*
 * FreePQSubTree
 */
 
static void
FreePQSubTree (tn, freedata)
PQNODE *tn;
void (*freedata)();
{
    if (tn->l) {
        FreePQSubTree (tn->l, freedata);
    }
    if (tn->r) {
        FreePQSubTree (tn->r, freedata);
    }

    (*freedata)(tn->data);
    
    MYFREE(tn);
    intree--;
}


/* JEFF'S CODE STARTS HERE */

void
DeleteNodePQTree (pq, node, data, key)
PQTREE *pq;
PQNODE *node;
void **data;
double *key;
{
  tree = pq->tree;
  intree = pq->intree;

  if (intree == 0) {
     *data = NULL;
     *key = 0.0;
     return;
  }
  else {
      *data = node->data;
      *key = node->key; 
  }

  if (intree == 1) {
      intree = 0;
      MYFREE(tree);
      tree = NULL;
  }
  else {      
      int i1, i2;
      dec(intree--,&i1,&i2);      

      if (SwapWithLast (node, i1, i2)) {
        if (*key < node->key - BB_EPS) {
          BubbleUp (node);
        }
        if (*key > node->key + BB_EPS) {
          BubbleDown (node);
        }
      }
  }

  pq->tree = tree;
  pq->intree = intree;
}

/*
 * SwapWithLast
 */

static unsigned
SwapWithLast(pqnode, i1, i2)
PQNODE *pqnode;
int i1;
int i2;
{
    PQNODE *cn, *cnc;

    cn = tree;
    while (i1 > 1) {
        if (i1 > i2)
            cn = cn->l;
        else {
            cn = cn->r;
            i2 -= i1;
        }
        i1 /= 2;
    }
    if (i1 > i2) {
        cnc = cn->l;
        cn->l = NULL;
    }
    else {
        cnc = cn->r;
        cn->r = NULL;
    }

    if (pqnode == cnc) {
        MYFREE(cnc);
        return (BB_FALSE);
    }
    else {
        pqnode->data = cnc->data;    
        pqnode->key = cnc->key;
        MYFREE(cnc);
        return (BB_TRUE);
    }
}


/*
 * PrintPQSubTree.  This is for debugging purposes only.
 */


void
PrintPQSubTree (pqnode)
PQNODE *pqnode;
{
    if (!pqnode) {
      printf("empty\n");
      return;
    }

    printf ("Key value: %f \n", pqnode->key); fflush( stdout );
    if (pqnode->l) printf ("Left\n");
    PrintPQSubTree (pqnode->l);
    
    
    if (pqnode->r) printf ("Right\n");
    PrintPQSubTree (pqnode->r);
}


/*
 * BubbleDown
 */

static void
BubbleDown( nn )     
PQNODE *nn;
{
  PQNODE *cn, *cnc;
  void *data;
  double key;

  cn = nn;
  cnc = cn->l;
  while (cnc != NULL) {
      if ((cn->r != NULL) && (cn->r->key > cnc->key)) {
          cnc = cn->r;
      }
      if (cn->key < cnc->key) {
          data = cnc->data;
          cnc->data = cn->data;
          cn->data = data;
          key = cnc->key;
          cnc->key = cn->key;
          cn->key = key;
          cn = cnc;
          cnc = cn->l;
      }
      else {
          cnc = NULL;
      }
  }
}

/*
 * BubbleUp
 */

static void
BubbleUp( nn )     
PQNODE *nn;
{
  PQNODE *cn, *cnc;
  void *data;
  double key;

  cn = nn;
  cnc = cn->parent;
  while (cnc != NULL) {
      if (cnc->key >= cn->key) {
        return;
      }
      else {
          data = cnc->data;
          cnc->data = cn->data;
          cn->data = data;
          key = cnc->key;
          cnc->key = cn->key;
          cn->key = key;
          cn = cnc;
          cnc = cn->parent;   
      }
  }
}



/*
 * CheckPQSubTree.  This is for debugging purposes only.
 */

#ifdef DEBUG 
void
CheckPQSubTree (pqnode)
PQNODE *pqnode;
{
    if (!pqnode) {
      return;
    }

    if (pqnode->l) CheckPQSubTree (pqnode->l);
    if ( ( pqnode->parent->key < pqnode->key ) && ( pqnode->parent != NULL ) )
      printf(" BIG PROBLEM -- Queue is wrong\n");
    if (pqnode->r) CheckPQSubTree (pqnode->r);
}
#endif


/*
 * CORE FUNCTIONS FOR MAINTAINING THE PRIORITY QUEUE:
 *
 *    DEC
 *    INS
 *    DEL
 */
 
static void
dec (ii, i1, i2)
int ii;
int *i1;
int *i2;
{
    *i1 = 1;
    while (*i1 * 2 <= ii) *i1 *= 2;
    *i2 = ii - *i1;
    *i1 /= 2;
}

static void
ins (nn, cn, i1, i2)
PQNODE *nn;
PQNODE *cn;
int i1;
int i2;
{
    PQNODE *cnc;
    void *data;
    double key;
    
    if (i1 > 1) {
        if (i1 > i2)
            cnc = cn->l;
        else {
            cnc = cn->r;
            i2 -= i1;
        }
        i1 /= 2;
        ins(nn,cnc,i1,i2);
    }
    else {
        if (i1 > i2)
            cn->l = nn;
        else
            cn->r = nn;
        cnc = nn;
    cnc->parent = cn;
    }
    if (cnc->key > cn->key) {
        data = cnc->data;
        cnc->data = cn->data;
        cn->data = data;
        key = cnc->key;
        cnc->key = cn->key;
        cn->key = key;
   }
}

static void
del (i1, i2)
int i1;
int i2;
{
    PQNODE *cn, *cnc;
    void *data;
    double key;
    
    cn = tree;
    while (i1 > 1) {
        if (i1 > i2)
            cn = cn->l;
        else {
            cn = cn->r;
            i2 -= i1;
        }
        i1 /= 2;
    }
    if (i1 > i2) {
        cnc = cn->l;
        cn->l = NULL;
    }
    else {
        cnc = cn->r;
        cn->r = NULL;
    }
    tree->data = cnc->data;
    tree->key = cnc->key;
    MYFREE(cnc);
    cn = tree;
    cnc = cn->l;
    while (cnc != NULL) {
        if ((cn->r != NULL) && (cn->r->key > cnc->key))
            cnc = cn->r;
        if (cn->key < cnc->key) {
            data = cnc->data;
            cnc->data = cn->data;
            cn->data = data;
            key = cnc->key;
            cnc->key = cn->key;
            cn->key = key;
            cn = cnc;
            cnc = cn->l;
        }
        else
            cnc = NULL;
    }
}

