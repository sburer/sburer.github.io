make clean
cp source/bandb.c.orig source/bandb.c
cp include/options.h.orig include/options.h
make
cp qpbb qpbb1
make clean
cp source/bandb.c.alt source/bandb.c
cp include/options.h.alt include/options.h
make
mv qpbb qpbbroot
make clean
mv qpbb1 qpbb
cp source/bandb.c.orig source/bandb.c
cp include/options.h.orig include/options.h
