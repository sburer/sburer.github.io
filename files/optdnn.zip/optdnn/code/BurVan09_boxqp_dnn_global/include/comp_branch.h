double comp_branch(int *newind, int *newtype, double *xval);
double comp_branch_kkt(int *newind, int *newtype, double *x, double *y, double *z);
