int partition(NODEINFO *nodeptr, int curindex, int curtype);
