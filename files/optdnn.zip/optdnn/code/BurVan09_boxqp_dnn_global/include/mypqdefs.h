#define BB_TRUE 1
#define BB_FALSE 0

#define BB_YES '1'
#define BB_NO '0'

#define BB_OPTIMAL 1
#define BB_INFEASIBLE 2

#define BB_FRACTIONAL 3
#define BB_INTEGRAL 4

#define BB_EPS 1E-15

#define BB_ABS(x)      ((x) < 0 ? -(x) : (x))

#define BB_max(A, B) ((A) > (B) ? (A) : (B))
#define BB_min(A, B) ((A) < (B) ? (A) : (B))


typedef struct pqnode
{
    double key;
    struct pqnode *l,*r;
    struct pqnode *parent;
    void *data;
} PQNODE;

typedef struct pqtree
{
    PQNODE *tree;
    int intree;
    int maxintree;
} PQTREE;

typedef struct
{
  double zrelax;

  double rank;
  
  int *fixedindices;
  int *fixedtypes;
  int numfixed;

  double *dvar; // for HOSTART == 2
  char objoper; // 0,1 -- indicates whether to add objective constraint

} NODEINFO;

