int matlab_start(Engine **ep_result, mxArray **mxQ_result, mxArray **mxc_result, mxArray **mxA_result, mxArray **mxb_result, mxArray **mxn_result);
double matlab_primal(double *xprimal, Engine *ep);

