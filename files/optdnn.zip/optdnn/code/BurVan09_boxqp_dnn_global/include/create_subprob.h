int create_qp_subprob(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp);
int create_qp_subprob_getubs(CPXENVptr env, CPXLPptr *lp, CPXLPptr *qp);
int create_qp_subprob_bmAxBAR(CPXENVptr env, CPXLPptr lp);
