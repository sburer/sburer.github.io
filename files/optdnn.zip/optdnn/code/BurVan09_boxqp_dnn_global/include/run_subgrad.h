SOLNINFO run_subgrad (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp, double *pvar, double *dvar, double *ddir, int printstyle, char *skipcols);
