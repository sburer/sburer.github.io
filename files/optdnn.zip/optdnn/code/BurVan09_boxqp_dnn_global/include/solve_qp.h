int solve_auglagr(CPXENVptr env, CPXLPptr *qp, double *curval, double sigma,
                  double *pvar, double *dvar, double *ddir, int num_psd_cycles, int num_qp_cycles,
                  int *sigma_reset_flag, int *basis_array_uninit, char *skipcols);

