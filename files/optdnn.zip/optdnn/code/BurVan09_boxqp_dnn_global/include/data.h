void read_qp_data   (char*);
void dealloc_qp_data(void);

extern int      n;
extern int      m;
extern double  *qpQ;
extern double  *qpc;
extern double  *qpA;
extern double  *qpb;
extern double  *ybar;
extern double  *zbar;
