//
// Interface options
//

#define PRINTSTYLE 1 // 0, 1

//
// Branch-and-bound options
//

#define REL_OR_ABS       1      // 1 = REL, 2 = ABS
#define OPT_TOLERANCE    1.00
#define ABS_TOLERANCE    1.0e-3
#define HOTSTART         1      // 0, 1, 2
#define MY_UB_ADJ        1.0e-6
#define MY_EARLYTERM_TOL 0.99   // Bigger than 1 means no early termination
#define YZX_BRANCH 0
#define AGG_YZ_BND 1
#define OBJOPER_RESOLVE  1

//
// Augmented Lagrangian options
//

#define ITERLIM 6000                  // ITERLIM set at 6000 b/c we expect at least one order of magnitude every 1000 iterations
#define SIGMA_FACTOR 1.58489319246111 // Following is so sigma increases by a factor of 10 every 500 iters
#define SIGMA_FREQ 100
#define BEGIN_NUM_CYCLES 1 
#define MAX_NUM_CYCLES 1
#define NORM_VIOL 1e-6
#define UB_FREQ 25
#define SKIPCOLS 1

#define USE_DSYEVR 0
//
// CPLEX options
//

#define MY_CPX_TOL 1.0e-9
