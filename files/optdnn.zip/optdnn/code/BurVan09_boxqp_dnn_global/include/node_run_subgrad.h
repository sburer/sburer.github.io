SOLNINFO node_run_subgrad (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp, int *fixedindices, int *fixedtypes,
                           int numfixedindices,  double *pvar, double *dvar, double *ddir);
