int create_qp_subprob(CPXENVptr, CPXLPptr *, CPXLPptr *);
