#define mymax(A, B) ((A) > (B) ? (A) : (B))
#define mymin(A, B) ((A) < (B) ? (A) : (B))

//Index into array storing upper triangle of symmetric matrix for 0 <= i <= j <= n
#define updiag_index(i,j) (i + ((int) (j*(j+1)/2)) )

//Index into array storing strictly upper triangle of symmetric matrix for 0 <= i < j <= n
#define supdiag_index(i,j) (i + ((int) ((j-1)*j/2)) )

//Index into square matrix stored row-wise for 0 <= i <= numcols, 0 <= j <= numcols
#define square_index(i,j,numcols)  ((i*(numcols)) + j)
