extern int N;
extern int YDIM;
extern int ZDIM;
extern int UDIM;
extern int LDIM;

void alloc_pdvars(double **passed_pvar, double **passed_dvar, double **passed_ddir);
void dealloc_pdvars(double *pvar, double *dvar, double *ddir);
void assign_pdvars(double *pvar, double *dvar, double *ddir, double **Y, double **U, double **Z, double **y, double **z, double **sym_lambda, double **S, double **z_lambda, double **obj_lambda, double **ycomp_lambda, double **sym_dir, double **S_dir, double **z_dir, double **obj_dir, double **ycomp_dir, int pvar_yes, int dvar_yes, int ddir_yes);
