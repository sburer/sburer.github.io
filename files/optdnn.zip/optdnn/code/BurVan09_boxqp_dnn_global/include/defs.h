#define MAX_STRING 10
#define MY_EPS 1.0e-6

typedef struct solninfo
{
  int fathom;
  double relaxbnd;
  double primalbnd;
  double *xval;
  double *y;
  double *z;
  int problemcode;
} SOLNINFO;

