extern int     UBE;
extern int     PSD;  // indicates whether N or N+
extern int     KKTLVL;
extern int     OBJOPER;
extern char    FILETYPE;
extern double *xbar;
extern double xBAR;
extern double *bmAxbar;
extern double yBAR;
extern double origyBAR;
extern double zBAR;
extern double origzBAR;
