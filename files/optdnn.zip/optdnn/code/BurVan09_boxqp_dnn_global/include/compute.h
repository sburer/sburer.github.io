extern double *tempc;
extern double *qdiag;
extern int *temp_indices;
extern int **cstatus, **rstatus;

extern double *EigValue, *EigVector, *Work;
extern int INFO, tempN, incX;
extern char JOBZ, UPLO;

extern int *quadpart_i, *quadpart_j;
extern double *quadpart_val;

extern double *solve_auglagr_tmp;

void alloc_computearrays(CPXENVptr env, CPXLPptr *qp);
void dealloc_computearrays();
double compute_dir(double *pvar, double *ddir);
void update_duals(double stepsize, double *dvar, double *ddir);
void project_S(double *S);
void get_dsyevr_lengths(void);
