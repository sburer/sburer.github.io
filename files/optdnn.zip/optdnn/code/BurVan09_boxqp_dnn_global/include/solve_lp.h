int set_yi_lp_obj(CPXENVptr env, CPXLPptr lp, double *dvar, int i);
int set_zi_lp_obj(CPXENVptr env, CPXLPptr lp, double *dvar, int i);
int compute_upper_bnd(CPXENVptr env, CPXLPptr *lp, double *curval, double *dvar, char *skipcols);
