PQTREE *CreatePQTree (void);
void InsertPQTree (PQTREE *, void **, double *);
void PrintPQSubTree( PQNODE * );
void DeleteTopPQTree (PQTREE *, void **, double *);
