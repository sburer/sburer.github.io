extern PQTREE *pq;
extern double ZLB;
extern int pdim;
extern int ddim;
extern int special;
extern double my_earlyterm_tol;
int myfathom(double val);
int bandb (CPXENVptr env, CPXLPptr * lp, CPXLPptr * qp);
