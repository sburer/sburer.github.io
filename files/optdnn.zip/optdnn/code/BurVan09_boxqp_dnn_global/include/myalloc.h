/*
 *     MINTO - Mixed INTeger Optimizer
 *
 *     VERSION 2.0
 *
 *     Author:    M.W.P. Savelsbergh
 *                School of Industrial and Systems Engineering
 *                Georgia Institute of Technology
 *                Atlanta, GA 30332-0205
 *                U.S.A.
 *
 *     (C)opyright 1992-1994 - M.W.P. Savelsbergh
 */

/*
 * MYALLOC.H
 */
 
/* 
 * SPECIAL MEMORY SUB SYSTEM FOR DEBUGGING AND STATISTICS
 */








#define MYMALLOC(VAR,TYPE) \
    if (((VAR) = (TYPE *) malloc ((size_t)sizeof(TYPE))) == NULL) {\
        printf ("MINTO: Memory allocation failed\n");\
        exit(0);\
    }

#define MYCALLOC(VAR,TYPE,SIZE) \
    if (((VAR) = (TYPE *) calloc ((size_t)(SIZE), (size_t)sizeof(TYPE))) == NULL) {\
        printf ("MINTO: Memory allocation failed\n");\
        exit(0);\
    }

#define MYREALLOC(VAR,TYPE,SIZE) \
    if (VAR) {\
      if (((VAR) = (TYPE *) realloc ((void *)(VAR), (size_t)((SIZE)*sizeof(TYPE)))) == NULL) {\
        printf ("MINTO: Memory allocation failed\n");\
        exit(0);\
      }\
    }\
    else {\
      if (((VAR) = (TYPE *) calloc ((size_t)(SIZE), (size_t)sizeof(TYPE))) == NULL) {\
        printf ("MINTO: Memory allocation failed\n");\
        exit(0);\
      }\
    }

#define MYFREE(VAR) \
    free ((void *)(VAR));\
    VAR = NULL;


