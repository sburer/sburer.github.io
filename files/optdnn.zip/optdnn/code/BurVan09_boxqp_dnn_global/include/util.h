int mychgbds(CPXENVptr env, CPXLPptr lp, const int index, const double bound, const char boundtype);
void mywrite(CPXENVptr env, CPXLPptr lp, const char *filename);
void printY(double *Y);
void printduals(double *dvar);
