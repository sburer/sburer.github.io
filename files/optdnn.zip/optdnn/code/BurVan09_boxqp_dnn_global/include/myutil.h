void free_nodeinfo(NODEINFO *nodeptr);
int FathomTree(double zprimal, int *numintree);
void terminate(char *messg);
