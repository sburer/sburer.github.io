savedir = pwd;
cd ../../code/SDPNAL-0/
startup
cd(savedir)

!cp ../../data/qap/*.dat .

maxNumCompThreads(1);

infiles = dir('*.dat');

for i = 1:length(infiles)

  fname{i}  = infiles(i).name;
  fname2{i} = strcat(fname{i},'.out');

  fid = fopen(fname{i});
  n(i) =  fscanf(fid, '%f', 1);
  A{i} = -fscanf(fid, '%f', [n(i),n(i)]);
  B{i} = -fscanf(fid, '%f', [n(i),n(i)]);
  fclose(fid);

end

[tmp,I] = sort(n);

% for i = 1:length(infiles)
for i = 1:5

  ind = I(i);

  if n(ind) <= 36

    if exist(fname2{ind},'file') == 0

      diary(fname2{ind})
      [blk,Ft,CC,bb] = qapAW(A{ind},B{ind});
      [blk,At,C,b] = addpositive(blk,Ft,CC,bb);
      [obj,X,y,Z,runhist,W] = sdpNAL(blk,At,C,b);
      diary off

    end

  end

end

!rm -rf *.dat
