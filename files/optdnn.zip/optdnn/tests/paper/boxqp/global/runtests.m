!cp ../../../../code/paper/opt_boxqp_global.m .
!cp ../../../../code/paper/opt_dnn.m .
!cp ../../../../code/paper/*mex* .

!cp ../../../../data/boxqp/basic/*.in .
!cp ../../../../data/boxqp/extended/*.in .
!cp ../../../../data/boxqp/extended2/*.in .

maxNumCompThreads(1);

infiles = dir('*.in');

for i = 1:length(infiles)

  str  = infiles(i).name;
  str2 = strcat(str,'.out');

  if exist(str2,'file') == 0

    fid = fopen(str);
    n =  fscanf(fid, '%f', 1);
    c = -fscanf(fid, '%f', n);
    Q = -fscanf(fid, '%f', [n,n]);
    fclose(fid);

    diary(str2)
    opt_boxqp_global(Q,c);
    diary off

  end

end

% !mail sburer@gmail.com < ../../../mailmsg.txt 

!rm -rf *.in

!rm -rf ./opt_*.*
