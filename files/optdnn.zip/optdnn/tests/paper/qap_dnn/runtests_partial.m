!cp ../../../code/paper/opt_qap*.m .
!cp ../../../code/paper/opt_dnn*.m .
!cp ../../../code/paper/*mex* .
!cp ../../../code/paper/*mex* .

!cp ../../../data/qap/*.dat .

maxNumCompThreads(1);

infiles = dir('*.dat');

for i = 1:length(infiles)

  str{i}  = infiles(i).name;
  str2{i} = strcat(str{i},'.out');

  fid = fopen(str{i});
  n(i) =  fscanf(fid, '%f', 1);
  A{i} = -fscanf(fid, '%f', [n(i),n(i)]);
  B{i} = -fscanf(fid, '%f', [n(i),n(i)]);
  fclose(fid);

end

[tmp,I] = sort(n);

% for i = 1:length(infiles)
for i = 1:5

  ind = I(i);

  if n(ind) <= 36

    if exist(str2{ind},'file') == 0

      diary(str2{ind})
      tic
      [LB,retcode] = opt_qap_dnn(A{ind},B{ind});
      fprintf('FINAL STATUS:  LB = %.10f   retcode = %s   time = %f\n', LB, retcode, toc);
      diary off

    end

  end

end

% !mail sburer@gmail.com < ../../mailmsg.txt 

!rm -rf *.dat

!rm -rf ./opt_*
