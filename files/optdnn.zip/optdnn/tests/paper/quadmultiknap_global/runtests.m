reset(RandStream.getDefaultStream);

!cp ../../../code/paper/*quadmultiknap*.m .
!cp ../../../code/paper/opt_dnn*.m .
!cp ../../../code/paper/opt_dnn*.c .
!cp ../../../code/paper/*mex* .

diary on

for mycase = 1:3

  count{mycase} = [];

  for n = 10 : 10 : 50

    if mycase == 1
      m = 1;
    elseif mycase == 2
      m = 5;
    elseif mycase == 3
      m = ceil(n/2);
    end

    totaltime = 0.0;
    savecputime = cputime;

    for i = 1:50

      dens = ceil(100 * rand)

      [Q,A,b] = gen_quadmultiknap(n,m,dens);
      opt_quadmultiknap_global(Q,A,b);

      totaltime = totaltime + (cputime - savecputime);
      savecputime = cputime;

    end

    count{mycase} = [count{mycase};n,totaltime/50];

  end

end

format long
count{1}
count{2}
count{3}
format short

diary off

!rm -rf *quadmultiknap*.m
!rm -rf opt_dnn*.m
!rm -rf opt_dnn*.c
!rm -rf *mex*
