cp ../../../code/BurVan09_boxqp_dnn_global/qpbb .

cp ../../../data/boxqp/basic/*.in .
cp ../../../data/boxqp/extended/*.in .
cp ../../../data/boxqp/extended2/*.in .

for i in $(ls *.in); do

  if [ ! -f $i.out ]
  then
    ./qpbb kkt0 psdon box $i > $i.out
  fi

done

# mail sburer@gmail.com < ../../mailmsg.txt 

rm -rf *.in

rm -rf ./qpbb
