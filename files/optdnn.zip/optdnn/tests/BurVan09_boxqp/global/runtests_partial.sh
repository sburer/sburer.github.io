cp ../../../code/BurVan09_boxqp_dnn_global/qpbb .

cp ../../../data/boxqp/basic/*.in .
cp ../../../data/boxqp/extended/*.in .
cp ../../../data/boxqp/extended2/*.in .

counter=0

for i in $(ls *.in); do

  if [ ! -f $i.out ]
  then
    if [ $counter -lt 5 ]
    then
      ./qpbb kkt0 psdon box $i > $i.out
      let counter+=1
    fi
  fi

done

rm -rf *.in

rm -rf ./qpbb
