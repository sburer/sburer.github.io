cp ../../../code/BurVan09_boxqp_dnn_global/qpbbroot .

cp ../../../data/boxqp/basic/*.in .
cp ../../../data/boxqp/extended/*.in .
cp ../../../data/boxqp/extended2/*.in .

for i in $(ls *.in); do

  if [ ! -f $i.out ]
  then
    ./qpbbroot kkt0 psdon box $i > $i.out
  fi

done

rm -rf *.in

rm -rf ./qpbbroot
