cp ../../../code/BurVan09_boxqp_dnn_global/qpbbroot .

cp ../../../data/boxqp/basic/*.in .
cp ../../../data/boxqp/extended/*.in .
cp ../../../data/boxqp/extended2/*.in .

counter=0

for i in $(ls *.in); do

  if [ ! -f $i.out ]
  then
    if [ $counter -lt 5 ]
    then
      ./qpbbroot kkt0 psdon box $i > $i.out
      let counter+=1
    fi
  fi

done

# mail sburer@gmail.com < ../../mailmsg.txt 

rm -rf *.in

rm -rf ./qpbbroot
