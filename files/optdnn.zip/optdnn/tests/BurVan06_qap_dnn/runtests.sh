cp ../../code/BurVan06_qap_dnn/auglagr .

cp ../../data/qap/*.dat .

for i in $(ls *.dat); do

  if [ ! -f $i.out ]
  then
    ./auglagr psdon qap $i > $i.out
  fi

done

# mail sburer@gmail.com < ../mailmsg.txt 

rm -rf *.dat

rm -rf ./auglagr
