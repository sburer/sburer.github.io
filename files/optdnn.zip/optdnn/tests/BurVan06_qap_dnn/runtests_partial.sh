cp ../../code/BurVan06_qap_dnn/auglagr .

# This should be the five smallest problems

cp ../../data/qap/*10*.dat .
cp ../../data/qap/chr12*.dat .

counter=0

for i in $(ls *.dat); do

  if [ ! -f $i.out ]
  then
    if [ $counter -lt 5 ]
    then
      ./auglagr psdon qap $i > $i.out
      let counter+=1
    fi
  fi

done

rm -rf *.dat

rm -rf ./auglagr
