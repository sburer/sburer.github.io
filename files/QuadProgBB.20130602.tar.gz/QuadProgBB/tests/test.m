clear
load ex2_1_1
options.checkpt = 0;
% options.checkfile = 'check016.mat';
[x,fval,time,stat] = quadprogbb(H,f,A,b,Aeq,beq,LB,UB,options);
