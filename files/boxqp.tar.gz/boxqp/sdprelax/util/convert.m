function convert(Q,c,fname)

% Calculate SDP relaxations of
%
%   max  0.5*x'*Q*x + c'*x
%   s.t. 0 <= x <= e
%
% First relaxation ('simple', without RLT) is
%
%   max  0.5*trace(Q*X) + c'*x
%   s.t. diag(X) <= x
%        [1,x';x,X] PSD
%        
% Second relaxation ('rlt', with RLT) is
% 
%   max  0.5*trace(Q*X) + c'*x
%   s.t. diag(X) <= x
%        [1,x';x,X] PSD
%        X(i,j) <= x(i)              for all i > j
%        X(i,j) <= x(j)              for all i > j
%        X(i,j) >= 0                 for all i > j
%        X(i,j) >= x(i) + x(j) - 1   for all i > j

%%%%%%%%%
% FIRST %
%%%%%%%%%

n = length(c);

QQ = 0.5*[0,c';c,Q];

Y = sdpvar(1+n,1+n,'symm');
F =     set( Y(1,1) == 1 );
F = F + set( Y >= 0 );
F = F + set( diag(Y(2:1+n,2:1+n)) <= Y(2:1+n,1) );

obj = sum(sum( QQ .* Y ));

solvesdp(F,-obj,sdpsettings('dualize',1,'solver','csdp'));

str = ['!mv mydata.dat-s ' fname '.simple.dat-s'];
str
eval(str);

%%%%%%%%%%
% SECOND %
%%%%%%%%%%

for i = 1:n
  for j = 1:i-1
    F = F + set( Y(1+i,1+j) <= Y(1+i,1) );
    F = F + set( Y(1+i,1+j) <= Y(1+j,1) );
    F = F + set( Y(1+i,1+j) >= 0        );
    F = F + set( Y(1+i,1+j) >= Y(1+i,1) + Y(1+j,1) - 1 );
  end
end

solvesdp(F,-obj,sdpsettings('dualize',1,'solver','csdp'));

str = ['!mv mydata.dat-s ' fname '.rlt.dat-s'];
str
eval(str);

% Clean up

str = '!rm -rf param.csdp';
eval(str);
