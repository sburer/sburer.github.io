infiles = dir('*.in');

for i = 1:length(infiles)

  str  = infiles(i).name;

  fid = fopen(str);
  n = fscanf(fid, '%f', 1);
  c = fscanf(fid, '%f', n);
  Q = fscanf(fid, '%f', [n,n]);
  fclose(fid);

  convert(Q,c,str);

end
