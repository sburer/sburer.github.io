#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <float.h>
#include <math.h>

#ifdef __WIN32
  #include <time.h>
#else
  #include <sys/times.h>
  #include <unistd.h>
#endif
