// global variables

// #ifndef __MEX
// #define size_t int
// #endif

extern size_t       global_blk;
extern problemdata *global_data;
extern double      *global_UtB;
extern double      *global_VtB;

extern double *global_UVt;
extern double *global_ARD;
extern double *global_ADD;
