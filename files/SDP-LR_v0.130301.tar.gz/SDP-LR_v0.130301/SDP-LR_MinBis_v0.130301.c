#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct {
  double *s;
  double *y;
  double rho;
  double a;
} l_bfgs;

typedef struct {
  int chunks;
  int maxiter;
  int maxtime;
  int M;
  int freqprint;
  int miniteronsubprob;
  int miniteronstage;
} params;

void    gradient(double*);
void    normalize(double*);
double  function(double*);
double  f_inexact_lsearch(double*, double, double*, double, double*);
double  f_bracketing(double*, double, double, double, double, double, double,
         double, double*, double, double*);
double  f_sectioning(double*, double*, double, double, double, double, double,
         double, double, double, double, double, double, double, double*, int);
int     f_interpolation_quadratic(double, double, double, double, double,
         double, double, double*);
double  min(double, double);
double  max(double, double);
int     addvec(double*, double*, double*, double, int);
int     specaddvec(double*, double*, double*, double, int);
double  dotproduct(double*, double*, int);
double  specdotproduct(double*, double*);
clock_t GetTime(void);
double  TimeInSec(clock_t, clock_t);
double  specinfnorm(double*);
int     n, m, *C1, *C2, *sumtoi, oldest, M, K, nowrank, maxrank;
double  *C3, *G, *D, constval, dirgradprod, extraobj;
double  penalty, lambda, specval, *specvec;
double  etabar, omegabar, tau, gammabar, alpha_omega;
double  beta_omega, alpha_eta, beta_eta, alpha_star, beta_star;
double  eta_star, omega_star, alpha_k, eta_k, omega_k;
params  *par;
l_bfgs  *vecs;

main(int argc, char *argv[])
{
   int h, i, j, k, iter, oldK, count;
   int lastchange, penaltychanged=1, earlychange=0;
   int lambdachange=0, lambdachangereq=5;
   int rankchange, iteronstage;
   double laststageval;
   double tempval, val, aval, alpha, totaltime;
   double *L, *aL, tempval3, relchanges[5], avgchange;
   FILE *datafile;
   clock_t begin, end;
   extern int n, m, *C1, *C2, *sumtoi, oldest, M, K;
   extern double *C3, *G, constval, dirgradprod;
   extern double penalty, lambda, specval, *specvec;

   if(argc != 3) {
     printf("Usage: %s <graph file> <parameter file>\n", argv[0]);
     return 0;
   }

   totaltime = 0.0;
   begin = GetTime();

   par = (params*)malloc(sizeof(params));
   datafile = fopen(argv[2], "r");
   fscanf(datafile, "%d\n", &par->chunks);
   fscanf(datafile, "%d\n", &par->maxiter);
   fscanf(datafile, "%d\n", &par->maxtime);
   fscanf(datafile, "%d\n", &par->M);
   fscanf(datafile, "%d\n", &par->freqprint);
   fscanf(datafile, "%d\n", &par->miniteronsubprob);
   fscanf(datafile, "%d\n", &par->miniteronstage);
   fclose(datafile);
   M = par->M;

   datafile = fopen(argv[1], "r");
   fscanf(datafile, "%d %d\n", &n, &m);

   maxrank = (int)sqrt(2*(n + 1)) + 1;
   K = (int)maxrank/par->chunks;
   if(K < 2) K = 2;
   rankchange = 0;

   C1 = (int*)malloc((m + 1)*sizeof(int));
   C2 = (int*)malloc((m + 1)*sizeof(int));
   C3 = (double*)malloc((m + 1)*sizeof(double));

   k = 1; constval = 0.0;
   for(h = 1; h <= m; h++) {
      fscanf(datafile, "%d %d %lf\n", &i, &j, &tempval);
      if(i < j) { C1[k] = i; C2[k] = j; C3[k++] = -tempval/4; }
      if(i > j) { C1[k] = j; C2[k] = i; C3[k++] = -tempval/4; }
      constval += tempval/2;  /* Really (2*tempval)/4 */
   }
   fclose(datafile);
   
   printf("\n");
   printf(" ==========================================================\n");
   printf("                            a nonlinear algorithm for\n");
   printf("                         solving the Minimum Bisection SDP\n");
   printf("  ** SDP-LR MinBis **   \n");
   printf("                            Sam Burer, Renato Monteiro\n");
   printf("                             Georgia Tech, v0.130301\n");
   printf(" ==========================================================\n\n");
   printf("     graph = %s\n", argv[1]);
   printf("   V, E, %% = %d, %d, %.2e\n\n", n, m, (double)200*m/(n*(n-1)));
   printf(" ==========================================================\n");
   printf("  iter     obj value      feas     norm      pen     time  \n");
   printf(" ----------------------------------------------------------\n");

   sumtoi = (int*)malloc((n + 1)*sizeof(int));
   sumtoi[0] = 0; /* necessary! */
   for(i = 1; i <= maxrank; i++) sumtoi[i] = (i*(i + 1))/2;
   for(i = maxrank+1; i <= n; i++) sumtoi[i] = sumtoi[maxrank] + (i-maxrank)*maxrank;

   L = (double*)calloc(sumtoi[n] + 1, sizeof(double));
   aL = (double*)calloc(sumtoi[n] + 1, sizeof(double));
   G = (double*)calloc(sumtoi[n] + 1, sizeof(double));
   D = (double*)calloc(sumtoi[n] + 1, sizeof(double));
   specvec = (double*)malloc((maxrank+1)*sizeof(double));

   vecs = (l_bfgs*)calloc(M + 1, sizeof(l_bfgs));
   for(i = 1; i <= M; i++) {
     (vecs+i)->s = (double*)calloc(sumtoi[n] + 1, sizeof(double));
     (vecs+i)->y = (double*)calloc(sumtoi[n] + 1, sizeof(double));
     for(j = 1; j <= sumtoi[n]; j++) (vecs+i)->s[j] = (vecs+i)->y[j] = 0.0;
     (vecs+i)->rho = (vecs+i)->a = 0.0;
   }
   oldest = 1;
   penalty = 1.5;
   lambda = 0.0;
   count = 0;

   for(i = 1; i <= sumtoi[n]; i++) L[i] = aL[i] = G[i] = D[i] = 0.0;
   for(i = 1; i <= K; i++) L[sumtoi[i-1] + i] = 1.0;
   for(i = K+1; i <= n; i++) {
     j = i%K;
     if(j == 0) j = K;
     L[sumtoi[i-1] + j] = 1.0;
   }

   normalize(L);
   val = function(L);
   gradient(L); 
   tempval = 1.0e15;
   alpha = 1.0;

   etabar = 1.0;    /* Affects choice between updating penalty or lambda. */ 
   omegabar = 1.0;  /* Affects subproblem stopping criteria. */
   gammabar = 0.99;  /* Used in calculation of alpha_k after penalty change. */
   alpha_omega = 1.0; /* Used only in the initial choice of omega_0. */
   alpha_eta = min(1.0, alpha_omega) - 0.01; /* Used only in the initial choice of eta_0. */
   beta_omega = 0.5; /* Used in the update of subproblem stopping criteria omega_k. */
   beta_eta = min(1.0, beta_omega) - 0.1; /* Used in the update of eta_k, which affects choice
                                             between updating penalty or lambda. */
   beta_eta = 0.5;                        /* The smaller, the more likely lambda is updated. */
   alpha_k = min(1.0, gammabar);
   omega_k = omegabar*pow(alpha_k, alpha_omega);
   eta_k = etabar*pow(alpha_k, alpha_eta);

   for(iter = 1; iter <= par->maxiter && totaltime <= par->maxtime; iter++) {

     tempval3 = fabs(specval);

     if(iter >= 6) {
       avgchange = 0.0;
       for(i = 0; i < 5; i++) avgchange += relchanges[i];
       avgchange /= 5.0;
     }

     if((tempval < max(omega_k, 1.0e-5) && count >= par->miniteronsubprob) || alpha < 1.0e-10) {

       if(n*tempval3/max(fabs(val),1.0) >= 1.0e-5) {

         if(tempval3 <= eta_k || (penalty >= 1.0e2 && lambdachange <= lambdachangereq) || penaltychanged == 1) {

/*           printf("Changing lambdas (%d) ...\n", lastchange); */
           lambdachange++;

           if(penalty >= 1.0e2 && lambdachange <= lambdachangereq && tempval3 > eta_k) earlychange = 1;

           lastchange++;
           lambda -= penalty*specval;
           penaltychanged = 0;

           alpha_k = 1/penalty;
           eta_k *= pow(alpha_k, beta_eta);
           omega_k *= pow(alpha_k, beta_omega);

         }
         else {

/*           printf("Changing penalties ...\n");  */
           lastchange = 0;

           penalty *= 10.0;
           penaltychanged = 1;
           lambdachange = 0;
           if(earlychange == 1) {
/*             beta_eta /= sqrt(10.0); */
             lambdachangereq += 0;
           }
           earlychange = 0;

           alpha_k = gammabar/penalty;
           eta_k = etabar*pow(alpha_k, beta_eta);
           omega_k = omegabar*pow(alpha_k, beta_omega);

         }

       }
       else {

         if(K >= maxrank || (K < maxrank && iteronstage >= par->miniteronstage && fabs(laststageval - val)/max(fabs(val), 1.0) < 1.0e-5)) {
           printf("  %5d  ", iter);
           if(val >= 0) printf(" ");
           printf("%.7e  %.1e  %.1e  %.1e  %6d\n", val, fabs(specval)*n, tempval, penalty, (int)totaltime);
           printf(" ----------------------------------------------------------\n");
           printf("  iter     obj value      feas     norm      pen     time  \n");
           printf(" ==========================================================\n");
           return 0;
         }
         else {
/*           printf("... increasing rank ...\n"); */
           rankchange++;
           laststageval = val; iteronstage = 0; oldK  = K;
           K = (int)min((double)maxrank, (double)K+(int)maxrank/par->chunks);
/*           printf("(oldK, K) = (%d, %d)\n", oldK, K); */
           for(j = oldK+1; j <= K; j++) {
             for(i = j; i <= n; i++) {
               L[sumtoi[i-1] + j] = (double)(i+j)/(n*n);
               if((i+j)%2 == 1) L[sumtoi[i-1] + j] *= -1.0;
             }
           }
           penalty = max(1.5e2, penalty/1000.0);
           penalty = min(penalty, 1.5e2);
         }

       }

       for(i = 0; i < 5; i++) relchanges[i] = 1.0;
       count = 0;
       for(i = 1; i <= M; i++) {
         specaddvec((vecs+i)->s, (vecs+i)->s, (vecs+i)->s, 0.0, 1);
         specaddvec((vecs+i)->y, (vecs+i)->y, (vecs+i)->y, 0.0, 1);
         (vecs+i)->rho = (vecs+i)->a = 0.0;
       }
       oldest = 1;
       normalize(L);
       val = function(L);
       gradient(L);
       alpha = 1.0;

     }

     /* specaddvec(D, D, G, -1.0, 1); */
     dir();
     dirgradprod = specdotproduct(D, G);
     specaddvec((vecs+oldest)->y, (vecs+oldest)->y, G, -1.0, 1);

     aval = f_inexact_lsearch(L, val, &alpha, 1.0e20, aL);
     updateLBFGS(alpha);

     specaddvec(L, L, aL, 1.0, 1);
     relchanges[iter%5] = fabs(val - aval)/fabs(val);
     val = aval;

     tempval = specinfnorm(G)/max(fabs(val),1.0);

     end = GetTime();
     totaltime += (double)TimeInSec(begin, end);
     begin = end;

     if(iter%par->freqprint == 0) {
       printf("  %5d  ", iter);
       if(val >= 0) printf(" ");
       printf("%.7e  %.1e  %.1e  %.1e  %6d\n", val, fabs(specval)*n, tempval, penalty, (int)totaltime);
     }

     count++;
     iteronstage++;
     
     if(isnan(val) || isnan(specval)) {
       printf("Error: loss of accuracy, terminating prematurely\n\n");
       return 0;
     } 
   }

   free(C1); free(C2); free(C3); 
   free(L); free(aL); free(G); free(D);
   free(sumtoi); free(par); free(specvec);
   for(i = 1; i <= M; i++) {
     free((vecs+i)->s); free((vecs+i)->y);
   }
   return 1;
}

void gradient(double* L)
{
  int i, j, k, h, tempint1, tempint2, upbd;
  double tempval;
  extern int n, m, *C1, *C2, *sumtoi, *nowtsumtoi, K;
  extern double *C3, *G, penalty, lambda, specval, *specvec;

  specaddvec(G, G, G, 0.0, 1);

  for(k = 1; k <= m; k++) {
    i = C1[k]; j = C2[k]; tempval = C3[k];
    tempint1 = sumtoi[i-1]; tempint2 = sumtoi[j-1];
    upbd = (int)min((double)i,(double)K);
    for(h = 1; h <= upbd; h++) {
      G[tempint1 + h] += tempval*L[tempint2 + h];
      G[tempint2 + h] += tempval*L[tempint1 + h];
    }
  }

  for(i = 1; i <= n; i++) {
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1]+upbd; j++)
      G[j] += (penalty*specval - lambda)*specvec[j - sumtoi[i-1]]/n;
  }

  specaddvec(G, G, G, 2.0, 1);

  for(i = 1; i <= n; i++) {
    tempval = 0.0;
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1] + upbd; j++) tempval += G[j]*L[j];
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1] + upbd; j++) G[j] -= tempval*L[j];
  }

  return;
}

void normalize(double* L)
{
  int i, j, upbd;
  double tempval;
  extern int n, *sumtoi, K;

  for(i = 1; i <= n; i++) {
    tempval = 0.0;
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1] + upbd; j++) tempval += L[j]*L[j];
    tempval = sqrt(tempval);
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1] + upbd; j++) L[j] /= tempval;
  }
  
  return;

}

double function(double* L)
{
  int i, j, k, h, tempint1, tempint2, upbd;
  double tempval, sum;
  extern int n, m, *sumtoi, *C1, *C2, K;
  extern double *C3, constval;
  extern double penalty, lambda, specval, *specvec;

  for(i = 1; i <= K; i++) specvec[i] = 0.0;
  for(i = 1; i <= n; i++) {
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1]+1; j <= sumtoi[i-1]+upbd; j++)
      specvec[j - sumtoi[i-1]] += L[j];
  }

  specval = (double)dotproduct(specvec, specvec, K)/n;
  extraobj = 0.5*penalty*specval*specval - lambda*specval;
  sum = constval + extraobj;
  for(k = 1; k <= m; k++) {
    i = C1[k]; j = C2[k];
    tempval = 0.0; tempint1 = sumtoi[i-1]; tempint2 = sumtoi[j-1];
    upbd = (int)min((double)i,(double)K);
    for(h = 1; h <= upbd; h++) tempval += L[tempint1 + h]*L[tempint2 + h];
    tempval *= C3[k];
    sum += 2*tempval;
  }

  return sum;
}

int dir(void)
{
  int i, ind;
  double beta;
  extern int n, m, oldest, *sumtoi, M, K;
  extern double *G, *D;
  extern l_bfgs *vecs;

  specaddvec(D, D, G, 1.0, 1);

  for(i = 1; i <= M; i++) {
    if(oldest - i > 0) ind = oldest - i;
    else ind = oldest - i + M;
    (vecs+ind)->a = (vecs+ind)->rho*specdotproduct((vecs+ind)->s, D);
    specaddvec(D, D, (vecs+ind)->y, -((vecs+ind)->a), 0);
  }
  for(i = M; i >= 1; i--) {
    if(oldest - i > 0) ind = oldest - i;
    else ind = oldest - i + M;
    beta = (vecs+ind)->rho*specdotproduct((vecs+ind)->y, D);
    specaddvec(D, D, (vecs+ind)->s, (vecs+ind)->a - beta, 0); 
  } 

  specaddvec(D, D, D, -1.0, 1);

  return 1;
}

int updateLBFGS(double a)
{
  extern int n, m, oldest;
  extern double *G, *D;
  extern l_bfgs *vecs;

  specaddvec((vecs+oldest)->y, (vecs+oldest)->y, G, 1.0, 0);
  specaddvec((vecs+oldest)->s, (vecs+oldest)->s, D, a, 1);
  (vecs+oldest)->rho = 1/specdotproduct((vecs+oldest)->y, (vecs+oldest)->s);
  oldest = oldest%M + 1;

  return 1;
}

double min(double a, double b)
{
  if(a < b) return a;
  else return b;
}

double max(double a, double b)
{
  if(a < b) return b;
  else return a;
}

int addvec(double* new, double* old, double* dir, double scalar, int length)
{
  int i;

  for(i = 1; i <= length; i++)
    new[i] = old[i] + scalar*dir[i];

  return 1;
}

int specaddvec(double* new, double* old, double* dir, double scalar, int option)
{
  int i, j, upbd;
  extern int n, K, *sumtoi;

  if(option == 1) {
    for(i = 1; i <= n; i++) {
      upbd = (int)min((double)i,(double)K);
      for(j = sumtoi[i-1] + 1; j <= sumtoi[i-1] + upbd; j++)
        new[j] = scalar*dir[j];
    }
    return 1;
  }

  for(i = 1; i <= n; i++) {
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1] + 1; j <= sumtoi[i-1] + upbd; j++)
      new[j] = old[j] + scalar*dir[j];
  }

  return 1;
}

double dotproduct(double* vec1, double* vec2, int length)
{
  int i;
  double sum;

  sum = 0.0;

  for(i = 1; i <= length; i++) sum += vec1[i]*vec2[i];

  return sum;
}

double specdotproduct(double* vec1, double* vec2)
{
  int i, j, upbd;
  double sum;
  extern int n, K, *sumtoi;

  sum = 0.0;

  for(i = 1; i <= n; i++) {
    upbd = (int)min((double)i,(double)K);
    for(j = sumtoi[i-1] + 1; j <= sumtoi[i-1] + upbd; j++)
      sum += vec1[j]*vec2[j];
  }

  return sum;
}

/* 
  function to compute alpha that min. the function f(x+alpha*d)  
  
  The algorithm is as given in Practical Optimization by R. Fletcher,
  page 33 through 39.
  
  */

double f_inexact_lsearch(double* x, double f_val, double* alpha, double alpha_upbd, double* ax) 
{
  /* define parameters */
  
  double sigma = 0.1;                 /* Wolfe Powell parameter */
  double rho   = 0.01;                /* Goldstein parameter */
  /* the smaller, the tighter -- rho */
  double tau1  = 9.0;                 /* preset factor for jump of alpha */
  double tau2  = 0.1;                 /* preset factor for alpha in sect. */
  double tau3  = 0.5;                 /* preset factor for alpha in sect. */ 
  double f_lower_bound = -1.0e20;      /* lower bound of objective function */
  double value;

  value = f_bracketing(x,f_val,sigma,rho,tau1,tau2,tau3,f_lower_bound,alpha,alpha_upbd,ax);
  return value;
} 


/* function bracketing to get a bracket trial for alpha */

double f_bracketing(double* x, double f_val, double sigma, double rho, double tau1, double tau2, double tau3, double f_lower_bound, double* alpha, double alpha_upbd, double* ax)
{
  double a;                     /* one value of alpha bracket */
  double b;                     /* another value of alpha bracket */
  double a1;                    /* lower limit of updated alpha */
  double b1;                    /* upper limit of updated alpha */ 
  double localmu;               /* upper bound of initial guess for alpha */
  double f_zero;                /* alpha function at alpha = 0 */
  double df_zero;               /* derivative of alpha function at alpha=0 */
  double f_a;                   /* alpha function value at alpha=a */
  double df_a;                  /* derivative of alpha function at alpha=a */
  double f_b;                   /* alpha function at b */
  double df_b;                  /* derivative of alpha function at alpha=b */
  double alpha_prev = 0.0;      /* previous value of alpha, initially 0 */
  double f_alpha_prev;
  double df_alpha_prev;
  double f_alpha;
  double df_alpha;
  int k = 1;
  double tempval, value;
  extern int n, m, *sumtoi, K;
  extern double *D, *G, dirgradprod;

  f_alpha_prev = f_zero = f_val;
  df_alpha_prev = df_zero = dirgradprod;

  localmu = (f_lower_bound - f_zero)/(rho*df_zero);
  /* *alpha = 1.0; */
  *alpha *= 1.5;

  k = 1;
  while(k < 20) {
    if(k == 99) printf("Reached upper threshhold. (1)\n");

    specaddvec(ax, x, D, *alpha, 0);
    normalize(ax);
    f_alpha = function(ax);

    if(isnan(f_alpha)) f_alpha = 1.0e20;

    if (f_alpha <= f_lower_bound) return f_alpha; /* This probably never occurs. */

    if (f_alpha > f_zero + (*alpha)*rho*df_zero || f_alpha >= f_alpha_prev) {
      a = alpha_prev; f_a = f_alpha_prev; df_a = df_alpha_prev;
      b = *alpha;     f_b = f_alpha;
      value = f_sectioning(x, ax, rho, tau2, tau3, sigma, a, b, f_zero, df_zero, f_a, f_b, df_a, 0, alpha, 2);
      return value;
    }
    gradient(ax);
    df_alpha = specdotproduct(D, G);

    if (fabs(df_alpha) <= ((-sigma)*df_zero)) return f_alpha;
    if (df_alpha >= 0.0) {
      a = *alpha;     f_a = f_alpha;      df_a = df_alpha;
      b = alpha_prev; f_b = f_alpha_prev; df_b = df_alpha_prev;
      value = f_sectioning(x, ax, rho, tau2, tau3, sigma, a, b, f_zero, df_zero, f_a, f_b, df_a, df_b, alpha, 3); 
      return value;
    }
    if(localmu <= (2*(*alpha) - alpha_prev)) {
      alpha_prev = *alpha;
      f_alpha_prev = f_alpha;
      df_alpha_prev = df_alpha;
      *alpha = localmu;
    }
    else {
      /* Store value of alpha before interpolation. */
      tempval = *alpha;
      /* Prepare for interpolation. */
      a = alpha_prev; f_a = f_alpha_prev; df_a = df_alpha_prev;
      b = *alpha;     f_b = f_alpha;      df_b = df_alpha;
      a1 = 2*(*alpha) - alpha_prev; 
      b1 = min(localmu, *alpha + tau1*(*alpha - alpha_prev));
      /* Do interpolation. */
      f_interpolation_quadratic(f_a, df_a, f_b, a, b, a1, b1, alpha);
      /* Prepare for next round. */
      alpha_prev = tempval;
      f_alpha_prev = f_alpha;
      df_alpha_prev = df_alpha;
    }
    k++;
  }

/*   printf("Line search failed (2).\n"); */
  return 1;

}


/* function to choose the section that gives the appropriate properties
   for alpha values */

double f_sectioning(double* x, double* ax, double rho, double tau2, double tau3, double sigma, double a, double b, double f_zero, double df_zero, double f_a, double f_b, double df_a, double df_b, double *alpha, int polytype)
{
  double a1;                 /* lower limit of alpha bracket */
  double b1;                 /* upper limit of alpha bracket */
  double f_alpha;
  double df_alpha;

  int k = 1;
  extern int n, m, *sumtoi;
  extern double *D, *G;

  while (k < 20) {
    if(k == 99) printf("Reached upper threshhold. (2)\n");

    a1 = a + tau2*(b - a);
    b1 = b - tau3*(b - a); 

    f_interpolation_quadratic(f_a, df_a, f_b, a, b, a1, b1, alpha);

    specaddvec(ax, x, D, *alpha, 0);
    normalize(ax);
    f_alpha = function(ax);

    if(isnan(f_alpha)) f_alpha = 2*f_a;

    if(f_alpha > f_zero + rho*(*alpha)*df_zero || f_alpha >= f_a) {
      /* Prepare for next round. */
      a = a;      f_a = f_a;     df_a = df_a;
      b = *alpha; f_b = f_alpha;
    }
    else {
      gradient(ax);
      df_alpha = specdotproduct(D, G);

      if (fabs(df_alpha) <= ((- sigma) * df_zero)) {
/*       if (df_alpha <= ((- sigma) * df_zero)) { */
    return f_alpha;
      }
      if((b - a) * df_alpha >= 0.0) {
    b = a; f_b = f_a; df_b = df_a;
      }
      else {
    b = b; f_b = f_b; df_b = df_b;
      }
      a = *alpha; f_a = f_alpha; df_a = df_alpha;
    }
    k++;
  }

/*   printf("Line search failed (2).\n"); */
  return f_alpha;
}


/* function to generate next choose of alpha by quadratic interpolation */

int f_interpolation_quadratic (double f_a, double df_a, double f_b, double a, double b, double a1, double b1, double *alpha) 
{
  double za1, zb1, root;
  double endptmin;

  za1 = f_a + df_a*(a1 - a) + (f_b - f_a - (b-a)*df_a)*(a1 - a)*(a1 - a)/((b - a)*(b - a));
  zb1 = f_a + df_a*(b1 - a) + (f_b - f_a - (b-a)*df_a)*(b1 - a)*(b1 - a)/((b - a)*(b - a));
  if(za1 < zb1) endptmin = a1;
  else endptmin = b1;
  root = a - (b-a)*(b-a)*df_a/(2*(f_b - f_a - (b-a)*df_a));

  if(f_b - f_a - (b-a)*df_a < 0) {       /* Opens downward. */
    if(a1 < b1) {
      if(a1 <= root && root <= b1) *alpha = endptmin;
      if(root < a1) *alpha = b1;
      if(root > b1) *alpha = a1;
    }
    else {
      if(b1 <= root && root <= a1) *alpha = endptmin;
      if(root < b1) *alpha = a1;
      if(root > a1) *alpha = b1;
    }
  }
  else {                                 /* Opens upward. */
    if(a1 < b1) {
      if(a1 <= root && root <= b1) *alpha = root;
      if(root < a1) *alpha = a1;
      if(root > b1) *alpha = b1;
    }
    else {
      if(b1 <= root && root <= a1) *alpha = root;
      if(root < b1) *alpha = b1;
      if(root > a1) *alpha = a1;
    }
  }

  return 1;

}



clock_t GetTime(void)
{
  clock_t t;

  struct tms {
    clock_t    tms_utime;
    clock_t    tms_stime;
    clock_t    tms_cutime;
    clock_t    tms_cstime;
  } tmrec;

  t = times(&tmrec);
  t = tmrec.tms_utime+tmrec.tms_stime;

  return t;
}

double TimeInSec(clock_t head,
                 clock_t rear)
{
  double tscal;

  tscal=0.01;
  return ((double)(rear-head)*tscal);
}

double specinfnorm(double *vec)
{
  int i, j, upbd;
  double val;
  extern int n, *sumtoi, K;

  val = -1.0;
  for(i = 1; i <= n; i++) {
    upbd = (int)min((double)i, (double)K);
    for(j = sumtoi[i-1] + 1; j <= sumtoi[i-1] + upbd; j++)
      if(fabs(vec[j]) > val) val = fabs(vec[j]);
  }

  return val;
}
