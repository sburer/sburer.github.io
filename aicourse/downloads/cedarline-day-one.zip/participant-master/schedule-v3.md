# New Starter Hub pilot calendar

4 August: Hub and orientation sessions begin at East and West.
15 September: pilot ends; survey invitation sent to attendees.
16–18 September: reconcile records and prepare initial feedback summary.
25 September: Dana reviews status and decides whether to authorize a next phase.
Early October: possible scheduling-page test if approved; dates not committed.
