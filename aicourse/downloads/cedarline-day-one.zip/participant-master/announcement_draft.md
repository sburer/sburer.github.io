Subject: The New Starter Hub is continuing

We're pleased to extend the Hub to all new employees next month. The pilot met its attendance goal and the new scheduling page is ready.

Draft saved 15 September, before the attendance check or an extension decision. Not approved to send. Use only as evidence of an outdated proposed message, not as the current plan.
