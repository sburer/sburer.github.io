# Early survey snippets — preliminary, 18 September

- “The welcome staff made the first day less awkward.”
- “I could not tell whether the 9 a.m. session was East or West.”
- “I searched for payroll and missed the checklist under Forms.”

These are selected comments, not a coded summary. Do not use them to calculate how common an issue is. A fuller response export is being prepared separately.
