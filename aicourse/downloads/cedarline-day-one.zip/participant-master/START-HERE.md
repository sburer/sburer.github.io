# Cedarline New Starter Hub: Friday update

You are an operations analyst at Cedarline, a fictional organization. Dana Chen, Director of People Operations, needs a one-page status update by Friday, 25 September 2026 to decide what to do next with a pilot onboarding help hub.

Read `Day 1 Student Guide.docx` for the full assignment. This is a copied practice folder. First find out what is here. Propose an organization and sensible names before changing anything; check ambiguous or conflicting files yourself. Then use the relevant evidence to make the update. Do not invent facts to fill gaps. Every file, name, person, and number here is fictional.

**A starting request you can adapt:** “Look only in this copied folder. Inventory every file and tell me what each appears to be. Propose a folder structure and specific moves, but do not move, rename, delete, or overwrite anything yet. Flag files that conflict, look duplicated, or seem unrelated. Tell me what you need me to decide.”

After you review the plan, approve only the changes you want. Ask for a before/after file count and inspect the result. For the update, tell the tool that Dana needs a decision-ready page, ask it to show the source for each key number, and check those sources yourself before using the result.
