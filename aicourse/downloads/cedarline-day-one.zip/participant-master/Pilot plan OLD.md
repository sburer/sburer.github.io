# New Starter Hub: early planning sketch

Drafted 12 July 2026. This was an initial idea, not the approved plan.

- Pilot: 4 August–29 August, one site only.
- Suggested success measure: 60 check-ins.
- Budget estimate: $2,500.
- If enough people attend, extend immediately in September.

The approved scope and later decision records supersede this sketch.
