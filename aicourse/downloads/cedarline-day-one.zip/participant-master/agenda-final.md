# Review meeting agenda — 16 September, first draft

1. Celebrate reaching 60 attendees.
2. Approve immediate extension.
3. Assign communications.

Drafted 15 September. The attendance figure and decision prompt had not yet been reconciled.
