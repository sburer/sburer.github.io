# Pilot at a glance — OLD SLIDE DRAFT

61 people attended (from raw check-ins; not reconciled).
The 60-attendee target was exceeded.
Spend is under budget.
Recommendation: extend the pilot immediately.

Prepared 16 September before attendance was deduplicated and before the extension decision was deferred. Do not reuse these conclusions without checking the later source files.
