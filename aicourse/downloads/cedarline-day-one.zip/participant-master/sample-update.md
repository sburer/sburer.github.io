# Sample of Dana's preferred update style (different project)

**Decision needed:** Approve a two-week test, not a full rollout.

The trial reached most intended users, but the open questions are about access and repeat use. We can answer those with a small test before committing next-quarter funds.

**What we know:** The tested group used the new form without staff assistance in most cases. This is a limited pilot result, not a promise about all teams.

**Next:** Name the owner, the test period, and the measure that would change our recommendation.

Use this as a tone/structure example; its facts belong to another project.
