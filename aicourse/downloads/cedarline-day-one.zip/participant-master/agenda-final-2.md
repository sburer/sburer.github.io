# Review meeting agenda — 16 September, revised

1. Reconcile unique attendees against the approved goal.
2. Review questions about orientation times and checklist findability.
3. Decide what evidence Dana needs before extending.

Revised 16 September at 8:30 a.m. This is not identical to `agenda-final.md`; keep both while organizing.
