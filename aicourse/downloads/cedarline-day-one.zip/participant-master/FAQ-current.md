# New Starter Hub FAQ — pilot version, 5 August 2026

The Hub is available to invited new employees at East and West. It has a searchable first-week guide and three short modules. The orientation schedule is linked from the home page, although the link text currently says “Events.” Employees may message the support desk for help. The pilot ends 15 September; an extension is not yet decided.
