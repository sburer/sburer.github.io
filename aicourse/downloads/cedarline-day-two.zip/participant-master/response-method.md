# What these records cover

The survey link went to **57 unique pilot attendees** on 15 September 2026. The 24 rows in `survey-responses.csv` are the responses received by 22 September. Taking the survey was optional. They are anonymous and may not reflect all attendees or all 84 people invited to the pilot. Ratings use 1 = very poor and 5 = very good.

`support-messages.csv` is a separate set of incoming help requests and comments during the pilot. A sender may have written more than once, and a sender may also have answered the survey; this cannot be linked from the supplied data. T03 and T04 are explicitly a follow-up from the same sender. Do not add tickets to the survey denominator or treat ticket counts as population prevalence.

When coding themes, count each survey response at most once **per theme**. A response can belong to more than one theme. Preserve the raw files and record your coding rule so someone else can check it.
