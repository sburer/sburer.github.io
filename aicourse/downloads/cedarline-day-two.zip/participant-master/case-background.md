# The case in one page

Cedarline is a fictional organization with East and West offices. Its **New Starter Hub** pilot gave newly hired employees a searchable first-week guide, three short onboarding modules, and optional staff help. The pilot ran from 4 August through 15 September 2026.

The organization invited 84 new employees. Of those, 68 registered, 57 unique people attended an orientation, and 44 completed all three modules. The approved attendance goal was at least 59 unique people, so the pilot fell two short. Cedarline has **not** approved an extension. Dana Chen, Director of People Operations, wants to know what to improve before deciding on a next phase.

This assignment focuses on **feedback about what to improve**. The survey and support records in this folder are the evidence you need. They have different sources and limitations, explained in `response-method.md`. You do **not** need any files or work from another class session. If this setting is familiar, still use this folder's evidence rather than relying on memory.
