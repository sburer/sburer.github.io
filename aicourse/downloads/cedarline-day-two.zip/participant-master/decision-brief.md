# What Dana needs

Prepare a short recommendation for the next phase of the New Starter Hub. Name the **two changes** you would test first, what in the supplied evidence supports them, and what would make you revise your view. Include one simple follow-up measure for each change. You may propose work within a $500 test budget; anything larger needs a separate approval. No expansion has been approved.

The support desk is checking the privacy concern separately. You should flag it and request verification, without deciding from these records alone that a breach occurred or that it is common.

Write plainly. Dana prefers a decision and evidence, not a long catalogue of every comment. Do not expose individual senders in a public-facing output.
