# Cedarline New Starter Hub: what should change?

You are an operations analyst at fictional Cedarline. **Start with `Day 2 Student Guide.docx` and `case-background.md`; no earlier class session is required.** Dana Chen wants a concise recommendation before deciding whether to extend the New Starter Hub. Recommend **two changes**, explain the evidence and its limits, and say what you would measure next. Build a small working aid that shows the checked survey counts and the response IDs behind them.

Keep your counts and quotes traceable to the supplied records. Do not infer prevalence from a few memorable support messages. Do not silently treat an old draft as verified analysis. These people, files, and figures are entirely fictional.

After you finish, write down a short method another person could use on a new feedback batch. Your instructor will provide that new batch separately so you can test and revise the method. Keep your aid local and the coding visible. A plain spreadsheet or table is enough; it does not need to classify comments automatically.

**A starting request you can adapt:** “Read the case background, survey, support messages, method note, and decision brief in this folder. Before drafting a recommendation, propose a small set of themes and show which survey response IDs support each one. Keep survey and support records separate. Tell me what claims in the old draft do not follow from the evidence, and what still needs human judgment.”

Check the coding and denominators yourself. Then ask for the concise recommendation in a form Dana can use. Finally, ask the tool to write a reusable workflow that names its inputs, output, checks, and stopping points; try it on the separate new batch when your instructor provides it. For one possible fix, check an AI claim against its original source. Say what the source does and does not support; if you cannot verify it, do not use the claim.
